# EV Ride Planner - Android App (Kotlin & Jetpack Compose)

**EV Ride Planner** is a smart trip and battery calculation companion designed for electric scooter, electric motorcycle, and electric car riders. It helps EV riders eliminate range anxiety by planning multi-stop routes, calculating exact battery consumption per leg, verifying safety reserve margins, and finding fast charging stations.

---

## Features

1. **Trip Planning & Vehicle Presets**
   - Choose from EV presets (Ather 450X, Ola S1 Pro, TVS iQube, Ultraviolette F77, Revolt RV400, Tata Nexon.ev, MG ZS EV, Tesla Model 3) or enter custom specs.
   - 100% full-charge range (km).
   - Starting battery percentage.
   - Minimum reserve safety margin (e.g. 15%).
   - Battery pack capacity (kWh) to calculate energy usage and charging costs.

2. **Route & Stop Management**
   - Multi-stop route planning: Home, Charging Station, and Destination.
   - Distance between each stop (km).
   - Add, edit, delete, and reorder stops (Move Up / Down).
   - One-tap "Round Trip" route generation (automatically mirrors intermediate stops back to base).
   - Real-time total distance calculation.

3. **Smart Battery & Weather Calculation Engine**
   - Segment-by-segment consumption based on vehicle range.
   - Estimated battery on arrival at each stop.
   - Support for both planned charge targets and actual battery achieved on the road.
   - Weather & terrain modifiers:
     - Clear (1.0x)
     - Rain / Headwind (+15% consumption)
     - Extreme Cold (<5°C) (+25% consumption)
     - Hilly / Elevation Climb (+20% consumption)
   - Real-time automatic recalculation on any input adjustment.

4. **Safety Checks & Route Validation**
   - Prominent **ROUTE PASS** or **ROUTE FAIL** status banner.
   - Warning when rider cannot reach the next stop safely.
   - Low-battery alert and minimum reserve breach warnings.
   - Detailed, expandable breakdown of critical segments with shortfall distance.

5. **Dashboard & Visualization**
   - Key metrics: Total Trip Distance, Final Arrival Battery %, Extra Return Range (km), Total Charging Stops, and Estimated Charging Cost (₹).
   - Segment breakdown cards with animated battery level bars.
   - Google Maps navigation integration.

6. **Charging Stations Directory**
   - Verified fast chargers from Ather Grid, Tata Power EZ Charge, Zeon, Jio-bp pulse, Statiq, and Shell Recharge.
   - Search by city or provider name.
   - One-click "Add to Route" button.
   - Favorite station bookmarking.
   - Direct Google Maps navigation coordinates.

7. **Data Persistence & Offline Support**
   - Local SQLite database powered by Android Jetpack Room.
   - Save and load complete trip plans offline.
   - Export trip plans as formatted JSON for sharing or backup.
   - Import JSON trip plans directly.

8. **Google Sign-In & Rider Profile Interface**
   - Integrated Google Sign-In profile modal with Google branding.
   - Account switcher to test sign-in flow (e.g., Nikesh V. or test rider accounts).
   - Cloud backup status and eco stats (total km logged & CO2 saved).

---

## Technical Stack

- **Language:** Kotlin 2.2
- **UI Framework:** Jetpack Compose (Material Design 3, EV Green Theme)
- **Architecture:** MVVM (Model-View-ViewModel) + Clean Architecture
- **State Management:** Kotlin Coroutines & StateFlow
- **Local Database:** Room Database with TypeConverters
- **Build System:** Gradle Kotlin DSL (`build.gradle.kts`)

---

## How to Build the APK in Android Studio

1. **Prerequisites:**
   - Android Studio Iguana, Jellyfish, Koala, or Ladybug.
   - JDK 17 configured in Android Studio (*Settings > Build, Execution, Deployment > Build Tools > Gradle*).
   - Android SDK 34 or 36.

2. **Open Project:**
   - In Android Studio, click **File > Open** and select the project root folder.
   - Allow Gradle to sync.

3. **Generate Debug or Release APK:**
   - In the top menu, click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
   - Android Studio will build the APK and show a notification: *"APK(s) generated successfully"*.
   - Click **Locate** to open the folder:
     ```
     app/build/outputs/apk/debug/app-debug.apk
     ```

4. **Run on Device or Emulator:**
   - Connect an Android device or launch an AVD.
   - Click the green **Run** (Shift + F10) button.
