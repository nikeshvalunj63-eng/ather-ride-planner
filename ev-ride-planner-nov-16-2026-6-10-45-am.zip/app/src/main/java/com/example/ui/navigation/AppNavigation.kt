package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.EvStation
import androidx.compose.material.icons.filled.Garage
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Route
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Dashboard : Screen("dashboard", "Dashboard", Icons.Default.Dashboard)
    object Planner : Screen("planner", "Planner", Icons.Default.Route)
    object Garage : Screen("garage", "Garage", Icons.Default.Garage)
    object Stations : Screen("stations", "Stations", Icons.Default.EvStation)
    object History : Screen("history", "Saved", Icons.Default.History)
    object SmartPredictor : Screen("smart_predictor", "Predictor", Icons.Default.ElectricBolt)
    object Community : Screen("ev_community", "Community", Icons.Default.Groups)
}
