package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.EvConnectorCatalog
import com.example.viewmodel.UiTripState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SubmitCommunityStationDialog(
    state: UiTripState,
    onDismiss: () -> Unit,
    onSubmit: (
        name: String,
        provider: String,
        city: String,
        address: String,
        powerKw: Double,
        connectorTypes: String,
        costPerKwh: Double,
        bayCapacity: Int,
        latitude: Double,
        longitude: Double,
        openingHours: String,
        notes: String
    ) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var provider by remember { mutableStateOf("Independent Host") }
    var city by remember { mutableStateOf(state.locationAreaLabel ?: "") }
    var address by remember { mutableStateOf("") }
    var powerStr by remember { mutableStateOf("22") }
    var costStr by remember { mutableStateOf("18") }
    var baysStr by remember { mutableStateOf("2") }
    var latStr by remember { mutableStateOf(state.userLatitude?.let { String.format("%.4f", it) } ?: "18.5204") }
    var lonStr by remember { mutableStateOf(state.userLongitude?.let { String.format("%.4f", it) } ?: "73.8567") }
    var hours by remember { mutableStateOf("24/7") }
    var notes by remember { mutableStateOf("") }
    var selectedConnectors by remember { mutableStateOf(state.compatibleConnectors.ifEmpty { setOf("Type 2") }) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Submit Charging Station", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Station Name *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("submit_station_name_input")
                )
                OutlinedTextField(
                    value = provider,
                    onValueChange = { provider = it },
                    label = { Text("Operator / Host") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = city,
                        onValueChange = { city = it },
                        label = { Text("City *") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = powerStr,
                        onValueChange = { powerStr = it },
                        label = { Text("kW") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(0.7f)
                    )
                }
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Street / Landmark") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Connectors", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    EvConnectorCatalog.ALL_CONNECTORS.take(6).forEach { conn ->
                        val active = selectedConnectors.contains(conn)
                        FilterChip(
                            selected = active,
                            onClick = {
                                selectedConnectors = if (active && selectedConnectors.size > 1) {
                                    selectedConnectors - conn
                                } else {
                                    selectedConnectors + conn
                                }
                            },
                            label = { Text(conn, fontSize = 11.sp) }
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = costStr,
                        onValueChange = { costStr = it },
                        label = { Text("₹/kWh") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = baysStr,
                        onValueChange = { baysStr = it },
                        label = { Text("Bays") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = latStr,
                        onValueChange = { latStr = it },
                        label = { Text("Latitude") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = lonStr,
                        onValueChange = { lonStr = it },
                        label = { Text("Longitude") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = hours,
                    onValueChange = { hours = it },
                    label = { Text("Opening Hours") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Access / Parking Notes") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSubmit(
                        name.ifBlank { "Community EV Hub" },
                        provider.ifBlank { "Independent Host" },
                        city.ifBlank { "Local Hub" },
                        address.ifBlank { city.ifBlank { "GPS Pinned" } },
                        powerStr.toDoubleOrNull() ?: 22.0,
                        EvConnectorCatalog.toCsv(selectedConnectors),
                        costStr.toDoubleOrNull() ?: 18.0,
                        baysStr.toIntOrNull() ?: 2,
                        latStr.toDoubleOrNull() ?: 18.5204,
                        lonStr.toDoubleOrNull() ?: 73.8567,
                        hours.ifBlank { "24/7" },
                        notes
                    )
                },
                modifier = Modifier.testTag("confirm_submit_station_button")
            ) {
                Text("Submit Station")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun ShareVerifiedRouteDialog(
    state: UiTripState,
    activeStopsJson: String,
    onDismiss: () -> Unit,
    onSubmit: (
        title: String,
        originCity: String,
        destinationCity: String,
        totalDistanceKm: Double,
        elevationGainMeters: Double,
        vehicleName: String,
        vehicleCategory: String,
        chargingStopsCount: Int,
        arrivalBatteryPercent: Double,
        weatherCondition: String,
        stopsSummary: String,
        stopsJson: String,
        notes: String
    ) -> Unit
) {
    val firstStopName = state.stops.firstOrNull()?.name ?: "Home"
    val lastStopName = state.stops.lastOrNull()?.name ?: "Destination"
    val defaultSummary = state.stops.joinToString(" ➔ ") { it.name }

    var title by remember { mutableStateOf(state.title.ifBlank { "$firstStopName to $lastStopName" }) }
    var originCity by remember { mutableStateOf(firstStopName) }
    var destinationCity by remember { mutableStateOf(lastStopName) }
    var distStr by remember {
        mutableStateOf(
            if (state.calculationSummary.totalDistanceKm > 0.0) {
                String.format("%.1f", state.calculationSummary.totalDistanceKm)
            } else "65.0"
        )
    }
    var elevStr by remember { mutableStateOf("${state.smartPredictionInput.elevationGainMeters.toInt()}") }
    var arrivalStr by remember { mutableStateOf("${state.calculationSummary.finalBatteryPercent.toInt()}") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Share Verified Route", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 400.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Prefilled from '${state.selectedVehicleName}' • ${state.calculationSummary.totalChargingStops} charge stop(s)",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Route Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("submit_route_title_input")
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = originCity,
                        onValueChange = { originCity = it },
                        label = { Text("Origin") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = destinationCity,
                        onValueChange = { destinationCity = it },
                        label = { Text("Destination") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = distStr,
                        onValueChange = { distStr = it },
                        label = { Text("Distance (km)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = elevStr,
                        onValueChange = { elevStr = it },
                        label = { Text("Elev Gain (m)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = arrivalStr,
                    onValueChange = { arrivalStr = it },
                    label = { Text("Actual Arrival Battery (%)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Road / Charger Reliability Notes") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSubmit(
                        title.ifBlank { "$originCity to $destinationCity" },
                        originCity.ifBlank { "Start" },
                        destinationCity.ifBlank { "Destination" },
                        distStr.toDoubleOrNull() ?: 50.0,
                        elevStr.toDoubleOrNull() ?: 0.0,
                        state.selectedVehicleName,
                        state.selectedVehicleCategory,
                        state.calculationSummary.totalChargingStops,
                        arrivalStr.toDoubleOrNull() ?: state.calculationSummary.finalBatteryPercent,
                        state.weatherCondition,
                        defaultSummary.ifBlank { "$originCity ➔ $destinationCity" },
                        activeStopsJson,
                        notes
                    )
                },
                modifier = Modifier.testTag("confirm_submit_route_button")
            ) {
                Text("Share Route")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun SubmitRangeReportDialog(
    state: UiTripState,
    onDismiss: () -> Unit,
    onSubmit: (
        vehicleName: String,
        vehicleCategory: String,
        claimedRangeKm: Double,
        observedRealRangeKm: Double,
        distanceDrivenKm: Double,
        batteryUsedPercent: Double,
        avgEfficiencyWhPerKm: Double,
        avgSpeedKmh: Double,
        weatherCondition: String,
        ridingOrAcMode: String,
        notes: String
    ) -> Unit
) {
    var vehicleName by remember { mutableStateOf(state.selectedVehicleName) }
    var claimedStr by remember { mutableStateOf("${state.vehicleRange100.toInt()}") }
    var distDrivenStr by remember { mutableStateOf("45") }
    var batteryUsedStr by remember { mutableStateOf("50") }
    var realRangeStr by remember { mutableStateOf("90") }
    var effStr by remember { mutableStateOf("${state.smartPredictionInput.vehicleEfficiencyWhPerKm.toInt()}") }
    var speedStr by remember { mutableStateOf("${state.averageSpeedKmh.toInt()}") }
    var modeStr by remember {
        mutableStateOf(
            if (state.selectedVehicleCategory.equals("Electric Car", ignoreCase = true)) {
                state.smartPredictionInput.acUsageMode.label
            } else {
                state.smartPredictionInput.ridingMode.label
            }
        )
    }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Post Real-World Range Report", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = vehicleName,
                    onValueChange = { vehicleName = it },
                    label = { Text("EV Model") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = claimedStr,
                        onValueChange = { claimedStr = it },
                        label = { Text("Claimed (km)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = realRangeStr,
                        onValueChange = { realRangeStr = it },
                        label = { Text("Real Range (km)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = distDrivenStr,
                        onValueChange = { distDrivenStr = it },
                        label = { Text("Driven (km)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = batteryUsedStr,
                        onValueChange = { batteryUsedStr = it },
                        label = { Text("Battery Used %") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedButton(
                    onClick = {
                        val d = distDrivenStr.toDoubleOrNull() ?: 45.0
                        val b = (batteryUsedStr.toDoubleOrNull() ?: 50.0).coerceIn(1.0, 100.0)
                        val proj = (d / b) * 100.0
                        realRangeStr = String.format("%.1f", proj)
                        val wh = (state.batteryCapacityKWh * 1000.0 * (b / 100.0)) / d.coerceAtLeast(1.0)
                        effStr = String.format("%.1f", wh)
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Auto-Calculate Real Range & Wh/km", fontSize = 12.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = effStr,
                        onValueChange = { effStr = it },
                        label = { Text("Wh/km") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = speedStr,
                        onValueChange = { speedStr = it },
                        label = { Text("Avg km/h") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = modeStr,
                    onValueChange = { modeStr = it },
                    label = { Text("Ride Mode / AC Usage") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Terrain / Traffic Notes") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSubmit(
                        vehicleName.ifBlank { state.selectedVehicleName },
                        state.selectedVehicleCategory,
                        claimedStr.toDoubleOrNull() ?: state.vehicleRange100,
                        realRangeStr.toDoubleOrNull() ?: 85.0,
                        distDrivenStr.toDoubleOrNull() ?: 45.0,
                        batteryUsedStr.toDoubleOrNull() ?: 50.0,
                        effStr.toDoubleOrNull() ?: 35.0,
                        speedStr.toDoubleOrNull() ?: state.averageSpeedKmh,
                        state.weatherCondition,
                        modeStr.ifBlank { "Ride" },
                        notes
                    )
                },
                modifier = Modifier.testTag("confirm_submit_range_button")
            ) {
                Text("Publish Report")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SubmitEvOwnerReviewDialog(
    state: UiTripState,
    onDismiss: () -> Unit,
    onSubmit: (
        vehicleName: String,
        vehicleCategory: String,
        rating: Int,
        ownershipMonths: Int,
        odometerKm: Int,
        headline: String,
        pros: String,
        cons: String,
        reviewText: String
    ) -> Unit
) {
    var vehicleName by remember { mutableStateOf(state.selectedVehicleName) }
    var category by remember { mutableStateOf(state.selectedVehicleCategory) }
    var rating by remember { mutableIntStateOf(5) }
    var monthsStr by remember { mutableStateOf("8") }
    var odoStr by remember { mutableStateOf("3500") }
    var headline by remember { mutableStateOf("") }
    var pros by remember { mutableStateOf("") }
    var cons by remember { mutableStateOf("") }
    var reviewText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Write EV Owner Review", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = vehicleName,
                    onValueChange = { vehicleName = it },
                    label = { Text("EV Model") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Electric Scooter", "Electric Motorcycle", "Electric Car").forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat.removePrefix("Electric "), fontSize = 11.sp) }
                        )
                    }
                }
                Text("Rating", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    (1..5).forEach { stars ->
                        FilterChip(
                            selected = rating == stars,
                            onClick = { rating = stars },
                            label = { Text("$stars★", fontSize = 12.sp) }
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = monthsStr,
                        onValueChange = { monthsStr = it },
                        label = { Text("Months Owned") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = odoStr,
                        onValueChange = { odoStr = it },
                        label = { Text("Odometer (km)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = headline,
                    onValueChange = { headline = it },
                    label = { Text("Headline *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("submit_review_headline_input")
                )
                OutlinedTextField(
                    value = pros,
                    onValueChange = { pros = it },
                    label = { Text("Pros") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = cons,
                    onValueChange = { cons = it },
                    label = { Text("Cons") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = reviewText,
                    onValueChange = { reviewText = it },
                    label = { Text("Detailed Experience *") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSubmit(
                        vehicleName.ifBlank { state.selectedVehicleName },
                        category,
                        rating,
                        monthsStr.toIntOrNull() ?: 6,
                        odoStr.toIntOrNull() ?: 2500,
                        headline.ifBlank { "$vehicleName Owner Review" },
                        pros,
                        cons,
                        reviewText.ifBlank { headline.ifBlank { "Solid daily EV performance." } }
                    )
                },
                modifier = Modifier.testTag("confirm_submit_review_button")
            ) {
                Text("Post Review")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ShareChargingExperienceDialog(
    state: UiTripState,
    onDismiss: () -> Unit,
    onSubmit: (
        stationName: String,
        provider: String,
        vehicleName: String,
        connectorUsed: String,
        peakPowerKw: Double,
        startPercent: Double,
        endPercent: Double,
        durationMinutes: Int,
        waitTimeMinutes: Int,
        rating: Int,
        experienceNotes: String
    ) -> Unit
) {
    var stationName by remember { mutableStateOf("") }
    var provider by remember { mutableStateOf("Ather Grid") }
    var connectorUsed by remember { mutableStateOf(state.compatibleConnectors.firstOrNull() ?: "Type 2") }
    var powerStr by remember { mutableStateOf("22") }
    var startStr by remember { mutableStateOf("20") }
    var endStr by remember { mutableStateOf("85") }
    var durationStr by remember { mutableStateOf("35") }
    var waitStr by remember { mutableStateOf("0") }
    var rating by remember { mutableIntStateOf(5) }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Share Charging Experience", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = stationName,
                    onValueChange = { stationName = it },
                    label = { Text("Station Name *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("submit_experience_station_input")
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = provider,
                        onValueChange = { provider = it },
                        label = { Text("Operator") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = powerStr,
                        onValueChange = { powerStr = it },
                        label = { Text("Peak kW") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(0.7f)
                    )
                }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    EvConnectorCatalog.ALL_CONNECTORS.take(5).forEach { conn ->
                        FilterChip(
                            selected = connectorUsed == conn,
                            onClick = { connectorUsed = conn },
                            label = { Text(conn, fontSize = 11.sp) }
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = startStr,
                        onValueChange = { startStr = it },
                        label = { Text("Start %") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = endStr,
                        onValueChange = { endStr = it },
                        label = { Text("End %") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = durationStr,
                        onValueChange = { durationStr = it },
                        label = { Text("Charge Mins") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = waitStr,
                        onValueChange = { waitStr = it },
                        label = { Text("Wait Mins") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    (1..5).forEach { stars ->
                        FilterChip(
                            selected = rating == stars,
                            onClick = { rating = stars },
                            label = { Text("$stars★", fontSize = 12.sp) }
                        )
                    }
                }
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Charger Speed, Amenities & Queue Notes") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSubmit(
                        stationName.ifBlank { "Public EV Charger" },
                        provider.ifBlank { "Public Operator" },
                        state.selectedVehicleName,
                        connectorUsed,
                        powerStr.toDoubleOrNull() ?: 22.0,
                        startStr.toDoubleOrNull() ?: 20.0,
                        endStr.toDoubleOrNull() ?: 85.0,
                        durationStr.toIntOrNull() ?: 35,
                        waitStr.toIntOrNull() ?: 0,
                        rating,
                        notes.ifBlank { "Smooth session with $connectorUsed." }
                    )
                },
                modifier = Modifier.testTag("confirm_submit_experience_button")
            ) {
                Text("Share Session")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SubmitTripRecommendationDialog(
    onDismiss: () -> Unit,
    onSubmit: (
        title: String,
        corridor: String,
        totalDistanceKm: Double,
        recommendedCategory: String,
        difficulty: String,
        bestSeason: String,
        chargingTip: String,
        highlights: String
    ) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var corridor by remember { mutableStateOf("") }
    var distStr by remember { mutableStateOf("85") }
    var category by remember { mutableStateOf("All EVs") }
    var difficulty by remember { mutableStateOf("Easy") }
    var bestSeason by remember { mutableStateOf("Oct–Mar") }
    var chargingTip by remember { mutableStateOf("") }
    var highlights by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Recommend an EV Trip", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Trip Title *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("submit_rec_title_input")
                )
                OutlinedTextField(
                    value = corridor,
                    onValueChange = { corridor = it },
                    label = { Text("Corridor / Region *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = distStr,
                        onValueChange = { distStr = it },
                        label = { Text("Total km") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = bestSeason,
                        onValueChange = { bestSeason = it },
                        label = { Text("Best Season") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                Text("Best For", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("All EVs", "Electric Scooter", "Electric Motorcycle", "Electric Car").forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat.removePrefix("Electric "), fontSize = 11.sp) }
                        )
                    }
                }
                Text("Difficulty", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Easy", "Moderate", "Challenging").forEach { diff ->
                        FilterChip(
                            selected = difficulty == diff,
                            onClick = { difficulty = diff },
                            label = { Text(diff, fontSize = 11.sp) }
                        )
                    }
                }
                OutlinedTextField(
                    value = chargingTip,
                    onValueChange = { chargingTip = it },
                    label = { Text("Charging Strategy Tip *") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = highlights,
                    onValueChange = { highlights = it },
                    label = { Text("Route Highlights *") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSubmit(
                        title.ifBlank { "Recommended EV Trip" },
                        corridor.ifBlank { title.ifBlank { "Regional Loop" } },
                        distStr.toDoubleOrNull() ?: 85.0,
                        category,
                        difficulty,
                        bestSeason.ifBlank { "All Year" },
                        chargingTip.ifBlank { "Top up to 90% before uphill climbs." },
                        highlights.ifBlank { "Smooth tarmac with reliable EV charging stops." }
                    )
                },
                modifier = Modifier.testTag("confirm_submit_rec_button")
            ) {
                Text("Post Recommendation")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
