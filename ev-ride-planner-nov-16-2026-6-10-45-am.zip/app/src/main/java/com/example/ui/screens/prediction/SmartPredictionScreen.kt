package com.example.ui.screens.prediction

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.ElectricScooter
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AcUsageMode
import com.example.data.model.RidingMode
import com.example.ui.components.MathBreakdownCard
import com.example.ui.components.MlCalibrationCard
import com.example.ui.components.PredictionOutputsHeroCard
import com.example.ui.components.RecommendedChargingPointCard
import com.example.ui.components.SmoothNumberField
import com.example.viewmodel.TripViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SmartPredictionScreen(
    viewModel: TripViewModel,
    onBack: () -> Unit,
    onOpenStations: () -> Unit
) {
    BackHandler(onBack = onBack)

    val state by viewModel.uiState.collectAsState()
    val telemetryRecords by viewModel.telemetryRecords.collectAsState()
    val input = state.smartPredictionInput
    val result = state.smartPredictionResult
    val syncKey = "${input.vehicleName}_${input.vehicleCategory}_${state.predictionSyncVersion}"
    var elevationChipKey by remember { mutableStateOf(0) }

    var showLogOutcomeDialog by remember { mutableStateOf(false) }
    var actualConsumedInput by remember { mutableStateOf<Double?>(null) }
    var logNotes by remember { mutableStateOf("") }

    val weatherOptions = listOf(
        "Clear",
        "Rain / Headwind",
        "Extreme Cold (<5°C)",
        "Hot (>35°C)",
        "Hilly / Elevation"
    )
    val elevationPresets = listOf(-200.0 to "-200m", 0.0 to "0m", 300.0 to "+300m", 800.0 to "+800m")

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 640.dp)
                .padding(horizontal = 16.dp)
                .testTag("smart_predictor_lazy_column"),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 88.dp)
        ) {
            // Top bar
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("smart_predictor_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back to Dashboard"
                            )
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        Column {
                            Text(
                                text = "Smart Battery Prediction",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "${input.vehicleName} (${input.batteryCapacityKWh} kWh)",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    TextButton(
                        onClick = { viewModel.syncPredictionFromActiveTrip() },
                        modifier = Modifier
                            .defaultMinSize(minHeight = 48.dp)
                            .testTag("sync_route_prediction_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Sync,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Sync Route", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            // Outputs Hero Card: Arrival %, Energy Consumption, Safety Margin
            item {
                PredictionOutputsHeroCard(
                    input = input,
                    result = result
                )
            }

            // Output: Recommended Charging Point
            item {
                RecommendedChargingPointCard(
                    result = result,
                    onAddStationToRoute = { station -> viewModel.addStationToTrip(station) },
                    onBrowseStations = onOpenStations
                )
            }

            // All Prediction Inputs Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("prediction_inputs_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Ride & Physics Inputs",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )

                        // Vehicle Category Selector (Two-Wheeler vs Electric Car)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = input.isTwoWheeler,
                                onClick = { viewModel.updatePredictionVehicleCategory("Electric Scooter") },
                                label = { Text("Two-Wheeler") },
                                leadingIcon = {
                                    Icon(Icons.Default.ElectricScooter, contentDescription = null, modifier = Modifier.size(16.dp))
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .defaultMinSize(minHeight = 48.dp)
                                    .testTag("predictor_category_two_wheeler")
                            )
                            FilterChip(
                                selected = input.isCar,
                                onClick = { viewModel.updatePredictionVehicleCategory("Electric Car") },
                                label = { Text("Electric Car") },
                                leadingIcon = {
                                    Icon(Icons.Default.DirectionsCar, contentDescription = null, modifier = Modifier.size(16.dp))
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .defaultMinSize(minHeight = 48.dp)
                                    .testTag("predictor_category_car")
                            )
                        }

                        // Row 1: Current Battery % & Distance km
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            SmoothNumberField(
                                value = input.currentBatteryPercent,
                                onValueChange = { if (it != null) viewModel.updatePredictionBattery(it) },
                                label = "Current Battery",
                                suffix = "%",
                                minValue = 1.0,
                                maxValue = 100.0,
                                syncKey = syncKey,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("predictor_battery_input")
                            )
                            SmoothNumberField(
                                value = input.distanceKm,
                                onValueChange = { if (it != null) viewModel.updatePredictionDistance(it) },
                                label = "Distance",
                                suffix = "km",
                                minValue = 0.0,
                                maxValue = 2000.0,
                                syncKey = syncKey,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("predictor_distance_input")
                            )
                        }

                        // Row 2: Vehicle Efficiency (Wh/km) & Speed (km/h)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            SmoothNumberField(
                                value = input.vehicleEfficiencyWhPerKm,
                                onValueChange = { if (it != null) viewModel.updatePredictionEfficiency(it) },
                                label = "Efficiency",
                                suffix = "Wh/km",
                                minValue = 10.0,
                                maxValue = 600.0,
                                syncKey = syncKey,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("predictor_efficiency_input")
                            )
                            SmoothNumberField(
                                value = input.speedKmh,
                                onValueChange = { if (it != null) viewModel.updatePredictionSpeed(it) },
                                label = "Cruising Speed",
                                suffix = "km/h",
                                minValue = 5.0,
                                maxValue = 200.0,
                                syncKey = syncKey,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("predictor_speed_input")
                            )
                        }

                        // Row 3: Road Elevation (m) & Payload (kg)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            SmoothNumberField(
                                value = input.elevationGainMeters,
                                onValueChange = { if (it != null) viewModel.updatePredictionElevation(it) },
                                label = "Road Elevation",
                                suffix = "m",
                                allowNegative = true,
                                minValue = -3000.0,
                                maxValue = 5000.0,
                                syncKey = "${syncKey}_$elevationChipKey",
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("predictor_elevation_input")
                            )
                            SmoothNumberField(
                                value = input.payloadKg,
                                onValueChange = { if (it != null) viewModel.updatePredictionPayload(it) },
                                label = "Payload",
                                suffix = "kg",
                                minValue = 0.0,
                                maxValue = 1000.0,
                                syncKey = syncKey,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("predictor_payload_input")
                            )
                        }

                        // Quick Elevation Presets
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            elevationPresets.forEach { (elevVal, label) ->
                                FilterChip(
                                    selected = kotlin.math.abs(input.elevationGainMeters - elevVal) < 0.5,
                                    onClick = {
                                        viewModel.updatePredictionElevation(elevVal)
                                        elevationChipKey += 1
                                    },
                                    label = { Text(label, fontSize = 11.sp) }
                                )
                            }
                        }

                        // Weather Selector
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "Weather Condition",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                weatherOptions.forEach { wx ->
                                    FilterChip(
                                        selected = input.weatherCondition == wx,
                                        onClick = { viewModel.updatePredictionWeather(wx) },
                                        label = { Text(wx, fontSize = 11.sp) }
                                    )
                                }
                            }
                        }

                        // Riding Mode (Two-Wheeler) OR AC Usage (Electric Car)
                        if (input.isCar) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "Cabin AC Usage (Electric Car)",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    AcUsageMode.entries.forEach { mode ->
                                        FilterChip(
                                            selected = input.acUsageMode == mode,
                                            onClick = { viewModel.updatePredictionAcMode(mode) },
                                            label = { Text(mode.label, fontSize = 11.sp) },
                                            modifier = Modifier
                                                .weight(1f)
                                                .defaultMinSize(minHeight = 48.dp)
                                                .testTag("predictor_ac_${mode.name.lowercase()}")
                                        )
                                    }
                                }
                            }
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "Riding Mode (Two-Wheeler)",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    RidingMode.entries.forEach { mode ->
                                        FilterChip(
                                            selected = input.ridingMode == mode,
                                            onClick = { viewModel.updatePredictionRidingMode(mode) },
                                            label = { Text(mode.label, fontSize = 11.sp) },
                                            modifier = Modifier
                                                .defaultMinSize(minHeight = 48.dp)
                                                .testTag("predictor_mode_${mode.name.lowercase()}")
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Transparent Math Breakdown
            item {
                MathBreakdownCard(
                    input = input,
                    result = result
                )
            }

            // ML Calibration & Reliable Telemetry Collection Card
            item {
                MlCalibrationCard(
                    result = result,
                    useMlIfReady = input.useMlCalibrationIfReady,
                    records = telemetryRecords,
                    onToggleMlCalibration = { viewModel.setMlCalibrationEnabled(it) },
                    onOpenLogOutcomeDialog = {
                        actualConsumedInput = (result.energyConsumedPercent * 10.0).toInt() / 10.0
                        logNotes = ""
                        showLogOutcomeDialog = true
                    },
                    onDeleteRecord = { viewModel.deleteTelemetryRecord(it) }
                )
            }
        }
    }

    if (showLogOutcomeDialog) {
        AlertDialog(
            onDismissRequest = { showLogOutcomeDialog = false },
            title = { Text("Log Actual Ride Outcome", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Record the true battery % consumed on your ${input.distanceKm.toInt()} km ride so the model verifies accuracy and unlocks ML calibration after 10 reliable trips.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    SmoothNumberField(
                        value = actualConsumedInput,
                        onValueChange = { actualConsumedInput = it },
                        label = "Actual Battery Used",
                        suffix = "%",
                        minValue = 0.5,
                        maxValue = 99.5,
                        syncKey = showLogOutcomeDialog,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("log_actual_consumed_input")
                    )
                    OutlinedTextField(
                        value = logNotes,
                        onValueChange = { logNotes = it },
                        label = { Text("Ride Notes (Optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val consumed = actualConsumedInput ?: result.energyConsumedPercent
                        viewModel.logActualTripOutcome(consumed, logNotes)
                        showLogOutcomeDialog = false
                    },
                    modifier = Modifier.testTag("confirm_log_actual_trip_button")
                ) {
                    Text("Save Ride Data")
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogOutcomeDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
