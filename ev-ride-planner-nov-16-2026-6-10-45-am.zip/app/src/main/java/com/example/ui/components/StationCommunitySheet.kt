package com.example.ui.components

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EditLocationAlt
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.ui.window.Dialog
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import com.example.auth.GoogleAuthHelper
import com.example.data.model.AvailabilityStatus
import com.example.data.model.ChargingOperatorCatalog
import com.example.data.model.ChargingStation
import com.example.data.model.ReportCategory
import com.example.data.model.RiderProfile
import com.example.data.model.StationCommunitySummary
import com.example.data.model.StationConfirmation
import com.example.data.model.StationPhoto
import com.example.data.model.StationReport
import com.example.ui.theme.EVGreenPrimary
import com.example.ui.theme.StatusDanger
import com.example.ui.theme.StatusSafe
import com.example.ui.theme.StatusWarning
import com.example.util.StationPhotoHelper
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val CHARGER_DOWN_REASONS = listOf(
    "Offline / No Power",
    "Broken Connector",
    "Blocked Charging Bay",
    "App / Payment Error",
    "Reduced Output Speed"
)

private val WRONG_LOCATION_REASONS = listOf(
    "GPS Pin Off by >100m",
    "Wrong Entrance / Side of Road",
    "Station Removed / Closed",
    "Duplicate Listing"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StationCommunitySheet(
    station: ChargingStation,
    summary: StationCommunitySummary?,
    reports: List<StationReport>,
    confirmations: List<StationConfirmation>,
    photos: List<StationPhoto>,
    riderProfile: RiderProfile,
    userLatitude: Double?,
    userLongitude: Double?,
    isSubmittingCommunityAction: Boolean,
    initialTab: Int = 0,
    onDismiss: () -> Unit,
    onAddStationToTrip: () -> Unit,
    onAuthSuccess: (uid: String, displayName: String, email: String, photoUrl: String?) -> Unit,
    onSubmitAvailability: (AvailabilityStatus, String, String) -> Unit,
    onSubmitChargerDownReport: (reason: String, notes: String) -> Unit,
    onSubmitWrongLocationReport: (reason: String, notes: String, lat: Double, lon: Double) -> Unit,
    onResolveReport: (StationReport) -> Unit,
    onUploadPhotoBase64: (caption: String, imageBase64: String) -> Unit,
    onDeletePhoto: (String) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    var selectedTab by remember(station.id, initialTab) { mutableIntStateOf(initialTab) }
    val operatorProfile = remember(station) {
        ChargingOperatorCatalog.resolveOperator(
            provider = station.provider,
            stationName = station.name,
            customPhone = station.operatorPhone,
            customWebsite = station.operatorWebsite
        )
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 600.dp)
                .testTag("station_community_sheet"),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = station.name,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${operatorProfile.displayName} • ${station.city}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }
                IconButton(onClick = onDismiss, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Close Station Details")
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Section Tabs
            val tabs = listOf("Operator", "Availability", "Report Issue", "Photos (${photos.size})")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(tabs.size) { index ->
                    FilterChip(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        label = { Text(tabs[index], fontSize = 12.sp) },
                        modifier = Modifier.testTag("station_sheet_tab_$index")
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f, fill = false)
                    .verticalScroll(rememberScrollState())
                    .padding(bottom = 12.dp)
                    .testTag("station_sheet_scroll_column"),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                when (selectedTab) {
                    0 -> {
                        OperatorIntegrationSection(
                            station = station,
                            operatorProfile = operatorProfile,
                            summary = summary,
                            onCallSupport = { phone ->
                                val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))
                                try {
                                    context.startActivity(dialIntent)
                                } catch (_: ActivityNotFoundException) {
                                    Toast.makeText(context, "No phone dialer available", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onOpenPortal = { url ->
                                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                                try {
                                    context.startActivity(webIntent)
                                } catch (_: ActivityNotFoundException) {
                                    Toast.makeText(context, "No browser available", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onNavigate = {
                                val geoUri = Uri.parse(
                                    "geo:${station.latitude},${station.longitude}?q=${Uri.encode("${station.name}, ${station.city}")}"
                                )
                                try {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, geoUri))
                                } catch (_: ActivityNotFoundException) {
                                    Toast.makeText(context, "No Maps app installed", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onAddToRoute = onAddStationToTrip
                        )
                    }

                    1 -> {
                        if (!riderProfile.isSignedIn) {
                            CommunityAuthPromptCard(
                                onSignInClick = {
                                    GoogleAuthHelper.onGoogleSignInClicked(
                                        context = context,
                                        credentialManager = credentialManager,
                                        scope = coroutineScope,
                                        onAuthSuccess = { user ->
                                            onAuthSuccess(
                                                user.uid,
                                                user.displayName ?: "EV Rider",
                                                user.email ?: "",
                                                user.photoUrl?.toString()
                                            )
                                        },
                                        onAuthError = { msg ->
                                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                        }
                                    )
                                }
                            )
                        }

                        CommunityAvailabilitySection(
                            station = station,
                            summary = summary,
                            confirmations = confirmations,
                            isSignedIn = riderProfile.isSignedIn,
                            isSubmitting = isSubmittingCommunityAction,
                            onSubmitAvailability = onSubmitAvailability
                        )
                    }

                    2 -> {
                        if (!riderProfile.isSignedIn) {
                            CommunityAuthPromptCard(
                                onSignInClick = {
                                    GoogleAuthHelper.onGoogleSignInClicked(
                                        context = context,
                                        credentialManager = credentialManager,
                                        scope = coroutineScope,
                                        onAuthSuccess = { user ->
                                            onAuthSuccess(
                                                user.uid,
                                                user.displayName ?: "EV Rider",
                                                user.email ?: "",
                                                user.photoUrl?.toString()
                                            )
                                        },
                                        onAuthError = { msg ->
                                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                        }
                                    )
                                }
                            )
                        }

                        ReportStationIssueSection(
                            station = station,
                            reports = reports,
                            currentUid = riderProfile.uid,
                            isSignedIn = riderProfile.isSignedIn,
                            isSubmitting = isSubmittingCommunityAction,
                            userLatitude = userLatitude,
                            userLongitude = userLongitude,
                            onSubmitChargerDownReport = onSubmitChargerDownReport,
                            onSubmitWrongLocationReport = onSubmitWrongLocationReport,
                            onResolveReport = onResolveReport
                        )
                    }

                    3 -> {
                        if (!riderProfile.isSignedIn) {
                            CommunityAuthPromptCard(
                                onSignInClick = {
                                    GoogleAuthHelper.onGoogleSignInClicked(
                                        context = context,
                                        credentialManager = credentialManager,
                                        scope = coroutineScope,
                                        onAuthSuccess = { user ->
                                            onAuthSuccess(
                                                user.uid,
                                                user.displayName ?: "EV Rider",
                                                user.email ?: "",
                                                user.photoUrl?.toString()
                                            )
                                        },
                                        onAuthError = { msg ->
                                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                        }
                                    )
                                }
                            )
                        }

                        StationPhotosSection(
                            photos = photos,
                            currentUid = riderProfile.uid,
                            isSignedIn = riderProfile.isSignedIn,
                            isSubmitting = isSubmittingCommunityAction,
                            onUploadPhotoBase64 = onUploadPhotoBase64,
                            onDeletePhoto = onDeletePhoto
                        )
                    }
                }
            }
        }
    }
}
}

@Composable
private fun CommunityAuthPromptCard(onSignInClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "Google Sign-In Required for Community Sync",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
            Text(
                text = "Sign in with Google to view live community verifications, submit issue reports, or upload station photos.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
            )
            Button(
                onClick = onSignInClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .testTag("sheet_google_signin_button")
            ) {
                Text("Sign in with Google")
            }
        }
    }
}

@Composable
private fun OperatorIntegrationSection(
    station: ChargingStation,
    operatorProfile: com.example.data.model.ChargingOperatorProfile,
    summary: StationCommunitySummary?,
    onCallSupport: (String) -> Unit,
    onOpenPortal: (String) -> Unit,
    onNavigate: () -> Unit,
    onAddToRoute: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.ElectricBolt,
                        contentDescription = null,
                        tint = EVGreenPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = operatorProfile.displayName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
                Surface(
                    color = EVGreenPrimary.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = station.ocpiNetworkCode.ifBlank { operatorProfile.ocpiNetworkId },
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = EVGreenPrimary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Text(
                text = operatorProfile.roamingStatus,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OperatorInfoTile(
                    label = "Bays & Output",
                    value = "${station.bayCapacity} bays • ${station.powerKw.toInt()} kW",
                    modifier = Modifier.weight(1f)
                )
                OperatorInfoTile(
                    label = "Hours",
                    value = station.openingHours.ifBlank { "24/7" },
                    modifier = Modifier.weight(1f)
                )
            }

            OperatorInfoTile(
                label = "Authentication & Billing",
                value = "${station.authMethods.ifBlank { operatorProfile.sessionAuthMethods }} • ₹${station.costPerKwh}/kWh",
                modifier = Modifier.fillMaxWidth()
            )

            OperatorInfoTile(
                label = "Tariff & Roaming Note",
                value = operatorProfile.tariffNote,
                modifier = Modifier.fillMaxWidth()
            )

            if (summary != null && summary.totalConfirmations > 0) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.VerifiedUser,
                        contentDescription = null,
                        tint = StatusSafe,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Community status: ${summary.headlineStatus}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = StatusSafe
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (operatorProfile.supportPhone.isNotBlank()) {
                    OutlinedButton(
                        onClick = { onCallSupport(operatorProfile.supportPhone) },
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .testTag("operator_call_support_button")
                    ) {
                        Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Call NOC", fontSize = 12.sp)
                    }
                }
                OutlinedButton(
                    onClick = { onOpenPortal(operatorProfile.portalUrl) },
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .testTag("operator_portal_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Operator Portal", fontSize = 12.sp)
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onAddToRoute,
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Add to Route", fontSize = 12.sp)
                }
                OutlinedButton(
                    onClick = onNavigate,
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                ) {
                    Icon(Icons.Default.Navigation, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Navigate", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun OperatorInfoTile(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(
                text = label,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
            Text(
                text = value,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
private fun CommunityAvailabilitySection(
    station: ChargingStation,
    summary: StationCommunitySummary?,
    confirmations: List<StationConfirmation>,
    isSignedIn: Boolean,
    isSubmitting: Boolean,
    onSubmitAvailability: (AvailabilityStatus, String, String) -> Unit
) {
    var selectedStatus by remember(summary?.userVote) {
        mutableStateOf(summary?.userVote ?: AvailabilityStatus.WORKING)
    }
    var connectorUsed by remember(station.id) {
        mutableStateOf(station.connectorTypes.split(",").firstOrNull()?.trim().orEmpty())
    }
    var comment by remember { mutableStateOf("") }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Tally Summary
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Community-Confirmed Availability", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AvailabilityCountBadge(
                        label = "Working",
                        count = summary?.workingCount ?: 0,
                        color = StatusSafe,
                        modifier = Modifier.weight(1f)
                    )
                    AvailabilityCountBadge(
                        label = "Busy",
                        count = summary?.busyCount ?: 0,
                        color = StatusWarning,
                        modifier = Modifier.weight(1f)
                    )
                    AvailabilityCountBadge(
                        label = "Down",
                        count = summary?.notWorkingCount ?: 0,
                        color = StatusDanger,
                        modifier = Modifier.weight(1f)
                    )
                }

                summary?.latestConfirmationMillis?.let { ts ->
                    val formatted = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(ts))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Schedule,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp),
                            tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Last confirmed by ${summary.latestConfirmerName ?: "Rider"} at $formatted",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                }
            }
        }

        // Submit Verification Form
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Confirm Live Charger Status", fontWeight = FontWeight.Bold, fontSize = 14.sp)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AvailabilityStatus.entries.forEach { status ->
                        FilterChip(
                            selected = selectedStatus == status,
                            onClick = { selectedStatus = status },
                            label = {
                                Text(
                                    text = when (status) {
                                        AvailabilityStatus.WORKING -> "Working"
                                        AvailabilityStatus.BUSY -> "Busy"
                                        AvailabilityStatus.NOT_WORKING -> "Down"
                                    },
                                    fontSize = 12.sp
                                )
                            },
                            modifier = Modifier.testTag("availability_chip_${status.value}")
                        )
                    }
                }

                OutlinedTextField(
                    value = connectorUsed,
                    onValueChange = { connectorUsed = it },
                    label = { Text("Connector Tested") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = comment,
                    onValueChange = { comment = it },
                    label = { Text("Charging experience / queue note (optional)") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("availability_comment_input")
                )

                Button(
                    onClick = {
                        onSubmitAvailability(selectedStatus, connectorUsed, comment)
                        comment = ""
                    },
                    enabled = isSignedIn && !isSubmitting,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .testTag("confirm_availability_button")
                ) {
                    if (isSubmitting) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    } else {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Confirm Availability")
                    }
                }
            }
        }

        if (confirmations.isNotEmpty()) {
            Text(
                text = "Recent Rider Verifications (${confirmations.size})",
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp
            )
            confirmations.take(6).forEach { conf ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(conf.authorLabel, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                            Text(
                                text = conf.availabilityStatus.replace("_", " "),
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = when (conf.availabilityStatus) {
                                    AvailabilityStatus.WORKING.value -> StatusSafe
                                    AvailabilityStatus.BUSY.value -> StatusWarning
                                    else -> StatusDanger
                                }
                            )
                        }
                        if (conf.connectorUsed.isNotBlank() || conf.comment.isNotBlank()) {
                            Text(
                                text = listOf(conf.connectorUsed, conf.comment).filter { it.isNotBlank() }.joinToString(" • "),
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AvailabilityCountBadge(
    label: String,
    count: Int,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = color.copy(alpha = 0.14f),
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "$count", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = color)
            Text(text = label, fontSize = 11.sp, color = color)
        }
    }
}

@Composable
private fun ReportStationIssueSection(
    station: ChargingStation,
    reports: List<StationReport>,
    currentUid: String?,
    isSignedIn: Boolean,
    isSubmitting: Boolean,
    userLatitude: Double?,
    userLongitude: Double?,
    onSubmitChargerDownReport: (reason: String, notes: String) -> Unit,
    onSubmitWrongLocationReport: (reason: String, notes: String, lat: Double, lon: Double) -> Unit,
    onResolveReport: (StationReport) -> Unit
) {
    var category by remember { mutableStateOf(ReportCategory.CHARGER_DOWN) }
    var selectedReason by remember(category) {
        mutableStateOf(
            if (category == ReportCategory.CHARGER_DOWN) CHARGER_DOWN_REASONS.first()
            else WRONG_LOCATION_REASONS.first()
        )
    }
    var notes by remember { mutableStateOf("") }
    var latText by remember(station.id) { mutableStateOf(String.format(Locale.US, "%.5f", station.latitude)) }
    var lonText by remember(station.id) { mutableStateOf(String.format(Locale.US, "%.5f", station.longitude)) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Report Station Problem", fontWeight = FontWeight.Bold, fontSize = 14.sp)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = category == ReportCategory.CHARGER_DOWN,
                        onClick = { category = ReportCategory.CHARGER_DOWN },
                        leadingIcon = { Icon(Icons.Default.Build, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        label = { Text("Charger Not Working", fontSize = 12.sp) },
                        modifier = Modifier.testTag("report_category_down")
                    )
                    FilterChip(
                        selected = category == ReportCategory.WRONG_LOCATION,
                        onClick = { category = ReportCategory.WRONG_LOCATION },
                        leadingIcon = { Icon(Icons.Default.EditLocationAlt, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        label = { Text("Incorrect Location", fontSize = 12.sp) },
                        modifier = Modifier.testTag("report_category_location")
                    )
                }

                val reasons = if (category == ReportCategory.CHARGER_DOWN) {
                    CHARGER_DOWN_REASONS
                } else {
                    WRONG_LOCATION_REASONS
                }

                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(reasons) { reason ->
                        FilterChip(
                            selected = selectedReason == reason,
                            onClick = { selectedReason = reason },
                            label = { Text(reason, fontSize = 11.sp) }
                        )
                    }
                }

                if (category == ReportCategory.WRONG_LOCATION) {
                    if (userLatitude != null && userLongitude != null) {
                        OutlinedButton(
                            onClick = {
                                latText = String.format(Locale.US, "%.5f", userLatitude)
                                lonText = String.format(Locale.US, "%.5f", userLongitude)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                        ) {
                            Icon(Icons.Default.GpsFixed, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Use My Current GPS Pin", fontSize = 12.sp)
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = latText,
                            onValueChange = { latText = it },
                            label = { Text("Correct Latitude") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("report_lat_input"),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = lonText,
                            onValueChange = { lonText = it },
                            label = { Text("Correct Longitude") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("report_lon_input"),
                            singleLine = true
                        )
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = {
                        Text(
                            if (category == ReportCategory.CHARGER_DOWN) {
                                "Fault details (connector number, error code)"
                            } else {
                                "Landmark or entrance correction details"
                            }
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("report_notes_input")
                )

                Button(
                    onClick = {
                        if (category == ReportCategory.CHARGER_DOWN) {
                            onSubmitChargerDownReport(selectedReason, notes)
                        } else {
                            val parsedLat = latText.toDoubleOrNull() ?: station.latitude
                            val parsedLon = lonText.toDoubleOrNull() ?: station.longitude
                            onSubmitWrongLocationReport(selectedReason, notes, parsedLat, parsedLon)
                        }
                        notes = ""
                    },
                    enabled = isSignedIn && !isSubmitting,
                    colors = ButtonDefaults.buttonColors(containerColor = StatusDanger),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .testTag("submit_report_button")
                ) {
                    if (isSubmitting) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            color = MaterialTheme.colorScheme.onError,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(
                            if (category == ReportCategory.CHARGER_DOWN) Icons.Default.ErrorOutline else Icons.Default.WarningAmber,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            if (category == ReportCategory.CHARGER_DOWN) "Submit Fault Report" else "Submit Location Fix"
                        )
                    }
                }
            }
        }

        if (reports.isNotEmpty()) {
            Text(
                text = "Community Issue Reports (${reports.size})",
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp
            )
            reports.forEach { rep ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = rep.issueReason,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = if (rep.status == "resolved") StatusSafe else StatusDanger
                            )
                            Text(
                                text = if (rep.status == "resolved") "RESOLVED" else rep.reportCategory.replace("_", " "),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (rep.status == "resolved") StatusSafe else StatusWarning
                            )
                        }
                        if (rep.notes.isNotBlank()) {
                            Text(rep.notes, fontSize = 12.sp)
                        }
                        if (rep.reportCategory == ReportCategory.WRONG_LOCATION.value && rep.suggestedLat != 0.0) {
                            Text(
                                text = "Suggested Pin: ${String.format(Locale.US, "%.5f", rep.suggestedLat)}, ${String.format(Locale.US, "%.5f", rep.suggestedLon)}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Reported by ${rep.authorLabel}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                            )
                            if (rep.status != "resolved" && currentUid == rep.userId) {
                                TextButton(onClick = { onResolveReport(rep) }) {
                                    Text("Mark Fixed", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StationPhotosSection(
    photos: List<StationPhoto>,
    currentUid: String?,
    isSignedIn: Boolean,
    isSubmitting: Boolean,
    onUploadPhotoBase64: (caption: String, imageBase64: String) -> Unit,
    onDeletePhoto: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var caption by remember { mutableStateOf("") }
    var isProcessingImage by remember { mutableStateOf(false) }

    // Zero-permission Android Photo Picker (Google Play compliant)
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            isProcessingImage = true
            scope.launch {
                val encoded = StationPhotoHelper.encodeUriToCompressedBase64(context, uri)
                isProcessingImage = false
                encoded.onSuccess { base64 ->
                    onUploadPhotoBase64(caption.ifBlank { "Station bay photo" }, base64)
                    caption = ""
                }.onFailure { err ->
                    Toast.makeText(
                        context,
                        err.localizedMessage ?: "Unable to read photo",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Upload Station Photo", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(
                    text = "Share photos of charger bays, signage, parking entrance, or fault screens with fellow EV riders.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f)
                )

                OutlinedTextField(
                    value = caption,
                    onValueChange = { caption = it },
                    label = { Text("Photo caption (e.g., Right bay working 60 kW)") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("photo_caption_input"),
                    singleLine = true
                )

                Button(
                    onClick = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    enabled = isSignedIn && !isSubmitting && !isProcessingImage,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .testTag("upload_photo_button")
                ) {
                    if (isProcessingImage || isSubmitting) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            color = MaterialTheme.colorScheme.onPrimary,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Pick Photo & Upload")
                    }
                }
            }
        }

        if (photos.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.PhotoLibrary,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "No rider photos uploaded for this station yet.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
            }
        } else {
            photos.forEach { photo ->
                val decoded = remember(photo.imageBase64) {
                    StationPhotoHelper.decodeBase64ToBitmap(photo.imageBase64)
                }
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (decoded != null) {
                            Image(
                                bitmap = decoded.asImageBitmap(),
                                contentDescription = photo.caption.ifBlank { "Station photo" },
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(170.dp)
                                    .clip(RoundedCornerShape(10.dp))
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(80.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(MaterialTheme.colorScheme.surface),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("Photo preview unavailable", fontSize = 11.sp)
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = photo.caption.ifBlank { "Station bay photo" },
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = "Uploaded by ${photo.authorLabel}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                                )
                            }
                            if (currentUid == photo.userId && photo.id.isNotBlank()) {
                                IconButton(
                                    onClick = { onDeletePhoto(photo.id) },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Delete,
                                        contentDescription = "Delete Uploaded Photo",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
