package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ChargingCycle
import com.example.domain.ChargingTimeEstimator
import com.example.ui.theme.EVGreenPrimary

@Composable
fun LogChargingCycleDialog(
    vehicleName: String,
    defaultStationName: String,
    defaultStartPercent: Double,
    defaultEndPercent: Double,
    existingCycles: List<ChargingCycle>,
    onDismiss: () -> Unit,
    onSaveCycle: (stationName: String, startPercent: Double, endPercent: Double, durationMinutes: Int, chargerPowerKw: Double) -> Unit,
    onDeleteCycle: (String) -> Unit
) {
    var stationName by remember(defaultStationName) { mutableStateOf(defaultStationName) }
    var startPct by remember(defaultStartPercent) { mutableStateOf<Double?>(defaultStartPercent) }
    var endPct by remember(defaultEndPercent) { mutableStateOf<Double?>(defaultEndPercent) }
    var durationMinutes by remember { mutableStateOf<Double?>(45.0) }
    var chargerKw by remember { mutableStateOf<Double?>(3.3) }

    val validStart = (startPct ?: 0.0).coerceIn(0.0, 99.0)
    val validEnd = (endPct ?: 0.0).coerceIn(0.0, 100.0)
    val validMins = (durationMinutes ?: 0.0).toInt()
    val gained = (validEnd - validStart).coerceAtLeast(0.0)
    val canSave = gained > 0.5 && validMins > 0

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Timer, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text("Charging Cycle & Time", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = vehicleName,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                    )
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Log a previous charge session so the planner learns your real charging speed.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f)
                )

                OutlinedTextField(
                    value = stationName,
                    onValueChange = { stationName = it },
                    label = { Text("Charger / Location") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SmoothNumberField(
                        value = startPct,
                        onValueChange = { startPct = it },
                        label = "Start %",
                        suffix = "%",
                        minValue = 0.0,
                        maxValue = 99.0,
                        syncKey = "cycle_start_$defaultStartPercent",
                        modifier = Modifier.weight(1f)
                    )
                    SmoothNumberField(
                        value = endPct,
                        onValueChange = { endPct = it },
                        label = "End %",
                        suffix = "%",
                        minValue = 1.0,
                        maxValue = 100.0,
                        syncKey = "cycle_end_$defaultEndPercent",
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SmoothNumberField(
                        value = durationMinutes,
                        onValueChange = { durationMinutes = it },
                        label = "Time Taken",
                        suffix = "min",
                        allowDecimal = false,
                        minValue = 1.0,
                        maxValue = 2000.0,
                        syncKey = "cycle_mins",
                        modifier = Modifier.weight(1f)
                    )
                    SmoothNumberField(
                        value = chargerKw,
                        onValueChange = { chargerKw = it },
                        label = "Charger Power",
                        suffix = "kW",
                        minValue = 0.5,
                        maxValue = 350.0,
                        syncKey = "cycle_kw",
                        modifier = Modifier.weight(1f)
                    )
                }

                // Live Preview of learned speed
                if (canSave) {
                    val rate = gained / validMins.toDouble()
                    val fullTime = (100.0 / rate).toInt()
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                EVGreenPrimary.copy(alpha = 0.14f),
                                RoundedCornerShape(10.dp)
                            )
                            .padding(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Bolt,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Speed: ${String.format("%.2f", rate)} %/min • Full 0→100% ≈ ${ChargingTimeEstimator.formatDuration(fullTime)}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }

                if (existingCycles.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Previous Cycles (${existingCycles.size})",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                    )

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 140.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(existingCycles, key = { it.id }) { cycle ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                                )
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 10.dp, vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "${cycle.stationName} (${cycle.startPercent.toInt()}% → ${cycle.endPercent.toInt()}%)",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = "${ChargingTimeEstimator.formatDuration(cycle.durationMinutes)} • ${String.format("%.2f", cycle.percentPerMinute)} %/min",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    IconButton(
                                        onClick = { onDeleteCycle(cycle.id) },
                                        modifier = Modifier.size(48.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Delete,
                                            contentDescription = "Delete Cycle",
                                            tint = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                enabled = canSave,
                onClick = {
                    onSaveCycle(
                        stationName,
                        validStart,
                        validEnd,
                        validMins,
                        chargerKw ?: 3.3
                    )
                }
            ) {
                Text("Save Cycle")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}
