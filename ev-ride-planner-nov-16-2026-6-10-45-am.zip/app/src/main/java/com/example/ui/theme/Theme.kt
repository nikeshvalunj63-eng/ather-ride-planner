package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = EVGreenPrimary,
    onPrimary = EVGreenOnPrimary,
    primaryContainer = EVGreenContainer,
    onPrimaryContainer = EVGreenOnContainer,
    secondary = EVCyanSecondary,
    onSecondary = EVCyanOnSecondary,
    secondaryContainer = EVCyanContainer,
    onSecondaryContainer = EVCyanOnContainer,
    background = EVDarkBackground,
    surface = EVDarkSurface,
    surfaceVariant = EVDarkSurfaceVariant,
    onBackground = EVDarkOnBackground,
    onSurface = EVDarkOnSurface,
    onSurfaceVariant = EVDarkOnSurfaceVariant,
    error = StatusDanger,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF008744),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFA3F6C3),
    onPrimaryContainer = Color(0xFF00210E),
    secondary = Color(0xFF0277BD),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFB3E5FC),
    onSecondaryContainer = Color(0xFF001F2B),
    background = EVLightBackground,
    surface = EVLightSurface,
    surfaceVariant = EVLightSurfaceVariant,
    onBackground = EVLightOnBackground,
    onSurface = EVLightOnSurface,
    onSurfaceVariant = EVLightOnSurfaceVariant,
    error = StatusDanger,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
