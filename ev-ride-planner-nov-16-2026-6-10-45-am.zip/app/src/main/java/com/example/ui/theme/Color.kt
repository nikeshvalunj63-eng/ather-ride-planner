package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Electric Green Palette
val EVGreenPrimary = Color(0xFF00E676)
val EVGreenOnPrimary = Color(0xFF00391A)
val EVGreenContainer = Color(0xFF005228)
val EVGreenOnContainer = Color(0xFF6DFFA2)

val EVCyanSecondary = Color(0xFF00B0FF)
val EVCyanOnSecondary = Color(0xFF00344F)
val EVCyanContainer = Color(0xFF004B70)
val EVCyanOnContainer = Color(0xFFB3E5FC)

// Dark Theme Surfaces
val EVDarkBackground = Color(0xFF0A140F)
val EVDarkSurface = Color(0xFF101F18)
val EVDarkSurfaceVariant = Color(0xFF162B21)
val EVDarkCardBorder = Color(0xFF224233)
val EVDarkOnBackground = Color(0xFFE1F5EC)
val EVDarkOnSurface = Color(0xFFE1F5EC)
val EVDarkOnSurfaceVariant = Color(0xFF9EBAAD)

// Light Theme Surfaces
val EVLightBackground = Color(0xFFF2FBF6)
val EVLightSurface = Color(0xFFFFFFFF)
val EVLightSurfaceVariant = Color(0xFFE4F5EB)
val EVLightCardBorder = Color(0xFFCCE8D9)
val EVLightOnBackground = Color(0xFF0B1F15)
val EVLightOnSurface = Color(0xFF0B1F15)
val EVLightOnSurfaceVariant = Color(0xFF456153)

// Status / Battery Colors
val BatteryFull = Color(0xFF00E676)
val BatteryAdequate = Color(0xFF69F0AE)
val BatteryWarning = Color(0xFFFFB300)
val BatteryCritical = Color(0xFFFF3D00)
val BatteryDead = Color(0xFFD50000)

val StatusSafe = Color(0xFF00E676)
val StatusWarning = Color(0xFFFFB300)
val StatusDanger = Color(0xFFFF3D00)
