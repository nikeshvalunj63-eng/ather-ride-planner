package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BatteryCritical
import com.example.ui.theme.BatteryDead
import com.example.ui.theme.BatteryFull
import com.example.ui.theme.BatteryWarning

@Composable
fun BatteryBar(
    percentage: Double,
    modifier: Modifier = Modifier,
    reserveMargin: Double = 15.0,
    showLabel: Boolean = true
) {
    val clamped = percentage.coerceIn(0.0, 100.0).toFloat()
    val animatedProgress by animateFloatAsState(
        targetValue = clamped / 100f,
        label = "batteryProgress"
    )

    val barColor = when {
        clamped <= 0f -> BatteryDead
        clamped <= reserveMargin.toFloat() -> BatteryCritical
        clamped <= 35f -> BatteryWarning
        else -> BatteryFull
    }

    Column(modifier = modifier.fillMaxWidth()) {
        if (showLabel) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (clamped <= reserveMargin) Icons.Default.BatteryAlert else Icons.Default.BatteryChargingFull,
                        contentDescription = null,
                        tint = barColor,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${String.format("%.1f", percentage)}%",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = barColor
                    )
                }

                if (percentage < 0.0) {
                    Text(
                        text = "EXHAUSTED",
                        color = BatteryDead,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                } else if (clamped <= reserveMargin.toFloat()) {
                    Text(
                        text = "RESERVE BREACH (<${reserveMargin.toInt()}%)",
                        color = BatteryCritical,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
        }

        // Battery outer pill frame
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(12.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(MaterialTheme.colorScheme.surface)
                .border(
                    width = 1.dp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(6.dp)
                )
        ) {
            // Reserve Threshold Marker line
            val reserveFrac = (reserveMargin / 100.0).coerceIn(0.05, 0.40).toFloat()
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .width(2.dp)
                    .align(Alignment.CenterStart)
                    .padding(start = (reserveFrac * 280).dp) // visual indicator
                    .background(Color.White.copy(alpha = 0.4f))
            )

            // Dynamic progress fill
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(fraction = animatedProgress)
                    .clip(RoundedCornerShape(6.dp))
                    .background(barColor)
            )
        }
    }
}
