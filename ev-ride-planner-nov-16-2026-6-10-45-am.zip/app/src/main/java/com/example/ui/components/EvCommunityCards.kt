package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.EvStation
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ChargingExperience
import com.example.data.model.CommunityStation
import com.example.data.model.EvOwnerReview
import com.example.data.model.RangeReport
import com.example.data.model.TripRecommendation
import com.example.data.model.VerifiedRoute
import com.example.ui.theme.EVGreenPrimary
import com.example.ui.theme.StatusDanger
import com.example.ui.theme.StatusSafe
import com.example.ui.theme.StatusWarning

@Composable
private fun CommunityBadge(text: String, tint: Color) {
    Box(
        modifier = Modifier
            .background(tint.copy(alpha = 0.14f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = text,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = tint
        )
    }
}

@Composable
private fun OwnerDeleteButton(
    isOwner: Boolean,
    contentDescription: String,
    testTag: String,
    onDelete: () -> Unit
) {
    if (isOwner) {
        IconButton(
            onClick = onDelete,
            modifier = Modifier
                .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
                .testTag(testTag)
        ) {
            Icon(
                imageVector = Icons.Default.Delete,
                contentDescription = contentDescription,
                tint = StatusDanger
            )
        }
    }
}

@Composable
fun CommunityStationCard(
    station: CommunityStation,
    distanceKm: Double?,
    endorseCount: Int,
    isEndorsedByMe: Boolean,
    isOwner: Boolean,
    onAddToRoute: () -> Unit,
    onToggleEndorse: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("community_station_card_${station.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(station.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(
                        text = "${station.provider} • ${station.city} • Added by ${station.authorLabel}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                OwnerDeleteButton(
                    isOwner = isOwner,
                    contentDescription = "Delete Submitted Station",
                    testTag = "delete_community_station_${station.id}",
                    onDelete = onDelete
                )
            }

            if (station.address.isNotBlank()) {
                Text(
                    text = station.address,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CommunityBadge("${station.powerKw.toInt()} kW", MaterialTheme.colorScheme.primary)
                CommunityBadge("₹${station.costPerKwh.toInt()}/kWh", MaterialTheme.colorScheme.secondary)
                CommunityBadge("${station.bayCapacity} bays", StatusSafe)
                if (distanceKm != null) {
                    CommunityBadge("${String.format("%.1f", distanceKm)} km", EVGreenPrimary)
                }
            }

            Text(
                text = "Connectors: ${station.connectorTypes} • Hours: ${station.openingHours}",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (station.notes.isNotBlank()) {
                Text(station.notes, fontSize = 12.sp)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onAddToRoute,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 48.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add to Route", fontSize = 12.sp)
                }
                OutlinedButton(
                    onClick = onToggleEndorse,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.defaultMinSize(minHeight = 48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Verified,
                        contentDescription = "Verify Station",
                        tint = if (isEndorsedByMe) EVGreenPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isEndorsedByMe) "Verified ($endorseCount)" else "Verify ($endorseCount)",
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

@Composable
fun VerifiedRouteCard(
    route: VerifiedRoute,
    endorseCount: Int,
    isEndorsedByMe: Boolean,
    isOwner: Boolean,
    onLoadRoute: () -> Unit,
    onToggleEndorse: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("verified_route_card_${route.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(route.title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(
                        text = "${route.originCity} ➔ ${route.destinationCity} • by ${route.authorLabel}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                OwnerDeleteButton(
                    isOwner = isOwner,
                    contentDescription = "Delete Verified Route",
                    testTag = "delete_verified_route_${route.id}",
                    onDelete = onDelete
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CommunityBadge("${String.format("%.1f", route.totalDistanceKm)} km", MaterialTheme.colorScheme.primary)
                CommunityBadge("Arrival ${route.arrivalBatteryPercent.toInt()}%", StatusSafe)
                CommunityBadge("${route.chargingStopsCount} charge stops", MaterialTheme.colorScheme.secondary)
            }

            Text(
                text = "${route.vehicleName} (${route.vehicleCategory}) • Elev: ${route.elevationGainMeters.toInt()} m • ${route.weatherCondition}",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (route.stopsSummary.isNotBlank()) {
                Text(
                    text = "Stops: ${route.stopsSummary}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            if (route.notes.isNotBlank()) {
                Text(route.notes, fontSize = 12.sp)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onLoadRoute,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 48.dp)
                ) {
                    Icon(Icons.Default.Route, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Load in Planner", fontSize = 12.sp)
                }
                OutlinedButton(
                    onClick = onToggleEndorse,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.defaultMinSize(minHeight = 48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ThumbUp,
                        contentDescription = "Verify Route",
                        tint = if (isEndorsedByMe) EVGreenPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Helpful ($endorseCount)", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun RangeReportCard(
    report: RangeReport,
    isOwner: Boolean,
    onDelete: () -> Unit
) {
    val ratio = report.realWorldRatioPercent.coerceIn(0.0, 140.0)
    val ratioColor = when {
        ratio >= 85.0 -> StatusSafe
        ratio >= 68.0 -> StatusWarning
        else -> StatusDanger
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("range_report_card_${report.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(report.vehicleName, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(
                        text = "${report.vehicleCategory} • Reported by ${report.authorLabel}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                OwnerDeleteButton(
                    isOwner = isOwner,
                    contentDescription = "Delete Range Report",
                    testTag = "delete_range_report_${report.id}",
                    onDelete = onDelete
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Real Range: ${report.observedRealRangeKm.toInt()} km (Claimed ${report.claimedRangeKm.toInt()} km)",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = ratioColor
                )
                CommunityBadge("${String.format("%.0f", ratio)}% of claim", ratioColor)
            }

            LinearProgressIndicator(
                progress = { (ratio / 100.0).toFloat().coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = ratioColor,
                trackColor = MaterialTheme.colorScheme.surface
            )

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CommunityBadge("${String.format("%.1f", report.avgEfficiencyWhPerKm)} Wh/km", MaterialTheme.colorScheme.primary)
                CommunityBadge("${report.avgSpeedKmh.toInt()} km/h", MaterialTheme.colorScheme.secondary)
                CommunityBadge("${report.ridingOrAcMode} • ${report.weatherCondition}", MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Text(
                text = "Measured trip: ${String.format("%.1f", report.distanceDrivenKm)} km using ${String.format("%.0f", report.batteryUsedPercent)}% battery",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (report.notes.isNotBlank()) {
                Text(report.notes, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun EvOwnerReviewCard(
    review: EvOwnerReview,
    isOwner: Boolean,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("owner_review_card_${review.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(review.headline, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(
                        text = "${review.vehicleName} • ${review.authorLabel}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = null,
                        tint = StatusWarning,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("${review.rating}/5", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    OwnerDeleteButton(
                        isOwner = isOwner,
                        contentDescription = "Delete Owner Review",
                        testTag = "delete_owner_review_${review.id}",
                        onDelete = onDelete
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CommunityBadge(review.vehicleCategory, MaterialTheme.colorScheme.primary)
                CommunityBadge("${review.ownershipMonths} mo owned", MaterialTheme.colorScheme.secondary)
                CommunityBadge("${review.odometerKm} km", EVGreenPrimary)
            }

            Text(review.reviewText, fontSize = 13.sp)

            if (review.pros.isNotBlank()) {
                Text("Pros: ${review.pros}", fontSize = 12.sp, color = StatusSafe, fontWeight = FontWeight.Medium)
            }
            if (review.cons.isNotBlank()) {
                Text("Cons: ${review.cons}", fontSize = 12.sp, color = StatusWarning, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
fun ChargingExperienceCard(
    experience: ChargingExperience,
    isOwner: Boolean,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("charging_experience_card_${experience.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(experience.stationName, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(
                        text = "${experience.provider} • ${experience.vehicleName} • by ${experience.authorLabel}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Star, contentDescription = null, tint = StatusWarning, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("${experience.rating}/5", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    OwnerDeleteButton(
                        isOwner = isOwner,
                        contentDescription = "Delete Charging Experience",
                        testTag = "delete_charging_experience_${experience.id}",
                        onDelete = onDelete
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CommunityBadge("${experience.startPercent.toInt()}% ➔ ${experience.endPercent.toInt()}%", EVGreenPrimary)
                CommunityBadge("${experience.durationMinutes} min", MaterialTheme.colorScheme.primary)
                CommunityBadge("${String.format("%.1f", experience.peakPowerKw)} kW", MaterialTheme.colorScheme.secondary)
                CommunityBadge("Wait ${experience.waitTimeMinutes}m", if (experience.waitTimeMinutes > 10) StatusWarning else StatusSafe)
            }

            Text(
                text = "Plug: ${experience.connectorUsed} • Rate: ${String.format("%.2f", experience.chargeSpeedPercentPerMin)} %/min",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Text(experience.experienceNotes, fontSize = 12.sp)
        }
    }
}

@Composable
fun TripRecommendationCard(
    recommendation: TripRecommendation,
    endorseCount: Int,
    isEndorsedByMe: Boolean,
    isOwner: Boolean,
    onTryInPredictor: () -> Unit,
    onToggleEndorse: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("trip_recommendation_card_${recommendation.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(recommendation.title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(
                        text = "${recommendation.corridor} • Suggested by ${recommendation.authorLabel}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                OwnerDeleteButton(
                    isOwner = isOwner,
                    contentDescription = "Delete Trip Recommendation",
                    testTag = "delete_trip_recommendation_${recommendation.id}",
                    onDelete = onDelete
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CommunityBadge("${recommendation.totalDistanceKm.toInt()} km", MaterialTheme.colorScheme.primary)
                CommunityBadge(recommendation.recommendedCategory, MaterialTheme.colorScheme.secondary)
                CommunityBadge(recommendation.difficulty, if (recommendation.difficulty == "Challenging") StatusWarning else StatusSafe)
                CommunityBadge(recommendation.bestSeason, EVGreenPrimary)
            }

            Text(recommendation.highlights, fontSize = 12.sp)

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.EvStation, contentDescription = null, tint = EVGreenPrimary, modifier = Modifier.size(15.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Charging tip: ${recommendation.chargingTip}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilledTonalButton(
                    onClick = onTryInPredictor,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 48.dp)
                ) {
                    Icon(Icons.Default.ElectricBolt, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Simulate in Predictor", fontSize = 12.sp)
                }
                OutlinedButton(
                    onClick = onToggleEndorse,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.defaultMinSize(minHeight = 48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ThumbUp,
                        contentDescription = "Upvote Recommendation",
                        tint = if (isEndorsedByMe) EVGreenPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Helpful ($endorseCount)", fontSize = 12.sp)
                }
            }
        }
    }
}
