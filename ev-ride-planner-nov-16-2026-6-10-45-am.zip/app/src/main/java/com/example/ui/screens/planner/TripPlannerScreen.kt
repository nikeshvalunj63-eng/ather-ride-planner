package com.example.ui.screens.planner

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ElectricScooter
import androidx.compose.material.icons.filled.EvStation
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Garage
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardReturn
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.EvConnectorCatalog
import com.example.data.model.Stop
import com.example.data.model.StopType
import com.example.data.model.VehiclePreset
import com.example.domain.ChargingTimeEstimator
import com.example.ui.components.SmoothNumberField
import com.example.viewmodel.TripViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun TripPlannerScreen(viewModel: TripViewModel) {
    val state by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    var showAddDialog by remember { mutableStateOf(false) }
    var editingStopIndex by remember { mutableStateOf<Int?>(null) }
    var showSaveDialog by remember { mutableStateOf(false) }
    var showExportImportDialog by remember { mutableStateOf(false) }
    var importJsonText by remember { mutableStateOf("") }
    var tripSaveTitle by remember { mutableStateOf(state.title) }

    val vehicleSyncKey = "${state.selectedVehicleName}_${state.tripVersion}"

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.testTag("add_stop_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Route Stop")
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 640.dp)
                    .padding(horizontal = 16.dp)
                    .testTag("planner_lazy_column"),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp)
            ) {
                // Header + Prominent Save Button
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Route & Vehicle Planner",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "Smoothly edit vehicle specs, stops & legs",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            IconButton(onClick = { showExportImportDialog = true }) {
                                Icon(
                                    Icons.Default.Upload,
                                    contentDescription = "Export or Import JSON",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Button(
                                onClick = {
                                    tripSaveTitle = state.title
                                    showSaveDialog = true
                                },
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                                modifier = Modifier.testTag("save_trip_top_button")
                            ) {
                                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Save", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Editable Trip Title
                item {
                    OutlinedTextField(
                        value = state.title,
                        onValueChange = { viewModel.updateTitle(it) },
                        label = { Text("Trip Name") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("trip_title_input")
                    )
                }

                // Vehicle Presets Dropdown
                item {
                    var presetExpanded by remember { mutableStateOf(false) }

                    ExposedDropdownMenuBox(
                        expanded = presetExpanded,
                        onExpandedChange = { presetExpanded = !presetExpanded },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = "${state.selectedVehicleName} (${state.vehicleRange100.toInt()} km)",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("EV Preset (Scooter / Motorcycle / Car)") },
                            leadingIcon = {
                                Icon(
                                    Icons.Default.ElectricScooter,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = presetExpanded) },
                            modifier = Modifier
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable, enabled = true)
                                .fillMaxWidth()
                        )
                        ExposedDropdownMenu(
                            expanded = presetExpanded,
                            onDismissRequest = { presetExpanded = false }
                        ) {
                            VehiclePreset.PRESETS.forEach { preset ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(
                                                text = "${preset.name} • ${preset.category}",
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 13.sp
                                            )
                                            Text(
                                                text = "100% Range: ${preset.range100Km.toInt()} km | Pack: ${preset.batteryCapacityKWh} kWh",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                            )
                                        }
                                    },
                                    onClick = {
                                        viewModel.applyVehiclePreset(preset)
                                        presetExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Smooth Vehicle Specs, Speed, Connectors & Weather Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedTextField(
                                value = state.selectedVehicleName,
                                onValueChange = { viewModel.updateVehicleName(it) },
                                label = { Text("Vehicle Name (Garage)") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("planner_vehicle_name_input")
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                SmoothNumberField(
                                    value = state.vehicleRange100,
                                    onValueChange = { v -> if (v != null) viewModel.updateRange(v) },
                                    label = "100% Range",
                                    suffix = "km",
                                    minValue = 1.0,
                                    maxValue = 2000.0,
                                    syncKey = vehicleSyncKey,
                                    modifier = Modifier.weight(1f)
                                )
                                SmoothNumberField(
                                    value = state.startBattery,
                                    onValueChange = { v -> if (v != null) viewModel.updateStartBattery(v) },
                                    label = "Start Battery",
                                    suffix = "%",
                                    minValue = 0.0,
                                    maxValue = 100.0,
                                    syncKey = vehicleSyncKey,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                SmoothNumberField(
                                    value = state.reserveMargin,
                                    onValueChange = { v -> if (v != null) viewModel.updateReserveMargin(v) },
                                    label = "Min Reserve",
                                    suffix = "%",
                                    minValue = 0.0,
                                    maxValue = 60.0,
                                    syncKey = vehicleSyncKey,
                                    modifier = Modifier.weight(1f)
                                )
                                SmoothNumberField(
                                    value = state.batteryCapacityKWh,
                                    onValueChange = { v -> if (v != null) viewModel.updateCapacity(v) },
                                    label = "Pack Size",
                                    suffix = "kWh",
                                    minValue = 0.5,
                                    maxValue = 250.0,
                                    syncKey = vehicleSyncKey,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            SmoothNumberField(
                                value = state.averageSpeedKmh,
                                onValueChange = { v -> if (v != null) viewModel.updateAverageSpeed(v) },
                                label = "Cruising Speed (for Travel Time)",
                                suffix = "km/h",
                                minValue = 5.0,
                                maxValue = 200.0,
                                syncKey = vehicleSyncKey,
                                modifier = Modifier.fillMaxWidth()
                            )

                            // Multi-select Compatible Charger Connector Types
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "Compatible Charger Connectors (${state.compatibleConnectors.size} selected)",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    EvConnectorCatalog.ALL_CONNECTORS.forEach { connector ->
                                        val isSelected = state.compatibleConnectors.contains(connector)
                                        FilterChip(
                                            selected = isSelected,
                                            onClick = { viewModel.toggleConnectorType(connector) },
                                            leadingIcon = if (isSelected) {
                                                {
                                                    Icon(
                                                        Icons.Default.Check,
                                                        contentDescription = null,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                }
                                            } else null,
                                            label = { Text(connector, fontSize = 11.sp) }
                                        )
                                    }
                                }
                            }

                            // Weather & Terrain modifier
                            var weatherExpanded by remember { mutableStateOf(false) }
                            ExposedDropdownMenuBox(
                                expanded = weatherExpanded,
                                onExpandedChange = { weatherExpanded = !weatherExpanded },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                OutlinedTextField(
                                    value = state.weatherCondition,
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("Weather & Terrain Condition") },
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = weatherExpanded) },
                                    modifier = Modifier
                                        .menuAnchor(MenuAnchorType.PrimaryNotEditable, enabled = true)
                                        .fillMaxWidth()
                                )
                                ExposedDropdownMenu(
                                    expanded = weatherExpanded,
                                    onDismissRequest = { weatherExpanded = false }
                                ) {
                                    listOf(
                                        "Clear",
                                        "Rain / Headwind",
                                        "Extreme Cold (<5°C)",
                                        "Hot (>35°C)",
                                        "Hilly / Elevation"
                                    ).forEach { option ->
                                        DropdownMenuItem(
                                            text = { Text(option) },
                                            onClick = {
                                                viewModel.updateWeather(option)
                                                weatherExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            FilledTonalButton(
                                onClick = { viewModel.saveCurrentVehicleToGarage() },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .defaultMinSize(minHeight = 48.dp)
                                    .testTag("planner_save_to_garage_button")
                            ) {
                                Icon(Icons.Default.Garage, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Save Vehicle to Garage")
                            }
                        }
                    }
                }

                // Charging Time Estimator & Previous Cycle History Card
                item {
                    val summary = state.calculationSummary
                    val timeToFullFromStart = if (state.startBattery < 100.0 && summary.chargingSpeedPercentPerMin > 0.0) {
                        kotlin.math.ceil((100.0 - state.startBattery) / summary.chargingSpeedPercentPerMin).toInt().coerceAtLeast(1)
                    } else 0

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.Timer,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (timeToFullFromStart > 0) {
                                            "Charge ${state.startBattery.toInt()}%→100%: ~${ChargingTimeEstimator.formatDuration(timeToFullFromStart)}"
                                        } else {
                                            "Full Charge (0→100%): ~${ChargingTimeEstimator.formatDuration(summary.estimatedFullChargeMinutes)}"
                                        },
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                }
                                Spacer(modifier = Modifier.height(3.dp))
                                Text(
                                    text = if (summary.isChargingTimeFromHistory) {
                                        "Learned ${String.format("%.2f", summary.chargingSpeedPercentPerMin)} %/min from ${summary.chargingCyclesUsed} previous cycle(s)"
                                    } else {
                                        "Using ${String.format("%.2f", summary.chargingSpeedPercentPerMin)} %/min default • Log past cycle"
                                    },
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            FilledTonalButton(
                                onClick = {
                                    viewModel.openLogCycleDialog(
                                        stationName = "Home Charger",
                                        startPercent = if (state.startBattery < 95.0) state.startBattery else 20.0,
                                        endPercent = 100.0
                                    )
                                },
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier.testTag("planner_log_cycle_button")
                            ) {
                                Text("Log Cycle", fontSize = 12.sp)
                            }
                        }
                    }
                }

                // Stops Section Header with Round Trip & Reset Home shortcuts
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Route Stops (${state.stops.size})",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            TextButton(onClick = { viewModel.resetToHomeOnly() }) {
                                Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Home Only", fontSize = 12.sp)
                            }
                            if (state.stops.size >= 2) {
                                TextButton(onClick = { viewModel.createReturnTrip() }) {
                                    Icon(Icons.Default.KeyboardReturn, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Round Trip", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }

                // Stop Items List
                itemsIndexed(
                    items = state.stops,
                    key = { _, stop -> stop.id }
                ) { index, stop ->
                    val nextStop = state.stops.getOrNull(index + 1)
                    val stopSyncKey = "${stop.id}_${state.tripVersion}"

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    val icon = when (stop.type) {
                                        StopType.HOME -> Icons.Default.Home
                                        StopType.CHARGING_STATION -> Icons.Default.EvStation
                                        StopType.DESTINATION -> Icons.Default.Flag
                                    }
                                    Icon(
                                        icon,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(22.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = "${index + 1}. ${stop.name}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp
                                        )
                                        Text(
                                            text = stop.type.name.replace("_", " "),
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }

                                Row {
                                    IconButton(onClick = { editingStopIndex = index }) {
                                        Icon(
                                            Icons.Default.Edit,
                                            contentDescription = "Edit Stop",
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    if (index > 0) {
                                        IconButton(onClick = { viewModel.moveStop(index, index - 1) }) {
                                            Icon(Icons.Default.ArrowUpward, contentDescription = "Move Up")
                                        }
                                    }
                                    if (index < state.stops.size - 1) {
                                        IconButton(onClick = { viewModel.moveStop(index, index + 1) }) {
                                            Icon(Icons.Default.ArrowDownward, contentDescription = "Move Down")
                                        }
                                    }
                                    if (state.stops.size > 1) {
                                        IconButton(onClick = { viewModel.deleteStop(index) }) {
                                            Icon(
                                                Icons.Default.Delete,
                                                contentDescription = "Delete Stop",
                                                tint = MaterialTheme.colorScheme.error
                                            )
                                        }
                                    }
                                }
                            }

                            // Leg Distance to next stop (all except final stop)
                            if (nextStop != null) {
                                Spacer(modifier = Modifier.height(10.dp))
                                SmoothNumberField(
                                    value = stop.distanceToNextKm,
                                    onValueChange = { dist ->
                                        viewModel.updateStop(
                                            index,
                                            stop.copy(distanceToNextKm = (dist ?: 0.0).coerceAtLeast(0.0))
                                        )
                                    },
                                    label = "Distance to ${nextStop.name}",
                                    suffix = "km",
                                    showZeroAsEmpty = true,
                                    placeholder = "Enter km",
                                    minValue = 0.0,
                                    syncKey = stopSyncKey,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }

                            // Charging target and actual charging inputs (Home / Charging Station)
                            if (stop.type == StopType.CHARGING_STATION || stop.type == StopType.HOME) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    SmoothNumberField(
                                        value = stop.targetBatteryAfterChargePercent,
                                        onValueChange = { target ->
                                            if (target != null) {
                                                viewModel.updateStop(
                                                    index,
                                                    stop.copy(targetBatteryAfterChargePercent = target.coerceIn(0.0, 100.0))
                                                )
                                            }
                                        },
                                        label = if (index == 0 && stop.type == StopType.HOME) "Home Charge" else "Target Charge",
                                        suffix = "%",
                                        minValue = 0.0,
                                        maxValue = 100.0,
                                        syncKey = stopSyncKey,
                                        modifier = Modifier.weight(1f)
                                    )

                                    SmoothNumberField(
                                        value = stop.actualChargedBatteryPercent,
                                        onValueChange = { actual ->
                                            viewModel.updateActualChargedBattery(index, actual)
                                        },
                                        label = "Actual Charge",
                                        suffix = "%",
                                        placeholder = "Optional",
                                        minValue = 0.0,
                                        maxValue = 100.0,
                                        syncKey = stopSyncKey,
                                        modifier = Modifier.weight(1f)
                                    )
                                }

                                // Show estimated charging duration at this stop based on previous cycle speed
                                val arrivingSegment = state.calculationSummary.segments.getOrNull(index - 1)
                                if (arrivingSegment != null && arrivingSegment.chargingMinutes > 0) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "⏱ Est. charge time: ~${ChargingTimeEstimator.formatDuration(arrivingSegment.chargingMinutes)} (${arrivingSegment.arrivalBatteryPercent.coerceAtLeast(0.0).toInt()}% → ${arrivingSegment.departureBatteryPercent.toInt()}%)",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.weight(1f)
                                        )
                                        TextButton(
                                            onClick = {
                                                viewModel.openLogCycleDialog(
                                                    stationName = stop.name,
                                                    startPercent = arrivingSegment.arrivalBatteryPercent.coerceIn(0.0, 99.0),
                                                    endPercent = stop.actualChargedBatteryPercent ?: stop.targetBatteryAfterChargePercent
                                                )
                                            },
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                        ) {
                                            Text("Log Time", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Helpful prompt when only Home exists + Primary Save Trip CTA at bottom
                item {
                    if (state.stops.size == 1) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                            )
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "Default Home stop ready at 100% charge",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "Tap '+ Add Stop' below or pick a nearby charger from the Stations tab within 100 km of your live location.",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f)
                                )
                                Button(
                                    onClick = { showAddDialog = true },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Add Destination or Charging Stop")
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        FilledTonalButton(
                            onClick = {
                                tripSaveTitle = state.title
                                showSaveDialog = true
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("save_trip_bottom_button")
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (state.currentTripId == null) "Save Trip" else "Update Saved Trip")
                        }

                        OutlinedButton(
                            onClick = { showAddDialog = true },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Add Stop")
                        }
                    }
                }
            }
        }
    }

    // Add Stop Dialog
    if (showAddDialog) {
        val lastStop = state.stops.lastOrNull()
        var newName by remember { mutableStateOf("") }
        var newType by remember {
            mutableStateOf(
                if (state.stops.size <= 1) StopType.DESTINATION else StopType.CHARGING_STATION
            )
        }
        var newDistanceFromPrev by remember { mutableStateOf<Double?>(25.0) }
        var newTargetCharge by remember { mutableStateOf<Double?>(90.0) }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Add Route Stop") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        label = { Text("Stop Name (e.g. Lonavala / City Hub)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        StopType.values().forEach { type ->
                            val shortLabel = when (type) {
                                StopType.HOME -> "Home"
                                StopType.CHARGING_STATION -> "Charger"
                                StopType.DESTINATION -> "Dest"
                            }
                            FilterChip(
                                selected = newType == type,
                                onClick = {
                                    newType = type
                                    if (type == StopType.HOME) newTargetCharge = 100.0
                                },
                                label = { Text(shortLabel, fontSize = 12.sp) }
                            )
                        }
                    }

                    SmoothNumberField(
                        value = newDistanceFromPrev,
                        onValueChange = { newDistanceFromPrev = it },
                        label = "Distance from ${lastStop?.name ?: "previous stop"}",
                        suffix = "km",
                        minValue = 0.0,
                        syncKey = "add_dist",
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (newType == StopType.CHARGING_STATION || newType == StopType.HOME) {
                        SmoothNumberField(
                            value = newTargetCharge,
                            onValueChange = { newTargetCharge = it },
                            label = "Target Battery After Charge",
                            suffix = "%",
                            minValue = 10.0,
                            maxValue = 100.0,
                            syncKey = "add_charge",
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    modifier = Modifier.testTag("confirm_add_stop_button"),
                    onClick = {
                        val finalName = newName.trim().ifBlank {
                            when (newType) {
                                StopType.HOME -> "Home Return"
                                StopType.CHARGING_STATION -> "Charging Stop"
                                StopType.DESTINATION -> "Destination"
                            }
                        }
                        viewModel.addStop(
                            name = finalName,
                            type = newType,
                            distanceFromPreviousKm = newDistanceFromPrev ?: 0.0,
                            targetCharge = newTargetCharge ?: 90.0
                        )
                        showAddDialog = false
                    }
                ) {
                    Text("Add Stop")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Edit Stop Dialog (smooth full editing of Name, Type, Distance, Target Charge)
    editingStopIndex?.let { idx ->
        val stop = state.stops.getOrNull(idx)
        if (stop != null) {
            val nextStop = state.stops.getOrNull(idx + 1)
            var editName by remember(stop.id) { mutableStateOf(stop.name) }
            var editType by remember(stop.id) { mutableStateOf(stop.type) }
            var editDist by remember(stop.id) { mutableStateOf<Double?>(stop.distanceToNextKm) }
            var editTargetCharge by remember(stop.id) { mutableStateOf<Double?>(stop.targetBatteryAfterChargePercent) }

            AlertDialog(
                onDismissRequest = { editingStopIndex = null },
                title = { Text("Edit Stop #${idx + 1}") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = editName,
                            onValueChange = { editName = it },
                            label = { Text("Stop Name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            StopType.values().forEach { type ->
                                val shortLabel = when (type) {
                                    StopType.HOME -> "Home"
                                    StopType.CHARGING_STATION -> "Charger"
                                    StopType.DESTINATION -> "Dest"
                                }
                                FilterChip(
                                    selected = editType == type,
                                    onClick = { editType = type },
                                    label = { Text(shortLabel, fontSize = 12.sp) }
                                )
                            }
                        }

                        if (nextStop != null) {
                            SmoothNumberField(
                                value = editDist,
                                onValueChange = { editDist = it },
                                label = "Distance to ${nextStop.name}",
                                suffix = "km",
                                minValue = 0.0,
                                syncKey = "edit_${stop.id}",
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        if (editType == StopType.CHARGING_STATION || editType == StopType.HOME) {
                            var chargeChipVersion by remember(stop.id) { mutableStateOf(0) }
                            SmoothNumberField(
                                value = editTargetCharge,
                                onValueChange = { editTargetCharge = it },
                                label = "Target Charge",
                                suffix = "%",
                                minValue = 0.0,
                                maxValue = 100.0,
                                syncKey = "edit_charge_${stop.id}_$chargeChipVersion",
                                modifier = Modifier.fillMaxWidth()
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf(80.0, 90.0, 100.0).forEach { pct ->
                                    FilterChip(
                                        selected = editTargetCharge == pct,
                                        onClick = {
                                            editTargetCharge = pct
                                            chargeChipVersion++
                                        },
                                        label = { Text("${pct.toInt()}%", fontSize = 12.sp) }
                                    )
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.updateStop(
                                idx,
                                stop.copy(
                                    name = editName.trim().ifBlank { stop.name },
                                    type = editType,
                                    distanceToNextKm = (editDist ?: 0.0).coerceAtLeast(0.0),
                                    targetBatteryAfterChargePercent = (editTargetCharge ?: stop.targetBatteryAfterChargePercent).coerceIn(0.0, 100.0)
                                )
                            )
                            editingStopIndex = null
                        }
                    ) {
                        Text("Apply")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { editingStopIndex = null }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }

    // Save Dialog
    if (showSaveDialog) {
        val isExistingSaved = state.currentTripId != null
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = { Text(if (isExistingSaved) "Save / Update Trip Plan" else "Save Trip Plan") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = tripSaveTitle,
                        onValueChange = { tripSaveTitle = it },
                        label = { Text("Trip Title") },
                        placeholder = { Text("e.g. Pune to Lonavala Ride") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (isExistingSaved) {
                        Text(
                            text = "You are editing a saved trip. You can update it or save as a new copy.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (isExistingSaved) {
                        OutlinedButton(
                            onClick = {
                                viewModel.saveCurrentTrip(tripSaveTitle, saveAsNew = true)
                                showSaveDialog = false
                            }
                        ) {
                            Text("Save Copy")
                        }
                    }
                    Button(
                        onClick = {
                            viewModel.saveCurrentTrip(tripSaveTitle, saveAsNew = false)
                            showSaveDialog = false
                        }
                    ) {
                        Text(if (isExistingSaved) "Update" else "Save Trip")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showSaveDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Export / Import Dialog
    if (showExportImportDialog) {
        var mode by remember { mutableStateOf("export") }
        val exportedJson = remember(state.stops, state.title) { viewModel.exportTripAsJson() }

        AlertDialog(
            onDismissRequest = { showExportImportDialog = false },
            title = { Text("Export & Import Route") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        FilterChip(
                            selected = mode == "export",
                            onClick = { mode = "export" },
                            label = { Text("Export Plan") }
                        )
                        FilterChip(
                            selected = mode == "import",
                            onClick = { mode = "import" },
                            label = { Text("Import Plan") }
                        )
                    }

                    if (mode == "export") {
                        Text(
                            text = "Copy the JSON below or share it to import on another device:",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                        OutlinedTextField(
                            value = exportedJson,
                            onValueChange = {},
                            readOnly = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                        )
                        Button(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("EV Trip JSON", exportedJson)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "JSON copied to clipboard!", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Copy to Clipboard")
                        }
                    } else {
                        Text(
                            text = "Paste a valid EV Trip JSON string below:",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                        OutlinedTextField(
                            value = importJsonText,
                            onValueChange = { importJsonText = it },
                            placeholder = { Text("{ \"title\": ... }") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                        )
                        Button(
                            onClick = {
                                val success = viewModel.importTripFromJson(importJsonText)
                                if (success) {
                                    showExportImportDialog = false
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            enabled = importJsonText.isNotBlank()
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Load Imported Plan")
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showExportImportDialog = false }) {
                    Text("Close")
                }
            }
        )
    }
}
