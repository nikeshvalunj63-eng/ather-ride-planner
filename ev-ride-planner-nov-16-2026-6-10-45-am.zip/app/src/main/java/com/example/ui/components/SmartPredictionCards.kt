package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.EvStation
import androidx.compose.material.icons.filled.Functions
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ChargingStation
import com.example.data.model.PredictionSafetyStatus
import com.example.data.model.SmartPredictionInput
import com.example.data.model.SmartPredictionResult
import com.example.data.model.TripTelemetryRecord
import com.example.domain.ChargingTimeEstimator
import com.example.ui.theme.EVGreenPrimary
import com.example.ui.theme.StatusDanger
import com.example.ui.theme.StatusSafe
import com.example.ui.theme.StatusWarning
import java.util.Locale

@Composable
fun PredictionOutputsHeroCard(
    input: SmartPredictionInput,
    result: SmartPredictionResult
) {
    val statusColor = when (result.safetyStatus) {
        PredictionSafetyStatus.SAFE -> StatusSafe
        PredictionSafetyStatus.LOW_RESERVE -> StatusWarning
        PredictionSafetyStatus.CRITICAL -> StatusDanger
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("prediction_output_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.ElectricBolt,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Predicted Arrival Battery",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(statusColor.copy(alpha = 0.16f))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = result.safetyStatus.label,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = statusColor
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    text = "${String.format(Locale.US, "%.1f", result.expectedArrivalBatteryPercent)}%",
                    fontSize = 36.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = statusColor
                )
                Column(horizontalAlignment = Alignment.End) {
                    val marginPrefix = if (result.safetyMarginPercent >= 0.0) "+" else ""
                    Text(
                        text = "Safety Margin: $marginPrefix${String.format(Locale.US, "%.1f", result.safetyMarginPercent)}%",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = statusColor
                    )
                    Text(
                        text = "Reserve target: ${input.reserveMarginPercent.toInt()}% • ~${ChargingTimeEstimator.formatDuration(result.estimatedTravelMinutes)} ride",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            BatteryBar(
                percentage = result.clampedArrivalBatteryPercent,
                reserveMargin = input.reserveMarginPercent
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                PredictionMiniMetric(
                    label = "Energy Used",
                    value = "${String.format(Locale.US, "%.2f", result.energyConsumedKwh)} kWh",
                    subtitle = "${String.format(Locale.US, "%.1f", result.effectiveWhPerKm)} Wh/km",
                    modifier = Modifier.weight(1f)
                )
                PredictionMiniMetric(
                    label = "Consumption",
                    value = "-${String.format(Locale.US, "%.1f", result.energyConsumedPercent)}%",
                    subtitle = "${String.format(Locale.US, "%.0f", input.distanceKm)} km leg",
                    modifier = Modifier.weight(1f)
                )
                PredictionMiniMetric(
                    label = "Surplus Range",
                    value = "${if (result.surplusDistanceKm >= 0) "+" else ""}${String.format(Locale.US, "%.1f", result.surplusDistanceKm)} km",
                    subtitle = "Safe max ${String.format(Locale.US, "%.0f", result.recommendedChargingPoint.safeMaxReachKm)} km",
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun PredictionMiniMetric(
    label: String,
    value: String,
    subtitle: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.75f))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = subtitle,
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun RecommendedChargingPointCard(
    result: SmartPredictionResult,
    onAddStationToRoute: (ChargingStation) -> Unit,
    onBrowseStations: () -> Unit
) {
    val rec = result.recommendedChargingPoint
    val accent = if (rec.actionRequired) StatusWarning else StatusSafe

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("recommended_charging_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = if (rec.actionRequired) Icons.Default.Warning else Icons.Default.EvStation,
                        contentDescription = null,
                        tint = accent,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Recommended Charging Point",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(accent.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = if (rec.actionRequired) "STOP ADVISED" else "OPTIONAL BACKUP",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = accent
                    )
                }
            }

            Text(
                text = rec.headline,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Text(
                text = rec.detail,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val station = rec.station
                if (station != null) {
                    Button(
                        onClick = { onAddStationToRoute(station) },
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 48.dp)
                            .testTag("recommended_station_action_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (rec.actionRequired) {
                                "Add Stop (→ ${rec.recommendedTargetChargePercent.toInt()}%)"
                            } else {
                                "Add Backup Charger"
                            },
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    FilledTonalButton(
                        onClick = onBrowseStations,
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 48.dp)
                            .testTag("recommended_station_action_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.EvStation,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Find Compatible Stations", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun MathBreakdownCard(
    input: SmartPredictionInput,
    result: SmartPredictionResult
) {
    val b = result.breakdown
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("math_breakdown_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Functions,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Transparent Mathematical Model",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(10.dp)
            ) {
                Text(
                    text = b.formulaSummary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            BreakdownRow("Base distance demand", b.baseDriveWh)
            BreakdownRow("Aerodynamic speed (${input.speedKmh.toInt()} km/h)", b.speedDeltaWh)
            if (input.isTwoWheeler) {
                BreakdownRow("Riding mode (${input.ridingMode.label})", b.ridingModeDeltaWh)
            } else {
                BreakdownRow("Cabin AC auxiliary (${input.acUsageMode.label})", b.acAuxiliaryWh)
            }
            BreakdownRow("Payload mass (${input.payloadKg.toInt()} kg)", b.payloadDeltaWh)
            BreakdownRow("Weather (${input.weatherCondition})", b.weatherDeltaWh)
            BreakdownRow(
                label = if (input.elevationGainMeters >= 0) {
                    "Elevation climb (+${input.elevationGainMeters.toInt()} m)"
                } else {
                    "Downhill regen (${input.elevationGainMeters.toInt()} m)"
                },
                deltaWh = b.elevationDeltaWh
            )
            if (result.mlCalibrationStatus.isMlActive) {
                BreakdownRow(
                    label = "ML residual calibration (${result.mlCalibrationStatus.learnedScaleFactor}x)",
                    deltaWh = b.mlResidualAdjustmentWh
                )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Total Predicted Energy",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Text(
                    text = "${String.format(Locale.US, "%.0f", b.totalWh)} Wh (${String.format(Locale.US, "%.2f", result.energyConsumedKwh)} kWh)",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
private fun BreakdownRow(label: String, deltaWh: Double) {
    val sign = if (deltaWh > 0.5) "+" else ""
    val color = when {
        deltaWh < -1.0 -> EVGreenPrimary
        deltaWh > 200.0 -> StatusWarning
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            text = "$sign${String.format(Locale.US, "%.0f", deltaWh)} Wh",
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = color
        )
    }
}

@Composable
fun MlCalibrationCard(
    result: SmartPredictionResult,
    useMlIfReady: Boolean,
    records: List<TripTelemetryRecord>,
    onToggleMlCalibration: (Boolean) -> Unit,
    onOpenLogOutcomeDialog: () -> Unit,
    onDeleteRecord: (String) -> Unit
) {
    val cal = result.mlCalibrationStatus
    val progress = (cal.reliableTripsCount.toFloat() / cal.requiredTripsForMl.toFloat()).coerceIn(0f, 1f)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("ml_calibration_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = if (cal.isMlActive) Icons.Default.AutoAwesome else Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = if (cal.isMlReady) EVGreenPrimary else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = cal.statusHeadline,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (cal.isMlReady) {
                    Switch(
                        checked = useMlIfReady,
                        onCheckedChange = onToggleMlCalibration,
                        modifier = Modifier.testTag("ml_calibration_switch")
                    )
                }
            }

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = if (cal.isMlReady) EVGreenPrimary else MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surface
            )

            Text(
                text = if (!cal.isMlReady) {
                    "Currently running strictly on the deterministic physics model. Log ${cal.requiredTripsForMl - cal.reliableTripsCount} more reliable completed ride(s) to unlock on-device ML residual calibration."
                } else {
                    "Collected ${cal.reliableTripsCount} reliable trips (Avg error: ${cal.meanAbsoluteErrorPercent ?: 0.0}%). Ridge regression learns your personal riding factor (${cal.learnedScaleFactor}x) over the physics baseline."
                },
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            FilledTonalButton(
                onClick = onOpenLogOutcomeDialog,
                modifier = Modifier
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = 48.dp)
                    .testTag("log_actual_trip_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Log Actual Ride Outcome (${cal.reliableTripsCount}/${cal.requiredTripsForMl})", fontWeight = FontWeight.SemiBold)
            }

            if (records.isNotEmpty()) {
                HorizontalDivider()
                Text(
                    text = "Recent Logged Rides (${records.size})",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                records.take(5).forEach { record ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${record.distanceKm.toInt()} km • Actual -${String.format(Locale.US, "%.1f", record.actualConsumedPercent)}% (Math -${String.format(Locale.US, "%.1f", record.mathPredictedPercent)}%)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "${record.vehicleName} • ${record.speedKmh.toInt()} km/h • ${record.weatherCondition}",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(
                            onClick = { onDeleteRecord(record.id) },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete trip log",
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
