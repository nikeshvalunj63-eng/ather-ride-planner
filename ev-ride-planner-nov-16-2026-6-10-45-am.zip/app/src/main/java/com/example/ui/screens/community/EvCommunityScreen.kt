package com.example.ui.screens.community

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.EvStation
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.RateReview
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.remote.EvCommunityRepository
import com.example.data.remote.StationCommunityRepository
import com.example.domain.GeoUtils
import com.example.ui.components.ChargingExperienceCard
import com.example.ui.components.CommunityStationCard
import com.example.ui.components.EvOwnerReviewCard
import com.example.ui.components.RangeReportCard
import com.example.ui.components.ShareChargingExperienceDialog
import com.example.ui.components.ShareVerifiedRouteDialog
import com.example.ui.components.SubmitCommunityStationDialog
import com.example.ui.components.SubmitEvOwnerReviewDialog
import com.example.ui.components.SubmitRangeReportDialog
import com.example.ui.components.SubmitTripRecommendationDialog
import com.example.ui.components.TripRecommendationCard
import com.example.ui.components.VerifiedRouteCard
import com.example.viewmodel.TripViewModel

private data class CommunitySectionTab(
    val title: String,
    val ctaLabel: String,
    val icon: ImageVector
)

private val COMMUNITY_TABS = listOf(
    CommunitySectionTab("Stations", "Submit Charger", Icons.Default.EvStation),
    CommunitySectionTab("Routes", "Share Route", Icons.Default.Route),
    CommunitySectionTab("Range", "Post Range", Icons.Default.Speed),
    CommunitySectionTab("Reviews", "Write Review", Icons.Default.RateReview),
    CommunitySectionTab("Charging", "Log Session", Icons.Default.Bolt),
    CommunitySectionTab("Trips", "Recommend Trip", Icons.Default.Explore)
)

@Composable
fun EvCommunityScreen(
    viewModel: TripViewModel,
    onBack: () -> Unit,
    onRouteLoadedToPlanner: () -> Unit = {},
    onOpenPredictor: () -> Unit = {}
) {
    BackHandler { onBack() }

    val state by viewModel.uiState.collectAsState()
    val selectedTab = state.selectedCommunityTab.coerceIn(0, COMMUNITY_TABS.lastIndex)
    var searchQuery by remember { mutableStateOf("") }
    var activeSubmitDialogTab by remember { mutableStateOf<Int?>(null) }

    val currentUid = state.riderProfile.uid.orEmpty()
    val endorsements = state.communityEndorsements

    fun endorsementStats(type: String, docId: String): Pair<Int, Boolean> {
        val cleanId = StationCommunityRepository.sanitizeId(docId)
        val matching = endorsements.filter { it.targetType == type && it.targetId == cleanId }
        return matching.size to (currentUid.isNotBlank() && matching.any { it.userId == currentUid })
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 640.dp)
                .testTag("ev_community_lazy_column"),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 88.dp)
        ) {
            item(key = "community_header") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier
                                .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
                                .testTag("community_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back to Dashboard"
                            )
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Groups,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "EV Community",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = "Chargers, routes, range reports & EV insights",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Button(
                        onClick = {
                            if (state.riderProfile.isSignedIn) {
                                activeSubmitDialogTab = selectedTab
                            } else {
                                viewModel.setGoogleSignInDialogVisible(true)
                            }
                        },
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        modifier = Modifier
                            .defaultMinSize(minHeight = 48.dp)
                            .testTag("community_share_cta_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(COMMUNITY_TABS[selectedTab].ctaLabel, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            // Google Sign-In Gate Card when signed out
            if (!state.riderProfile.isSignedIn) {
                item(key = "community_signin_prompt") {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("community_signin_prompt_card"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AccountCircle,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Sign in with Google to Join EV Community",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }
                            Text(
                                text = "View live rider-submitted chargers, verified routes, real-world range reports, owner reviews, charging logs, and trip picks.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Button(
                                onClick = { viewModel.setGoogleSignInDialogVisible(true) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .defaultMinSize(minHeight = 48.dp)
                                    .testTag("community_google_signin_button")
                            ) {
                                Text("Sign in with Google")
                            }
                        }
                    }
                }
            }

            // 6 Community Feature Tabs
            item(key = "community_tabs_row") {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("community_tabs_row")
                ) {
                    itemsIndexed(COMMUNITY_TABS) { index, tab ->
                        val count = when (index) {
                            0 -> state.communityStations.size
                            1 -> state.verifiedRoutes.size
                            2 -> state.rangeReports.size
                            3 -> state.evOwnerReviews.size
                            4 -> state.chargingExperiences.size
                            else -> state.tripRecommendations.size
                        }
                        FilterChip(
                            selected = selectedTab == index,
                            onClick = { viewModel.selectCommunityTab(index) },
                            leadingIcon = {
                                Icon(tab.icon, contentDescription = null, modifier = Modifier.size(16.dp))
                            },
                            label = {
                                Text(
                                    text = if (count > 0) "${tab.title} ($count)" else tab.title,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            },
                            modifier = Modifier
                                .defaultMinSize(minHeight = 48.dp)
                                .testTag("community_tab_$index")
                        )
                    }
                }
            }

            // Search / Filter Input
            item(key = "community_search_box") {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    placeholder = { Text("Filter ${COMMUNITY_TABS[selectedTab].title.lowercase()} by EV, city, or station...") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("community_search_input")
                )
            }

            val q = searchQuery.trim()
            when (selectedTab) {
                0 -> {
                    val filtered = state.communityStations.filter {
                        q.isEmpty() || it.name.contains(q, true) || it.city.contains(q, true) ||
                            it.provider.contains(q, true) || it.connectorTypes.contains(q, true)
                    }
                    if (filtered.isEmpty()) {
                        item {
                            CommunityEmptyStateCard(
                                headline = "No user-submitted stations yet",
                                description = "Spotted a new EV charger, cafe plug, or highway hub? Submit it so nearby riders see it within 100 km.",
                                ctaText = "Submit Charging Station",
                                isSignedIn = state.riderProfile.isSignedIn,
                                onAction = {
                                    if (state.riderProfile.isSignedIn) activeSubmitDialogTab = 0
                                    else viewModel.setGoogleSignInDialogVisible(true)
                                }
                            )
                        }
                    } else {
                        items(filtered, key = { it.id }) { st ->
                            val dist = if (state.userLatitude != null && state.userLongitude != null && (st.latitude != 0.0 || st.longitude != 0.0)) {
                                GeoUtils.haversineDistanceKm(state.userLatitude!!, state.userLongitude!!, st.latitude, st.longitude)
                            } else null
                            val (count, endorsed) = endorsementStats("STATION", st.id)
                            CommunityStationCard(
                                station = st,
                                distanceKm = dist,
                                endorseCount = count,
                                isEndorsedByMe = endorsed,
                                isOwner = st.userId == currentUid && currentUid.isNotBlank(),
                                onAddToRoute = {
                                    viewModel.addStationToTrip(st.toChargingStation(state.userLatitude, state.userLongitude))
                                },
                                onToggleEndorse = { viewModel.toggleCommunityEndorsement("STATION", st.id) },
                                onDelete = { viewModel.deleteCommunityEntry(EvCommunityRepository.COLLECTION_STATIONS, st.id) }
                            )
                        }
                    }
                }

                1 -> {
                    val filtered = state.verifiedRoutes.filter {
                        q.isEmpty() || it.title.contains(q, true) || it.originCity.contains(q, true) ||
                            it.destinationCity.contains(q, true) || it.vehicleName.contains(q, true)
                    }
                    if (filtered.isEmpty()) {
                        item {
                            CommunityEmptyStateCard(
                                headline = "No verified travel routes yet",
                                description = "Share a completed EV trip from your Planner so other riders can load your verified stops and reserve margins.",
                                ctaText = "Share Active Route",
                                isSignedIn = state.riderProfile.isSignedIn,
                                onAction = {
                                    if (state.riderProfile.isSignedIn) activeSubmitDialogTab = 1
                                    else viewModel.setGoogleSignInDialogVisible(true)
                                }
                            )
                        }
                    } else {
                        items(filtered, key = { it.id }) { route ->
                            val (count, endorsed) = endorsementStats("ROUTE", route.id)
                            VerifiedRouteCard(
                                route = route,
                                endorseCount = count,
                                isEndorsedByMe = endorsed,
                                isOwner = route.userId == currentUid && currentUid.isNotBlank(),
                                onLoadRoute = {
                                    viewModel.loadVerifiedRouteIntoPlanner(route)
                                    onRouteLoadedToPlanner()
                                },
                                onToggleEndorse = { viewModel.toggleCommunityEndorsement("ROUTE", route.id) },
                                onDelete = { viewModel.deleteCommunityEntry(EvCommunityRepository.COLLECTION_ROUTES, route.id) }
                            )
                        }
                    }
                }

                2 -> {
                    val filtered = state.rangeReports.filter {
                        q.isEmpty() || it.vehicleName.contains(q, true) || it.weatherCondition.contains(q, true) ||
                            it.ridingOrAcMode.contains(q, true)
                    }
                    if (filtered.isEmpty()) {
                        item {
                            CommunityEmptyStateCard(
                                headline = "No real-world range reports yet",
                                description = "Compare claimed brochure range vs real-world highway, hill, or city battery performance.",
                                ctaText = "Post Range Report",
                                isSignedIn = state.riderProfile.isSignedIn,
                                onAction = {
                                    if (state.riderProfile.isSignedIn) activeSubmitDialogTab = 2
                                    else viewModel.setGoogleSignInDialogVisible(true)
                                }
                            )
                        }
                    } else {
                        items(filtered, key = { it.id }) { report ->
                            RangeReportCard(
                                report = report,
                                isOwner = report.userId == currentUid && currentUid.isNotBlank(),
                                onDelete = { viewModel.deleteCommunityEntry(EvCommunityRepository.COLLECTION_RANGE_REPORTS, report.id) }
                            )
                        }
                    }
                }

                3 -> {
                    val filtered = state.evOwnerReviews.filter {
                        q.isEmpty() || it.vehicleName.contains(q, true) || it.headline.contains(q, true) ||
                            it.reviewText.contains(q, true)
                    }
                    if (filtered.isEmpty()) {
                        item {
                            CommunityEmptyStateCard(
                                headline = "No EV owner reviews yet",
                                description = "Share honest ownership pros, cons, and real odometer experience with your scooter, bike, or car.",
                                ctaText = "Write EV Owner Review",
                                isSignedIn = state.riderProfile.isSignedIn,
                                onAction = {
                                    if (state.riderProfile.isSignedIn) activeSubmitDialogTab = 3
                                    else viewModel.setGoogleSignInDialogVisible(true)
                                }
                            )
                        }
                    } else {
                        items(filtered, key = { it.id }) { review ->
                            EvOwnerReviewCard(
                                review = review,
                                isOwner = review.userId == currentUid && currentUid.isNotBlank(),
                                onDelete = { viewModel.deleteCommunityEntry(EvCommunityRepository.COLLECTION_OWNER_REVIEWS, review.id) }
                            )
                        }
                    }
                }

                4 -> {
                    val filtered = state.chargingExperiences.filter {
                        q.isEmpty() || it.stationName.contains(q, true) || it.provider.contains(q, true) ||
                            it.vehicleName.contains(q, true)
                    }
                    if (filtered.isEmpty()) {
                        item {
                            CommunityEmptyStateCard(
                                headline = "No charging experiences shared yet",
                                description = "Share peak kW delivered, queue wait times, and amenities from your latest public charging session.",
                                ctaText = "Share Charging Session",
                                isSignedIn = state.riderProfile.isSignedIn,
                                onAction = {
                                    if (state.riderProfile.isSignedIn) activeSubmitDialogTab = 4
                                    else viewModel.setGoogleSignInDialogVisible(true)
                                }
                            )
                        }
                    } else {
                        items(filtered, key = { it.id }) { exp ->
                            ChargingExperienceCard(
                                experience = exp,
                                isOwner = exp.userId == currentUid && currentUid.isNotBlank(),
                                onDelete = { viewModel.deleteCommunityEntry(EvCommunityRepository.COLLECTION_CHARGING_EXPERIENCES, exp.id) }
                            )
                        }
                    }
                }

                else -> {
                    val filtered = state.tripRecommendations.filter {
                        q.isEmpty() || it.title.contains(q, true) || it.corridor.contains(q, true) ||
                            it.recommendedCategory.contains(q, true)
                    }
                    if (filtered.isEmpty()) {
                        item {
                            CommunityEmptyStateCard(
                                headline = "No community trip recommendations yet",
                                description = "Suggest scenic weekend loops, mountain climbs, or reliable highway corridors with charging tips.",
                                ctaText = "Recommend an EV Trip",
                                isSignedIn = state.riderProfile.isSignedIn,
                                onAction = {
                                    if (state.riderProfile.isSignedIn) activeSubmitDialogTab = 5
                                    else viewModel.setGoogleSignInDialogVisible(true)
                                }
                            )
                        }
                    } else {
                        items(filtered, key = { it.id }) { rec ->
                            val (count, endorsed) = endorsementStats("RECOMMENDATION", rec.id)
                            TripRecommendationCard(
                                recommendation = rec,
                                endorseCount = count,
                                isEndorsedByMe = endorsed,
                                isOwner = rec.userId == currentUid && currentUid.isNotBlank(),
                                onTryInPredictor = {
                                    viewModel.applyTripRecommendationToPredictor(rec)
                                    onOpenPredictor()
                                },
                                onToggleEndorse = { viewModel.toggleCommunityEndorsement("RECOMMENDATION", rec.id) },
                                onDelete = { viewModel.deleteCommunityEntry(EvCommunityRepository.COLLECTION_TRIP_RECOMMENDATIONS, rec.id) }
                            )
                        }
                    }
                }
            }
        }
    }

    when (activeSubmitDialogTab) {
        0 -> SubmitCommunityStationDialog(
            state = state,
            onDismiss = { activeSubmitDialogTab = null },
            onSubmit = { name, provider, city, address, powerKw, connectors, cost, bays, lat, lon, hours, notes ->
                viewModel.submitCommunityStation(
                    name, provider, city, address, powerKw, connectors, cost, bays, lat, lon, hours, notes
                )
                activeSubmitDialogTab = null
            }
        )

        1 -> ShareVerifiedRouteDialog(
            state = state,
            activeStopsJson = viewModel.activeRouteStopsJson(),
            onDismiss = { activeSubmitDialogTab = null },
            onSubmit = { title, origin, dest, dist, elev, veh, cat, stopsCount, arrival, weather, summary, stopsJson, notes ->
                viewModel.submitVerifiedRoute(
                    title, origin, dest, dist, elev, veh, cat, stopsCount, arrival, weather, summary, stopsJson, notes
                )
                activeSubmitDialogTab = null
            }
        )

        2 -> SubmitRangeReportDialog(
            state = state,
            onDismiss = { activeSubmitDialogTab = null },
            onSubmit = { veh, cat, claimed, observed, driven, used, eff, speed, weather, mode, notes ->
                viewModel.submitRangeReport(
                    veh, cat, claimed, observed, driven, used, eff, speed, weather, mode, notes
                )
                activeSubmitDialogTab = null
            }
        )

        3 -> SubmitEvOwnerReviewDialog(
            state = state,
            onDismiss = { activeSubmitDialogTab = null },
            onSubmit = { veh, cat, rating, months, odo, headline, pros, cons, text ->
                viewModel.submitEvOwnerReview(veh, cat, rating, months, odo, headline, pros, cons, text)
                activeSubmitDialogTab = null
            }
        )

        4 -> ShareChargingExperienceDialog(
            state = state,
            onDismiss = { activeSubmitDialogTab = null },
            onSubmit = { station, provider, veh, conn, power, start, end, dur, wait, rating, notes ->
                viewModel.submitChargingExperience(
                    station, provider, veh, conn, power, start, end, dur, wait, rating, notes
                )
                activeSubmitDialogTab = null
            }
        )

        5 -> SubmitTripRecommendationDialog(
            onDismiss = { activeSubmitDialogTab = null },
            onSubmit = { title, corridor, dist, cat, diff, season, tip, highlights ->
                viewModel.submitTripRecommendation(title, corridor, dist, cat, diff, season, tip, highlights)
                activeSubmitDialogTab = null
            }
        )
    }
}

@Composable
private fun CommunityEmptyStateCard(
    headline: String,
    description: String,
    ctaText: String,
    isSignedIn: Boolean,
    onAction: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("community_empty_state_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(headline, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(description, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(
                onClick = onAction,
                modifier = Modifier
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = 48.dp)
                    .testTag("community_empty_cta_button")
            ) {
                Text(if (isSignedIn) ctaText else "Sign in to $ctaText")
            }
        }
    }
}
