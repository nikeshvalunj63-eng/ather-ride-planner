package com.example.ui.screens.garage

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.ElectricMoped
import androidx.compose.material.icons.filled.ElectricScooter
import androidx.compose.material.icons.filled.Garage
import androidx.compose.material.icons.filled.Power
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.EvConnectorCatalog
import com.example.data.model.GarageVehicle
import com.example.ui.components.SmoothNumberField
import com.example.ui.theme.EVGreenPrimary
import com.example.viewmodel.TripViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GarageScreen(
    viewModel: TripViewModel,
    onVehicleActivated: () -> Unit = {}
) {
    val state by viewModel.uiState.collectAsState()
    val vehicles by viewModel.garageVehicles.collectAsState()

    var showVehicleDialog by remember { mutableStateOf(false) }
    var editingVehicle by remember { mutableStateOf<GarageVehicle?>(null) }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 640.dp)
                .padding(horizontal = 16.dp)
                .testTag("garage_lazy_column"),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 88.dp)
        ) {
            // Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Vehicle Garage",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Save multiple EVs & compatible charger plugs",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                        )
                    }

                    Button(
                        onClick = {
                            editingVehicle = null
                            showVehicleDialog = true
                        },
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        modifier = Modifier
                            .defaultMinSize(minHeight = 48.dp)
                            .testTag("garage_add_vehicle_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add EV", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Active Vehicle Banner Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                    ),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = SolidColor(MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
                        width = 1.dp
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "ACTIVE TRIP VEHICLE",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = state.selectedVehicleName,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${state.selectedVehicleCategory} • ${state.vehicleRange100.toInt()} km • ${state.batteryCapacityKWh} kWh • ${state.averageSpeedKmh.toInt()} km/h",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f)
                                )
                            }

                            FilledTonalButton(
                                onClick = { viewModel.saveCurrentVehicleToGarage() },
                                modifier = Modifier
                                    .defaultMinSize(minHeight = 48.dp)
                                    .testTag("garage_save_current_button")
                            ) {
                                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Save Current", fontSize = 12.sp)
                            }
                        }

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            state.compatibleConnectors.forEach { conn ->
                                ConnectorBadge(label = conn)
                            }
                        }
                    }
                }
            }

            // Saved Garage Vehicles Section
            item {
                Text(
                    text = "Saved Vehicles (${vehicles.size})",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            if (vehicles.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Garage,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                                modifier = Modifier.size(48.dp)
                            )
                            Text(
                                text = "Your Vehicle Garage is empty",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = "Save multiple scooters, motorcycles, or EVs with their range, speed, and compatible charger connectors for 1-tap switching.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                            )
                            Button(
                                onClick = {
                                    editingVehicle = null
                                    showVehicleDialog = true
                                },
                                modifier = Modifier.defaultMinSize(minHeight = 48.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Add Your First Vehicle")
                            }
                        }
                    }
                }
            } else {
                items(
                    items = vehicles,
                    key = { it.id }
                ) { vehicle ->
                    val isCurrentlyActive = state.activeVehicleId == vehicle.id ||
                        (state.activeVehicleId == null && vehicle.isActive)

                    val categoryIcon = when (vehicle.category) {
                        "Electric Car" -> Icons.Default.DirectionsCar
                        "Electric Motorcycle" -> Icons.Default.ElectricMoped
                        else -> Icons.Default.ElectricScooter
                    }

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        ),
                        border = if (isCurrentlyActive) {
                            CardDefaults.outlinedCardBorder().copy(
                                brush = SolidColor(EVGreenPrimary),
                                width = 1.5.dp
                            )
                        } else null
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = categoryIcon,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = vehicle.name,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp
                                            )
                                            if (isCurrentlyActive) {
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Box(
                                                    modifier = Modifier
                                                        .background(
                                                            EVGreenPrimary.copy(alpha = 0.2f),
                                                            RoundedCornerShape(4.dp)
                                                        )
                                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                                ) {
                                                    Text(
                                                        text = "ACTIVE",
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = MaterialTheme.colorScheme.primary
                                                    )
                                                }
                                            }
                                        }
                                        Text(
                                            text = "${vehicle.category} • Reserve ${vehicle.reserveMarginPercent.toInt()}%",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                                        )
                                    }
                                }

                                Row {
                                    IconButton(
                                        onClick = {
                                            editingVehicle = vehicle
                                            showVehicleDialog = true
                                        },
                                        modifier = Modifier.size(48.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Edit,
                                            contentDescription = "Edit Vehicle",
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    IconButton(
                                        onClick = { viewModel.deleteGarageVehicle(vehicle.id) },
                                        modifier = Modifier.size(48.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Delete,
                                            contentDescription = "Delete Vehicle",
                                            tint = MaterialTheme.colorScheme.error
                                        )
                                    }
                                }
                            }

                            // Metrics Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                SpecBadge(text = "${vehicle.range100Km.toInt()} km range")
                                SpecBadge(text = "${vehicle.batteryCapacityKWh} kWh")
                                SpecBadge(text = "${vehicle.averageSpeedKmh.toInt()} km/h")
                            }

                            // Compatible Connectors
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                vehicle.compatibleConnectors.forEach { conn ->
                                    ConnectorBadge(label = conn)
                                }
                            }

                            // Action button
                            if (isCurrentlyActive) {
                                OutlinedButton(
                                    onClick = onVehicleActivated,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .defaultMinSize(minHeight = 48.dp)
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Active in Planner • View Dashboard")
                                }
                            } else {
                                Button(
                                    onClick = {
                                        viewModel.selectGarageVehicle(vehicle)
                                        onVehicleActivated()
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .defaultMinSize(minHeight = 48.dp)
                                ) {
                                    Icon(Icons.Default.ElectricBolt, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Use This Vehicle")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showVehicleDialog) {
        AddEditGarageVehicleDialog(
            existing = editingVehicle,
            defaultName = editingVehicle?.name ?: "",
            defaultCategory = editingVehicle?.category ?: state.selectedVehicleCategory,
            defaultRange = editingVehicle?.range100Km ?: state.vehicleRange100,
            defaultCapacity = editingVehicle?.batteryCapacityKWh ?: state.batteryCapacityKWh,
            defaultReserve = editingVehicle?.reserveMarginPercent ?: state.reserveMargin,
            defaultSpeed = editingVehicle?.averageSpeedKmh ?: state.averageSpeedKmh,
            defaultConnectors = editingVehicle?.compatibleConnectors ?: state.compatibleConnectors,
            onDismiss = { showVehicleDialog = false },
            onSave = { name, category, range, capacity, reserve, speed, connectors ->
                viewModel.saveGarageVehicle(
                    id = editingVehicle?.id,
                    name = name,
                    category = category,
                    range100Km = range,
                    batteryCapacityKWh = capacity,
                    reserveMarginPercent = reserve,
                    averageSpeedKmh = speed,
                    compatibleConnectors = connectors,
                    setActive = true
                )
                showVehicleDialog = false
            }
        )
    }
}

@Composable
private fun SpecBadge(text: String) {
    Box(
        modifier = Modifier
            .background(
                MaterialTheme.colorScheme.surface,
                RoundedCornerShape(6.dp)
            )
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = text,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun ConnectorBadge(label: String) {
    Box(
        modifier = Modifier
            .background(
                MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                RoundedCornerShape(6.dp)
            )
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.Power,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AddEditGarageVehicleDialog(
    existing: GarageVehicle?,
    defaultName: String,
    defaultCategory: String,
    defaultRange: Double,
    defaultCapacity: Double,
    defaultReserve: Double,
    defaultSpeed: Double,
    defaultConnectors: Set<String>,
    onDismiss: () -> Unit,
    onSave: (
        name: String,
        category: String,
        range100Km: Double,
        capacityKWh: Double,
        reserveMarginPercent: Double,
        averageSpeedKmh: Double,
        connectors: Set<String>
    ) -> Unit
) {
    var name by remember(existing?.id) { mutableStateOf(defaultName) }
    var category by remember(existing?.id) { mutableStateOf(defaultCategory) }
    var rangeKm by remember(existing?.id) { mutableStateOf<Double?>(defaultRange) }
    var capacityKWh by remember(existing?.id) { mutableStateOf<Double?>(defaultCapacity) }
    var reservePct by remember(existing?.id) { mutableStateOf<Double?>(defaultReserve) }
    var speedKmh by remember(existing?.id) { mutableStateOf<Double?>(defaultSpeed) }
    var selectedConnectors by remember(existing?.id) { mutableStateOf(defaultConnectors) }

    val categories = listOf("Electric Scooter", "Electric Motorcycle", "Electric Car")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (existing == null) "Add Vehicle to Garage" else "Edit Garage Vehicle",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Vehicle Name (e.g. My Ather 450X)") },
                    placeholder = { Text("Enter EV name") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("garage_vehicle_name_input")
                )

                Text(
                    text = "Vehicle Category",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                )

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    categories.forEach { cat ->
                        val shortLabel = when (cat) {
                            "Electric Scooter" -> "Scooter"
                            "Electric Motorcycle" -> "Motorcycle"
                            else -> "Car"
                        }
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(shortLabel, fontSize = 12.sp) }
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SmoothNumberField(
                        value = rangeKm,
                        onValueChange = { rangeKm = it },
                        label = "100% Range",
                        suffix = "km",
                        minValue = 1.0,
                        maxValue = 2000.0,
                        syncKey = "g_range_${existing?.id}",
                        modifier = Modifier.weight(1f)
                    )
                    SmoothNumberField(
                        value = capacityKWh,
                        onValueChange = { capacityKWh = it },
                        label = "Pack Size",
                        suffix = "kWh",
                        minValue = 0.5,
                        maxValue = 250.0,
                        syncKey = "g_cap_${existing?.id}",
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SmoothNumberField(
                        value = speedKmh,
                        onValueChange = { speedKmh = it },
                        label = "Avg Speed",
                        suffix = "km/h",
                        minValue = 5.0,
                        maxValue = 200.0,
                        syncKey = "g_speed_${existing?.id}",
                        modifier = Modifier.weight(1f)
                    )
                    SmoothNumberField(
                        value = reservePct,
                        onValueChange = { reservePct = it },
                        label = "Min Reserve",
                        suffix = "%",
                        minValue = 0.0,
                        maxValue = 60.0,
                        syncKey = "g_res_${existing?.id}",
                        modifier = Modifier.weight(1f)
                    )
                }

                Text(
                    text = "Compatible Charger Connectors (${selectedConnectors.size} selected)",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                )

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    EvConnectorCatalog.ALL_CONNECTORS.forEach { connector ->
                        val isSelected = selectedConnectors.contains(connector)
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                selectedConnectors = if (isSelected) {
                                    selectedConnectors - connector
                                } else {
                                    selectedConnectors + connector
                                }
                            },
                            leadingIcon = if (isSelected) {
                                {
                                    Icon(
                                        Icons.Default.Check,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            } else null,
                            label = { Text(connector, fontSize = 11.sp) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                modifier = Modifier.testTag("garage_confirm_save_button"),
                onClick = {
                    onSave(
                        name.ifBlank { "My EV" },
                        category,
                        rangeKm ?: 110.0,
                        capacityKWh ?: 3.7,
                        reservePct ?: 15.0,
                        speedKmh ?: 45.0,
                        selectedConnectors
                    )
                }
            ) {
                Text("Save Vehicle")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
