package com.example.ui.screens.stations

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Power
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.model.ChargingOperatorCatalog
import com.example.data.model.EvConnectorCatalog
import com.example.data.remote.StationCommunityRepository
import com.example.domain.BatteryCalculator
import com.example.ui.theme.EVGreenPrimary
import com.example.ui.theme.StatusDanger
import com.example.ui.theme.StatusSafe
import com.example.ui.theme.StatusWarning
import com.example.viewmodel.TripViewModel

private data class QuickRegionFallback(
    val label: String,
    val lat: Double,
    val lon: Double
)

private val QUICK_REGIONS = listOf(
    QuickRegionFallback("Pune", 18.5204, 73.8567),
    QuickRegionFallback("Mumbai", 19.0760, 72.8777),
    QuickRegionFallback("Bengaluru", 12.9716, 77.5946),
    QuickRegionFallback("New Delhi", 28.6139, 77.2090),
    QuickRegionFallback("Hyderabad", 17.3850, 78.4867),
    QuickRegionFallback("Chennai", 13.0827, 80.2707)
)

@Composable
fun StationsScreen(
    viewModel: TripViewModel,
    onOpenCommunityStations: () -> Unit = {}
) {
    val state by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    var showOnlyFavorites by remember { mutableStateOf(false) }

    fun hasLocationPermission(): Boolean {
        val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    var permissionGranted by remember { mutableStateOf(hasLocationPermission()) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        val granted = perms[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            perms[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        permissionGranted = granted
        if (granted) {
            viewModel.fetchLiveLocationAndStations(context)
        }
    }

    // Auto-fetch live GPS stations when entering tab with permission already granted
    LaunchedEffect(permissionGranted) {
        if (permissionGranted && state.userLatitude == null && !state.isLoadingLocation) {
            viewModel.fetchLiveLocationAndStations(context)
        }
    }

    val activeRadiusKm = state.stationRadiusFilterKm
    val hasCoordinates = state.userLatitude != null && state.userLongitude != null

    val filteredStations = remember(
        state.allStations,
        state.stationSearchQuery,
        activeRadiusKm,
        showOnlyFavorites,
        state.showCompatibleStationsOnly,
        state.compatibleConnectors,
        state.stationWorkingFilterOnly,
        state.communitySummaries,
        hasCoordinates
    ) {
        state.allStations
            .filter { station ->
                val q = state.stationSearchQuery.trim()
                val matchesQuery = q.isEmpty() ||
                    station.name.contains(q, ignoreCase = true) ||
                    station.provider.contains(q, ignoreCase = true) ||
                    station.city.contains(q, ignoreCase = true) ||
                    station.address.contains(q, ignoreCase = true)

                val matchesRadius = if (!hasCoordinates || activeRadiusKm == null) {
                    true
                } else {
                    (station.distanceFromUserKm ?: Double.MAX_VALUE) <= activeRadiusKm
                }

                val matchesFav = !showOnlyFavorites || station.isFavorite
                val matchesConnector = !state.showCompatibleStationsOnly ||
                    EvConnectorCatalog.isStationCompatible(state.compatibleConnectors, station.connectorTypes)

                val summary = state.communitySummaries[StationCommunityRepository.sanitizeId(station.id)]
                val matchesWorking = !state.stationWorkingFilterOnly ||
                    (summary != null && summary.workingCount > 0 && summary.openDownReports == 0)

                matchesQuery && matchesRadius && matchesFav && matchesConnector && matchesWorking
            }
            .let { list ->
                if (hasCoordinates) {
                    list.sortedBy { it.distanceFromUserKm ?: Double.MAX_VALUE }
                } else {
                    list
                }
            }
    }

    val weatherMultiplier = BatteryCalculator.getWeatherMultiplier(state.weatherCondition)

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 640.dp)
                .testTag("stations_lazy_column"),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 88.dp)
        ) {
            item(key = "stations_header") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Nearby EV Chargers",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Sorted Near → Far • Based on ${state.selectedVehicleName} (${state.vehicleRange100.toInt()} km)",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                    )
                }

                OutlinedButton(
                    onClick = onOpenCommunityStations,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("stations_submit_charger_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Submit", fontSize = 11.sp)
                }

                IconButton(
                    onClick = {
                        if (hasLocationPermission()) {
                            viewModel.fetchLiveLocationAndStations(context)
                        } else {
                            permissionLauncher.launch(
                                arrayOf(
                                    Manifest.permission.ACCESS_COARSE_LOCATION,
                                    Manifest.permission.ACCESS_FINE_LOCATION
                                )
                            )
                        }
                    },
                    modifier = Modifier.testTag("refresh_gps_button")
                ) {
                    if (state.isLoadingLocation) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    } else {
                        Icon(
                            Icons.Default.MyLocation,
                            contentDescription = "Refresh Live GPS",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
            }

            // Live Location Status Banner
            item(key = "stations_location_banner") {
                Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (hasCoordinates) {
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant
                    }
                )
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = if (hasCoordinates) Icons.Default.GpsFixed else Icons.Default.LocationOn,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = state.stationStatusMessage
                                    ?: if (hasCoordinates) {
                                        "Live: ${state.locationAreaLabel ?: "GPS Active"} (Near → Far)"
                                    } else {
                                        "Enable Live GPS to list stations within 100 km near to far"
                                    },
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        if (!hasCoordinates && !state.isLoadingLocation) {
                            Button(
                                onClick = {
                                    if (hasLocationPermission()) {
                                        viewModel.fetchLiveLocationAndStations(context)
                                    } else {
                                        permissionLauncher.launch(
                                            arrayOf(
                                                Manifest.permission.ACCESS_COARSE_LOCATION,
                                                Manifest.permission.ACCESS_FINE_LOCATION
                                            )
                                        )
                                    }
                                },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.testTag("enable_gps_button")
                            ) {
                                Text("Use Live GPS", fontSize = 11.sp)
                            }
                        }
                    }

                    // Quick city GPS preview chips (useful if GPS is unavailable on an emulator)
                    if (!hasCoordinates) {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(QUICK_REGIONS) { region ->
                                FilterChip(
                                    selected = false,
                                    onClick = {
                                        viewModel.applyLiveCoordinates(region.lat, region.lon, region.label)
                                    },
                                    label = { Text("Near ${region.label}", fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                }
            }
            }

            // Search Bar
            item(key = "stations_search_bar") {
                OutlinedTextField(
                    value = state.stationSearchQuery,
                    onValueChange = { viewModel.updateStationSearchQuery(it) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    placeholder = { Text("Search station, city, or provider (Ather, Tata...)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
            }

            // Radius & Favorite Filter Chips Row
            item(key = "stations_filter_chips") {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                item {
                    FilterChip(
                        selected = activeRadiusKm == 100.0,
                        onClick = { viewModel.updateStationRadiusFilter(100.0) },
                        label = { Text("Within 100 km", fontSize = 12.sp) }
                    )
                }

                item {
                    val evRangeKm = state.vehicleRange100.coerceAtLeast(10.0)
                    FilterChip(
                        selected = activeRadiusKm != null && activeRadiusKm != 100.0,
                        onClick = { viewModel.updateStationRadiusFilter(evRangeKm) },
                        label = { Text("EV Range (${evRangeKm.toInt()} km)", fontSize = 12.sp) }
                    )
                }

                item {
                    FilterChip(
                        selected = activeRadiusKm == null,
                        onClick = { viewModel.updateStationRadiusFilter(null) },
                        label = { Text("All Stations", fontSize = 12.sp) }
                    )
                }

                item {
                    FilterChip(
                        selected = state.showCompatibleStationsOnly,
                        onClick = { viewModel.toggleCompatibleStationsOnly() },
                        leadingIcon = {
                            Icon(
                                if (state.showCompatibleStationsOnly) Icons.Default.Check else Icons.Default.Power,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        label = { Text("Compatible Plug", fontSize = 12.sp) },
                        modifier = Modifier.testTag("stations_compatible_chip")
                    )
                }

                item {
                    FilterChip(
                        selected = state.stationWorkingFilterOnly,
                        onClick = { viewModel.toggleWorkingStationsFilter() },
                        leadingIcon = {
                            Icon(
                                Icons.Default.VerifiedUser,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        label = { Text("Verified Working", fontSize = 12.sp) },
                        modifier = Modifier.testTag("stations_working_chip")
                    )
                }

                item {
                    FilterChip(
                        selected = showOnlyFavorites,
                        onClick = { showOnlyFavorites = !showOnlyFavorites },
                        leadingIcon = {
                            Icon(
                                if (showOnlyFavorites) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        label = { Text("Favorites", fontSize = 12.sp) }
                    )
                }
            }
            }

            if (filteredStations.isEmpty()) {
                item(key = "stations_empty") {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 32.dp),
                        contentAlignment = Alignment.TopCenter
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = if (state.isLoadingLocation) {
                                    "Searching EV charging stations within 100 km..."
                                } else {
                                    "No stations found within ${activeRadiusKm?.toInt() ?: "selected"} km."
                                },
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
                                fontSize = 14.sp
                            )
                            if (activeRadiusKm != null && !state.isLoadingLocation) {
                                OutlinedButton(onClick = { viewModel.updateStationRadiusFilter(null) }) {
                                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Show All Stations")
                                }
                            }
                        }
                    }
                }
            } else {
                items(
                    items = filteredStations,
                    key = { it.id }
                ) { station ->
                        val distKm = station.distanceFromUserKm
                        val batteryNeededPct = if (distKm != null) {
                            (distKm / state.vehicleRange100.coerceAtLeast(1.0)) * 100.0 * weatherMultiplier
                        } else null
                        val arrivalPct = batteryNeededPct?.let { state.startBattery - it }
                        val sanitizedId = StationCommunityRepository.sanitizeId(station.id)
                        val summary = state.communitySummaries[sanitizedId]
                        val operatorProfile = ChargingOperatorCatalog.resolveOperator(
                            provider = station.provider,
                            stationName = station.name,
                            customPhone = station.operatorPhone,
                            customWebsite = station.operatorWebsite
                        )

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("station_card_${station.id}"),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = station.name,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "${operatorProfile.displayName} • ${station.city} • ${station.address}",
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                        )
                                    }

                                    IconButton(onClick = { viewModel.toggleFavoriteStation(station.id) }) {
                                        Icon(
                                            imageVector = if (station.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                            contentDescription = "Favorite",
                                            tint = if (station.isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                // Operator Network & Community Status Row
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                                                RoundedCornerShape(6.dp)
                                            )
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = "${station.bayCapacity} bays • ${station.openingHours}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }

                                    val statusColor = when {
                                        summary == null -> MaterialTheme.colorScheme.onSurfaceVariant
                                        summary.openDownReports > 0 || summary.notWorkingCount > summary.workingCount -> StatusDanger
                                        summary.workingCount > 0 -> StatusSafe
                                        summary.busyCount > 0 || summary.wrongLocationReports > 0 -> StatusWarning
                                        else -> MaterialTheme.colorScheme.onSurfaceVariant
                                    }
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                statusColor.copy(alpha = 0.14f),
                                                RoundedCornerShape(6.dp)
                                            )
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = summary?.headlineStatus ?: "Community: Tap to Verify",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = statusColor
                                        )
                                    }

                                    if ((summary?.photoCount ?: 0) > 0) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                Icons.Default.PhotoCamera,
                                                contentDescription = null,
                                                modifier = Modifier.size(13.dp),
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Spacer(modifier = Modifier.width(3.dp))
                                            Text(
                                                text = "${summary?.photoCount}",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                // Live Distance & EV Reachability Row
                                if (distKm != null && batteryNeededPct != null && arrivalPct != null) {
                                    val reachColor = when {
                                        arrivalPct >= state.reserveMargin -> StatusSafe
                                        arrivalPct > 0.0 -> StatusWarning
                                        else -> StatusDanger
                                    }
                                    val reachLabel = when {
                                        arrivalPct >= state.reserveMargin -> "Reachable (${String.format("%.0f", arrivalPct)}% left)"
                                        arrivalPct > 0.0 -> "Low Reserve (${String.format("%.0f", arrivalPct)}% left)"
                                        else -> "Needs Charge En-Route"
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .background(
                                                    EVGreenPrimary.copy(alpha = 0.16f),
                                                    RoundedCornerShape(6.dp)
                                                )
                                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text(
                                                text = "${String.format("%.1f", distKm)} km away",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }

                                        Box(
                                            modifier = Modifier
                                                .background(
                                                    reachColor.copy(alpha = 0.15f),
                                                    RoundedCornerShape(6.dp)
                                                )
                                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text(
                                                text = reachLabel,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = reachColor
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))
                                }

                                // Spec Badges
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                                                RoundedCornerShape(6.dp)
                                            )
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = "${station.powerKw.toInt()} kW",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }

                                    Box(
                                        modifier = Modifier
                                            .background(
                                                MaterialTheme.colorScheme.surface,
                                                RoundedCornerShape(6.dp)
                                            )
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = "₹${station.costPerKwh}/kWh",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }

                                    val isPlugCompatible = EvConnectorCatalog.isStationCompatible(
                                        state.compatibleConnectors,
                                        station.connectorTypes
                                    )
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                (if (isPlugCompatible) StatusSafe else StatusWarning).copy(alpha = 0.14f),
                                                RoundedCornerShape(6.dp)
                                            )
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = if (isPlugCompatible) "Plug Match ✓" else "Check Plug",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (isPlugCompatible) StatusSafe else StatusWarning
                                        )
                                    }

                                    Text(
                                        text = station.connectorTypes,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                    )
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // Action Buttons
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = { viewModel.addStationToTrip(station) },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = if (distKm != null) "Add (${String.format("%.1f", distKm)} km)" else "Add",
                                            fontSize = 12.sp
                                        )
                                    }

                                    OutlinedButton(
                                        onClick = { viewModel.openStationSheet(station, initialTab = 1) },
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("station_community_button_${station.id}")
                                    ) {
                                        Icon(Icons.Default.VerifiedUser, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Status/Report", fontSize = 11.sp)
                                    }

                                    OutlinedButton(
                                        onClick = { viewModel.openStationSheet(station, initialTab = 0) },
                                        modifier = Modifier.testTag("station_operator_button_${station.id}")
                                    ) {
                                        Icon(Icons.Default.Build, contentDescription = "Operator Integration", modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                    }
                }
            }
        }
    }
}
