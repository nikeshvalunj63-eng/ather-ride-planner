package com.example.ui.components

import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import java.util.Locale

fun formatCleanNumber(value: Double): String {
    return if (value % 1.0 == 0.0) {
        value.toLong().toString()
    } else {
        String.format(Locale.US, "%.2f", value).trimEnd('0').trimEnd('.')
    }
}

@Composable
fun SmoothNumberField(
    value: Double?,
    onValueChange: (Double?) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    placeholder: String? = null,
    suffix: String? = null,
    allowDecimal: Boolean = true,
    allowNegative: Boolean = false,
    showZeroAsEmpty: Boolean = false,
    minValue: Double? = null,
    maxValue: Double? = null,
    syncKey: Any? = Unit,
    imeAction: ImeAction = ImeAction.Done
) {
    val focusManager = LocalFocusManager.current

    fun toDisplayString(v: Double?): String {
        if (v == null) return ""
        if (showZeroAsEmpty && v == 0.0) return ""
        return formatCleanNumber(v)
    }

    var text by remember(syncKey) { mutableStateOf(toDisplayString(value)) }
    var isFocused by remember { mutableStateOf(false) }

    // Only sync from external model changes when not actively typing (e.g. presets, load trip, round trip)
    LaunchedEffect(value, syncKey) {
        if (!isFocused) {
            val currentParsed = text.toDoubleOrNull()
            if (value == null) {
                if (text.isNotEmpty()) text = ""
            } else if (currentParsed == null || kotlin.math.abs(currentParsed - value) > 0.001) {
                text = toDisplayString(value)
            }
        }
    }

    OutlinedTextField(
        value = text,
        onValueChange = { raw ->
            val filtered = buildString {
                var hasDot = false
                for ((idx, ch) in raw.withIndex()) {
                    if (ch.isDigit()) {
                        append(ch)
                    } else if (allowNegative && ch == '-' && idx == 0) {
                        append(ch)
                    } else if (allowDecimal && ch == '.' && !hasDot) {
                        hasDot = true
                        append(ch)
                    }
                }
            }
            text = filtered
            if (filtered.isEmpty()) {
                onValueChange(null)
            } else {
                val parsed = filtered.toDoubleOrNull()
                if (parsed != null) {
                    onValueChange(parsed)
                }
            }
        },
        label = { Text(label) },
        placeholder = placeholder?.let { { Text(it) } },
        suffix = suffix?.let { { Text(it) } },
        singleLine = true,
        keyboardOptions = KeyboardOptions(
            keyboardType = if (allowDecimal) KeyboardType.Decimal else KeyboardType.Number,
            imeAction = imeAction
        ),
        keyboardActions = KeyboardActions(
            onDone = { focusManager.clearFocus() }
        ),
        modifier = modifier.onFocusChanged { focusState ->
            isFocused = focusState.isFocused
            if (!focusState.isFocused) {
                val parsed = text.toDoubleOrNull()
                if (parsed != null) {
                    var clamped = parsed
                    if (minValue != null) clamped = maxOf(minValue, clamped)
                    if (maxValue != null) clamped = minOf(maxValue, clamped)
                    if (clamped != parsed) {
                        onValueChange(clamped)
                    }
                    text = toDisplayString(clamped)
                } else {
                    text = toDisplayString(value)
                }
            }
        }
    )
}
