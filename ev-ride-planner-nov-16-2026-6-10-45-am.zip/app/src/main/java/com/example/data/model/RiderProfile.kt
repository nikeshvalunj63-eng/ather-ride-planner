package com.example.data.model

data class RiderProfile(
    val uid: String? = null,
    val isSignedIn: Boolean = false,
    val displayName: String = "Guest Rider",
    val email: String = "",
    val photoUrl: String? = null,
    val selectedVehicleName: String = "Ather 450X Gen 3",
    val totalKmTracked: Double = 342.5,
    val totalCo2SavedKg: Double = 41.2
)
