package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.TripTelemetryRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface TripTelemetryDao {
    @Query("SELECT * FROM trip_telemetry_records ORDER BY createdAt DESC")
    fun getAllRecords(): Flow<List<TripTelemetryRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecord(record: TripTelemetryRecord)

    @Query("DELETE FROM trip_telemetry_records WHERE id = :id")
    suspend fun deleteRecordById(id: String)

    @Query("DELETE FROM trip_telemetry_records")
    suspend fun clearAll()
}
