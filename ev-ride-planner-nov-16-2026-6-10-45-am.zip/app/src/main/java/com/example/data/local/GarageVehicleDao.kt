package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.GarageVehicle
import kotlinx.coroutines.flow.Flow

@Dao
interface GarageVehicleDao {

    @Query("SELECT * FROM garage_vehicles ORDER BY isActive DESC, createdAt DESC")
    fun getAllVehicles(): Flow<List<GarageVehicle>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateVehicle(vehicle: GarageVehicle)

    @Query("DELETE FROM garage_vehicles WHERE id = :vehicleId")
    suspend fun deleteVehicleById(vehicleId: String)

    @Query("UPDATE garage_vehicles SET isActive = 0")
    suspend fun clearActiveFlags()

    @Query("UPDATE garage_vehicles SET isActive = 1 WHERE id = :vehicleId")
    suspend fun markVehicleActive(vehicleId: String)
}
