package com.example.data.repository

import com.example.data.local.ChargingCycleDao
import com.example.data.local.GarageVehicleDao
import com.example.data.local.TripDao
import com.example.data.local.TripTelemetryDao
import com.example.data.model.ChargingCycle
import com.example.data.model.ChargingStation
import com.example.data.model.GarageVehicle
import com.example.data.model.TripPlan
import com.example.data.model.TripTelemetryRecord
import kotlinx.coroutines.flow.Flow

class TripRepository(
    private val tripDao: TripDao,
    private val chargingCycleDao: ChargingCycleDao? = null,
    private val garageVehicleDao: GarageVehicleDao? = null,
    private val tripTelemetryDao: TripTelemetryDao? = null
) {

    fun getAllSavedTrips(): Flow<List<TripPlan>> = tripDao.getAllTrips()

    suspend fun saveTrip(plan: TripPlan) = tripDao.insertOrUpdateTrip(plan)

    suspend fun deleteTrip(id: String) = tripDao.deleteTripById(id)

    suspend fun getTripById(id: String): TripPlan? = tripDao.getTripById(id)

    fun getAllChargingCycles(): Flow<List<ChargingCycle>>? = chargingCycleDao?.getAllCycles()

    suspend fun saveChargingCycle(cycle: ChargingCycle) {
        chargingCycleDao?.insertCycle(cycle)
    }

    suspend fun deleteChargingCycle(id: String) {
        chargingCycleDao?.deleteCycleById(id)
    }

    fun getAllGarageVehicles(): Flow<List<GarageVehicle>>? = garageVehicleDao?.getAllVehicles()

    suspend fun saveGarageVehicle(vehicle: GarageVehicle) {
        if (vehicle.isActive) {
            garageVehicleDao?.clearActiveFlags()
        }
        garageVehicleDao?.insertOrUpdateVehicle(vehicle)
    }

    suspend fun setActiveGarageVehicle(vehicleId: String) {
        garageVehicleDao?.clearActiveFlags()
        garageVehicleDao?.markVehicleActive(vehicleId)
    }

    suspend fun deleteGarageVehicle(vehicleId: String) {
        garageVehicleDao?.deleteVehicleById(vehicleId)
    }

    fun getAllTelemetryRecords(): Flow<List<TripTelemetryRecord>>? = tripTelemetryDao?.getAllRecords()

    suspend fun saveTelemetryRecord(record: TripTelemetryRecord) {
        tripTelemetryDao?.insertRecord(record)
    }

    suspend fun deleteTelemetryRecord(id: String) {
        tripTelemetryDao?.deleteRecordById(id)
    }

    fun getPreloadedStations(): List<ChargingStation> = listOf(
        ChargingStation(
            id = "cs_1",
            name = "Ather Grid - Indiranagar",
            provider = "Ather Grid",
            city = "Bengaluru",
            address = "100 Ft Road, HAL 2nd Stage, Indiranagar",
            powerKw = 22.0,
            connectorTypes = "Ather Fast Dot, Type 2",
            isFavorite = true,
            costPerKwh = 18.0,
            latitude = 12.9716,
            longitude = 77.6412,
            operatorPhone = "18002662843",
            operatorWebsite = "https://www.atherenergy.com/charging",
            openingHours = "24/7",
            bayCapacity = 4,
            authMethods = "Ather App • Auto-Auth • UPI",
            ocpiNetworkCode = "IN-ATH • Ather Telemetry"
        ),
        ChargingStation(
            id = "cs_2",
            name = "Tata Power EZ Charge - MG Road",
            provider = "Tata Power EZ Charge",
            city = "Bengaluru",
            address = "MG Road Metro Station Parking, Sivanchetti Gardens",
            powerKw = 60.0,
            connectorTypes = "CCS2, Bharat DC-001, Type 2",
            isFavorite = true,
            costPerKwh = 21.0,
            latitude = 12.9756,
            longitude = 77.6066,
            operatorPhone = "18008332233",
            operatorWebsite = "https://www.tatapower.com/ezcharge",
            openingHours = "24/7",
            bayCapacity = 6,
            authMethods = "EZ Charge App • RFID • UPI",
            ocpiNetworkCode = "IN-TPE • OCPI 2.2"
        ),
        ChargingStation(
            id = "cs_3",
            name = "Zeon Fast Charger - NH 275 Express",
            provider = "Zeon Charging",
            city = "Mysuru Highway",
            address = "Highway Food Court, Ramanagara, NH 275",
            powerKw = 50.0,
            connectorTypes = "CCS2, Type 2",
            isFavorite = false,
            costPerKwh = 22.5,
            latitude = 12.7214,
            longitude = 77.2811,
            operatorPhone = "09500501201",
            operatorWebsite = "https://www.zeoncharging.com",
            openingHours = "24/7",
            bayCapacity = 4,
            authMethods = "Zeon App • Auto-Charge • UPI",
            ocpiNetworkCode = "IN-ZEN • OCPI 2.2"
        ),
        ChargingStation(
            id = "cs_4",
            name = "Ather Grid - Bandra Kurla Complex",
            provider = "Ather Grid",
            city = "Mumbai",
            address = "G Block BKC, Bandra East",
            powerKw = 22.0,
            connectorTypes = "Ather Fast Dot",
            isFavorite = true,
            costPerKwh = 19.5,
            latitude = 19.0657,
            longitude = 72.8687,
            operatorPhone = "18002662843",
            operatorWebsite = "https://www.atherenergy.com/charging",
            openingHours = "06:00 - 23:00",
            bayCapacity = 3,
            authMethods = "Ather App • Auto-Auth",
            ocpiNetworkCode = "IN-ATH • Ather Telemetry"
        ),
        ChargingStation(
            id = "cs_5",
            name = "Jio-bp pulse - Mumbai Expressway Hub",
            provider = "Jio-bp pulse",
            city = "Navi Mumbai",
            address = "Mumbai-Pune Expressway Exit Hub, Kalamboli",
            powerKw = 60.0,
            connectorTypes = "CCS2, Type 2, GB/T",
            isFavorite = false,
            costPerKwh = 20.0,
            latitude = 19.0232,
            longitude = 73.1042,
            operatorPhone = "18008919023",
            operatorWebsite = "https://www.jiobp.com/products-and-services/ev-charging",
            openingHours = "24/7",
            bayCapacity = 8,
            authMethods = "Jio-bp pulse App • RFID • UPI",
            ocpiNetworkCode = "IN-JBP • OCPI 2.2"
        ),
        ChargingStation(
            id = "cs_6",
            name = "Statiq Smart Charging - Koregaon Park",
            provider = "Statiq",
            city = "Pune",
            address = "North Main Road, Koregaon Park",
            powerKw = 30.0,
            connectorTypes = "CCS2, Type 2",
            isFavorite = true,
            costPerKwh = 18.5,
            latitude = 18.5362,
            longitude = 73.8940,
            operatorPhone = "18001230456",
            operatorWebsite = "https://www.statiq.in",
            openingHours = "24/7",
            bayCapacity = 4,
            authMethods = "Statiq App • RFID • Wallet",
            ocpiNetworkCode = "IN-STQ • OCPI 2.2"
        ),
        ChargingStation(
            id = "cs_7",
            name = "Ather Grid - Connaught Place",
            provider = "Ather Grid",
            city = "New Delhi",
            address = "Inner Circle Block C, Connaught Place",
            powerKw = 22.0,
            connectorTypes = "Ather Fast Dot",
            isFavorite = false,
            costPerKwh = 19.0,
            latitude = 28.6315,
            longitude = 77.2167,
            operatorPhone = "18002662843",
            operatorWebsite = "https://www.atherenergy.com/charging",
            openingHours = "24/7",
            bayCapacity = 3,
            authMethods = "Ather App • Auto-Auth",
            ocpiNetworkCode = "IN-ATH • Ather Telemetry"
        ),
        ChargingStation(
            id = "cs_8",
            name = "Tata Power EZ Charge - Cyber City",
            provider = "Tata Power EZ Charge",
            city = "Gurugram",
            address = "DLF Cyber City, Phase 2, Sector 24",
            powerKw = 50.0,
            connectorTypes = "CCS2, Type 2",
            isFavorite = true,
            costPerKwh = 21.5,
            latitude = 28.4952,
            longitude = 77.0891,
            operatorPhone = "18008332233",
            operatorWebsite = "https://www.tatapower.com/ezcharge",
            openingHours = "24/7",
            bayCapacity = 6,
            authMethods = "EZ Charge App • RFID • UPI",
            ocpiNetworkCode = "IN-TPE • OCPI 2.2"
        ),
        ChargingStation(
            id = "cs_9",
            name = "Shell Recharge Fast Hub",
            provider = "Shell Recharge",
            city = "Hyderabad",
            address = "Gachibowli Outer Ring Road Junction",
            powerKw = 60.0,
            connectorTypes = "CCS2, Type 2",
            isFavorite = false,
            costPerKwh = 23.0,
            latitude = 17.4401,
            longitude = 78.3489,
            operatorPhone = "18002104400",
            operatorWebsite = "https://www.shell.in/motorists/shell-recharge.html",
            openingHours = "24/7",
            bayCapacity = 6,
            authMethods = "Shell Recharge App • Card • UPI",
            ocpiNetworkCode = "IN-SHL • OCPI 2.2"
        ),
        ChargingStation(
            id = "cs_10",
            name = "Zeon Fast Charger - OMR IT Corridor",
            provider = "Zeon Charging",
            city = "Chennai",
            address = "Old Mahabalipuram Road, Sholinganallur",
            powerKw = 50.0,
            connectorTypes = "CCS2, Type 2",
            isFavorite = false,
            costPerKwh = 22.0,
            latitude = 12.9010,
            longitude = 80.2279,
            operatorPhone = "09500501201",
            operatorWebsite = "https://www.zeoncharging.com",
            openingHours = "24/7",
            bayCapacity = 4,
            authMethods = "Zeon App • Auto-Charge • UPI",
            ocpiNetworkCode = "IN-ZEN • OCPI 2.2"
        )
    )
}
