package com.example.data.remote

import android.content.Context
import com.example.R
import com.example.data.model.ChargingExperience
import com.example.data.model.CommunityEndorsement
import com.example.data.model.CommunityStation
import com.example.data.model.EvOwnerReview
import com.example.data.model.RangeReport
import com.example.data.model.TripRecommendation
import com.example.data.model.VerifiedRoute
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class EvCommunityRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("Please sign in with Google before accessing EV Community.")
    }

    private inline fun <reified T> observeCommunityCollection(collection: String): Flow<List<T>> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection(collection)
                .whereEqualTo("visibility", "community")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        T::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, collection, auth)
                    }
                    throw error
                }
        )
    }

    fun observeCommunityStations(): Flow<List<CommunityStation>> =
        observeCommunityCollection<CommunityStation>(COLLECTION_STATIONS)
            .map { list -> list.sortedByDescending { it.createdAt?.seconds ?: 0L } }

    fun observeVerifiedRoutes(): Flow<List<VerifiedRoute>> =
        observeCommunityCollection<VerifiedRoute>(COLLECTION_ROUTES)
            .map { list -> list.sortedByDescending { it.createdAt?.seconds ?: 0L } }

    fun observeRangeReports(): Flow<List<RangeReport>> =
        observeCommunityCollection<RangeReport>(COLLECTION_RANGE_REPORTS)
            .map { list -> list.sortedByDescending { it.createdAt?.seconds ?: 0L } }

    fun observeOwnerReviews(): Flow<List<EvOwnerReview>> =
        observeCommunityCollection<EvOwnerReview>(COLLECTION_OWNER_REVIEWS)
            .map { list -> list.sortedByDescending { it.createdAt?.seconds ?: 0L } }

    fun observeChargingExperiences(): Flow<List<ChargingExperience>> =
        observeCommunityCollection<ChargingExperience>(COLLECTION_CHARGING_EXPERIENCES)
            .map { list -> list.sortedByDescending { it.createdAt?.seconds ?: 0L } }

    fun observeTripRecommendations(): Flow<List<TripRecommendation>> =
        observeCommunityCollection<TripRecommendation>(COLLECTION_TRIP_RECOMMENDATIONS)
            .map { list -> list.sortedByDescending { it.createdAt?.seconds ?: 0L } }

    fun observeEndorsements(): Flow<List<CommunityEndorsement>> =
        observeCommunityCollection(COLLECTION_ENDORSEMENTS)

    suspend fun submitCommunityStation(
        name: String,
        provider: String,
        city: String,
        address: String,
        powerKw: Double,
        connectorTypes: String,
        costPerKwh: Double,
        bayCapacity: Int,
        latitude: Double,
        longitude: Double,
        openingHours: String,
        notes: String,
        authorLabel: String,
        explicitId: String? = null
    ): Result<String> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val cleanId = explicitId?.takeIf { it.isNotBlank() }?.let(StationCommunityRepository::sanitizeId)
            ?: "cst_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val payload = mapOf(
            "userId" to uid,
            "authorLabel" to authorLabel.trim().ifBlank { "EV Rider" }.take(50),
            "name" to name.trim().ifBlank { "Community EV Charger" }.take(120),
            "provider" to provider.trim().ifBlank { "Independent Host" }.take(80),
            "city" to city.trim().ifBlank { "Local Hub" }.take(80),
            "address" to address.trim().ifBlank { city.ifBlank { "GPS Pinned Location" } }.take(200),
            "powerKw" to powerKw.coerceIn(0.5, 500.0),
            "connectorTypes" to connectorTypes.trim().ifBlank { "Type 2" }.take(160),
            "costPerKwh" to costPerKwh.coerceIn(0.0, 200.0),
            "bayCapacity" to bayCapacity.coerceIn(1, 60),
            "latitude" to latitude.coerceIn(-90.0, 90.0),
            "longitude" to longitude.coerceIn(-180.0, 180.0),
            "openingHours" to openingHours.trim().ifBlank { "24/7" }.take(60),
            "notes" to notes.trim().take(300),
            "visibility" to "community",
            "createdAt" to FieldValue.serverTimestamp()
        )
        return writeDocument(COLLECTION_STATIONS, cleanId, payload)
    }

    suspend fun submitVerifiedRoute(
        title: String,
        originCity: String,
        destinationCity: String,
        totalDistanceKm: Double,
        elevationGainMeters: Double,
        vehicleName: String,
        vehicleCategory: String,
        chargingStopsCount: Int,
        arrivalBatteryPercent: Double,
        weatherCondition: String,
        stopsSummary: String,
        stopsJson: String,
        notes: String,
        authorLabel: String,
        explicitId: String? = null
    ): Result<String> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val cleanId = explicitId?.takeIf { it.isNotBlank() }?.let(StationCommunityRepository::sanitizeId)
            ?: "crt_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val validCat = if (vehicleCategory in VALID_VEHICLE_CATEGORIES) vehicleCategory else "Electric Scooter"
        val payload = mapOf(
            "userId" to uid,
            "authorLabel" to authorLabel.trim().ifBlank { "EV Rider" }.take(50),
            "title" to title.trim().ifBlank { "$originCity to $destinationCity" }.take(120),
            "originCity" to originCity.trim().ifBlank { "Start" }.take(80),
            "destinationCity" to destinationCity.trim().ifBlank { "Destination" }.take(80),
            "totalDistanceKm" to totalDistanceKm.coerceIn(1.0, 5000.0),
            "elevationGainMeters" to elevationGainMeters.coerceIn(-5000.0, 10000.0),
            "vehicleName" to vehicleName.trim().ifBlank { "Electric Vehicle" }.take(80),
            "vehicleCategory" to validCat,
            "chargingStopsCount" to chargingStopsCount.coerceIn(0, 50),
            "arrivalBatteryPercent" to arrivalBatteryPercent.coerceIn(0.0, 100.0),
            "weatherCondition" to weatherCondition.trim().ifBlank { "Clear" }.take(40),
            "stopsSummary" to stopsSummary.trim().ifBlank { "$originCity -> $destinationCity" }.take(300),
            "stopsJson" to stopsJson.take(7800),
            "notes" to notes.trim().take(400),
            "visibility" to "community",
            "createdAt" to FieldValue.serverTimestamp()
        )
        return writeDocument(COLLECTION_ROUTES, cleanId, payload)
    }

    suspend fun submitRangeReport(
        vehicleName: String,
        vehicleCategory: String,
        claimedRangeKm: Double,
        observedRealRangeKm: Double,
        distanceDrivenKm: Double,
        batteryUsedPercent: Double,
        avgEfficiencyWhPerKm: Double,
        avgSpeedKmh: Double,
        weatherCondition: String,
        ridingOrAcMode: String,
        notes: String,
        authorLabel: String,
        explicitId: String? = null
    ): Result<String> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val cleanId = explicitId?.takeIf { it.isNotBlank() }?.let(StationCommunityRepository::sanitizeId)
            ?: "rrp_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val validCat = if (vehicleCategory in VALID_VEHICLE_CATEGORIES) vehicleCategory else "Electric Scooter"
        val payload = mapOf(
            "userId" to uid,
            "authorLabel" to authorLabel.trim().ifBlank { "EV Rider" }.take(50),
            "vehicleName" to vehicleName.trim().ifBlank { "Electric Vehicle" }.take(80),
            "vehicleCategory" to validCat,
            "claimedRangeKm" to claimedRangeKm.coerceIn(10.0, 2000.0),
            "observedRealRangeKm" to observedRealRangeKm.coerceIn(5.0, 2000.0),
            "distanceDrivenKm" to distanceDrivenKm.coerceIn(1.0, 2000.0),
            "batteryUsedPercent" to batteryUsedPercent.coerceIn(1.0, 100.0),
            "avgEfficiencyWhPerKm" to avgEfficiencyWhPerKm.coerceIn(5.0, 800.0),
            "avgSpeedKmh" to avgSpeedKmh.coerceIn(5.0, 200.0),
            "weatherCondition" to weatherCondition.trim().ifBlank { "Clear" }.take(40),
            "ridingOrAcMode" to ridingOrAcMode.trim().ifBlank { "Ride" }.take(40),
            "notes" to notes.trim().take(400),
            "visibility" to "community",
            "createdAt" to FieldValue.serverTimestamp()
        )
        return writeDocument(COLLECTION_RANGE_REPORTS, cleanId, payload)
    }

    suspend fun submitOwnerReview(
        vehicleName: String,
        vehicleCategory: String,
        rating: Int,
        ownershipMonths: Int,
        odometerKm: Int,
        headline: String,
        pros: String,
        cons: String,
        reviewText: String,
        authorLabel: String,
        explicitId: String? = null
    ): Result<String> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val cleanId = explicitId?.takeIf { it.isNotBlank() }?.let(StationCommunityRepository::sanitizeId)
            ?: "rev_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val validCat = if (vehicleCategory in VALID_VEHICLE_CATEGORIES) vehicleCategory else "Electric Scooter"
        val cleanText = reviewText.trim().ifBlank { headline.trim().ifBlank { "Great EV ownership experience." } }
        val payload = mapOf(
            "userId" to uid,
            "authorLabel" to authorLabel.trim().ifBlank { "EV Owner" }.take(50),
            "vehicleName" to vehicleName.trim().ifBlank { "Electric Vehicle" }.take(80),
            "vehicleCategory" to validCat,
            "rating" to rating.coerceIn(1, 5),
            "ownershipMonths" to ownershipMonths.coerceIn(0, 360),
            "odometerKm" to odometerKm.coerceIn(0, 1_000_000),
            "headline" to headline.trim().ifBlank { "$vehicleName Owner Review" }.take(120),
            "pros" to pros.trim().take(240),
            "cons" to cons.trim().take(240),
            "reviewText" to (if (cleanText.length < 5) "$cleanText review" else cleanText).take(600),
            "visibility" to "community",
            "createdAt" to FieldValue.serverTimestamp()
        )
        return writeDocument(COLLECTION_OWNER_REVIEWS, cleanId, payload)
    }

    suspend fun submitChargingExperience(
        stationName: String,
        provider: String,
        vehicleName: String,
        connectorUsed: String,
        peakPowerKw: Double,
        startPercent: Double,
        endPercent: Double,
        durationMinutes: Int,
        waitTimeMinutes: Int,
        rating: Int,
        experienceNotes: String,
        authorLabel: String,
        explicitId: String? = null
    ): Result<String> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val cleanId = explicitId?.takeIf { it.isNotBlank() }?.let(StationCommunityRepository::sanitizeId)
            ?: "exp_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val cleanStart = startPercent.coerceIn(0.0, 99.0)
        val cleanEnd = endPercent.coerceIn(cleanStart + 1.0, 100.0)
        val cleanNotes = experienceNotes.trim().ifBlank { "Charged cleanly." }
        val payload = mapOf(
            "userId" to uid,
            "authorLabel" to authorLabel.trim().ifBlank { "EV Rider" }.take(50),
            "stationName" to stationName.trim().ifBlank { "EV Charging Station" }.take(120),
            "provider" to provider.trim().ifBlank { "Public Charger" }.take(80),
            "vehicleName" to vehicleName.trim().ifBlank { "Electric Vehicle" }.take(80),
            "connectorUsed" to connectorUsed.trim().ifBlank { "Type 2" }.take(50),
            "peakPowerKw" to peakPowerKw.coerceIn(0.5, 500.0),
            "startPercent" to cleanStart,
            "endPercent" to cleanEnd,
            "durationMinutes" to durationMinutes.coerceIn(1, 1440),
            "waitTimeMinutes" to waitTimeMinutes.coerceIn(0, 360),
            "rating" to rating.coerceIn(1, 5),
            "experienceNotes" to (if (cleanNotes.length < 3) "$cleanNotes ok" else cleanNotes).take(500),
            "visibility" to "community",
            "createdAt" to FieldValue.serverTimestamp()
        )
        return writeDocument(COLLECTION_CHARGING_EXPERIENCES, cleanId, payload)
    }

    suspend fun submitTripRecommendation(
        title: String,
        corridor: String,
        totalDistanceKm: Double,
        recommendedCategory: String,
        difficulty: String,
        bestSeason: String,
        chargingTip: String,
        highlights: String,
        authorLabel: String,
        explicitId: String? = null
    ): Result<String> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val cleanId = explicitId?.takeIf { it.isNotBlank() }?.let(StationCommunityRepository::sanitizeId)
            ?: "rec_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val validCat = if (recommendedCategory in VALID_REC_CATEGORIES) recommendedCategory else "All EVs"
        val validDiff = if (difficulty in VALID_DIFFICULTIES) difficulty else "Easy"
        val cleanHighlights = highlights.trim().ifBlank { "Scenic EV friendly route" }
        val payload = mapOf(
            "userId" to uid,
            "authorLabel" to authorLabel.trim().ifBlank { "EV Rider" }.take(50),
            "title" to title.trim().ifBlank { "Scenic EV Route" }.take(120),
            "corridor" to corridor.trim().ifBlank { title.trim().ifBlank { "Local Loop" } }.take(140),
            "totalDistanceKm" to totalDistanceKm.coerceIn(1.0, 5000.0),
            "recommendedCategory" to validCat,
            "difficulty" to validDiff,
            "bestSeason" to bestSeason.trim().ifBlank { "All Year" }.take(60),
            "chargingTip" to chargingTip.trim().ifBlank { "Charge to 90% before climb." }.take(300),
            "highlights" to (if (cleanHighlights.length < 3) "$cleanHighlights trip" else cleanHighlights).take(500),
            "visibility" to "community",
            "createdAt" to FieldValue.serverTimestamp()
        )
        return writeDocument(COLLECTION_TRIP_RECOMMENDATIONS, cleanId, payload)
    }

    suspend fun toggleEndorsement(targetType: String, targetId: String, currentlyEndorsed: Boolean): Result<Boolean> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val cleanType = if (targetType in setOf("ROUTE", "RECOMMENDATION", "STATION")) targetType else "ROUTE"
        val cleanTargetId = StationCommunityRepository.sanitizeId(targetId)
        val docId = "${cleanType}_${cleanTargetId}_${StationCommunityRepository.sanitizeId(uid)}".take(128)
        val docRef = db.collection(COLLECTION_ENDORSEMENTS).document(docId)
        return try {
            if (currentlyEndorsed) {
                docRef.delete().await()
                Result.success(false)
            } else {
                val payload = mapOf(
                    "userId" to uid,
                    "targetType" to cleanType,
                    "targetId" to cleanTargetId,
                    "visibility" to "community",
                    "createdAt" to FieldValue.serverTimestamp()
                )
                docRef.set(payload).await()
                Result.success(true)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun deleteCommunityItem(collection: String, docId: String): Result<Unit> {
        try {
            requireUserId()
            require(docId.isNotBlank()) { "Document ID cannot be blank" }
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val docRef = db.collection(collection).document(StationCommunityRepository.sanitizeId(docId))
        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path, auth)
            Result.failure(e)
        }
    }

    private suspend fun writeDocument(
        collection: String,
        docId: String,
        payload: Map<String, Any>
    ): Result<String> {
        val docRef = db.collection(collection).document(docId)
        return try {
            docRef.set(payload).await()
            Result.success(docId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path, auth)
            Result.failure(e)
        }
    }

    companion object {
        const val COLLECTION_STATIONS = "community_stations"
        const val COLLECTION_ROUTES = "community_routes"
        const val COLLECTION_RANGE_REPORTS = "range_reports"
        const val COLLECTION_OWNER_REVIEWS = "ev_owner_reviews"
        const val COLLECTION_CHARGING_EXPERIENCES = "charging_experiences"
        const val COLLECTION_TRIP_RECOMMENDATIONS = "trip_recommendations"
        const val COLLECTION_ENDORSEMENTS = "community_endorsements"

        private val VALID_VEHICLE_CATEGORIES = setOf("Electric Scooter", "Electric Motorcycle", "Electric Car")
        private val VALID_REC_CATEGORIES = setOf("All EVs", "Electric Scooter", "Electric Motorcycle", "Electric Car")
        private val VALID_DIFFICULTIES = setOf("Easy", "Moderate", "Challenging")
    }
}
