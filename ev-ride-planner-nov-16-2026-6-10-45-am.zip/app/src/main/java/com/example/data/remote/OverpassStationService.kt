package com.example.data.remote

import com.example.data.model.ChargingOperatorCatalog
import com.example.data.model.ChargingStation
import com.example.domain.GeoUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object OverpassStationService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(18, TimeUnit.SECONDS)
        .build()

    /**
     * Queries OpenStreetMap Overpass API for real EV charging stations within [radiusKm]
     * around the user's live GPS coordinates, sorted near-to-far, and enriches them with
     * EV charging operator metadata.
     */
    suspend fun fetchNearbyStations(
        latitude: Double,
        longitude: Double,
        radiusKm: Double = 100.0
    ): Result<List<ChargingStation>> = withContext(Dispatchers.IO) {
        try {
            val radiusMeters = (radiusKm * 1000).toInt().coerceIn(1000, 150000)
            val query = """
                [out:json][timeout:15];
                (
                  node["amenity"="charging_station"](around:$radiusMeters,$latitude,$longitude);
                  way["amenity"="charging_station"](around:$radiusMeters,$latitude,$longitude);
                );
                out center 80;
            """.trimIndent()

            val body = query.toRequestBody("text/plain; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url("https://overpass-api.de/api/interpreter")
                .post(body)
                .header("User-Agent", "EVRidePlannerAndroid/1.0")
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext Result.failure(
                        IllegalStateException("Station lookup failed (HTTP ${response.code})")
                    )
                }

                val jsonStr = response.body?.string().orEmpty()
                if (jsonStr.isBlank()) {
                    return@withContext Result.success(emptyList())
                }

                val root = JSONObject(jsonStr)
                val elements = root.optJSONArray("elements") ?: return@withContext Result.success(emptyList())
                val stations = mutableListOf<ChargingStation>()

                for (i in 0 until elements.length()) {
                    val el = elements.getJSONObject(i)
                    val tags = el.optJSONObject("tags") ?: continue

                    val stLat = if (el.has("lat")) {
                        el.optDouble("lat", Double.NaN)
                    } else {
                        el.optJSONObject("center")?.optDouble("lat", Double.NaN) ?: Double.NaN
                    }
                    val stLon = if (el.has("lon")) {
                        el.optDouble("lon", Double.NaN)
                    } else {
                        el.optJSONObject("center")?.optDouble("lon", Double.NaN) ?: Double.NaN
                    }

                    if (stLat.isNaN() || stLon.isNaN()) continue

                    val distKm = GeoUtils.haversineDistanceKm(latitude, longitude, stLat, stLon)
                    if (distKm > radiusKm) continue

                    val operatorRaw = tags.optString("operator")
                        .ifBlank { tags.optString("brand") }
                        .ifBlank { tags.optString("network") }
                        .ifBlank { "Public EV Network" }

                    val rawName = tags.optString("name")
                        .ifBlank { "$operatorRaw Charging Station" }

                    val city = tags.optString("addr:city")
                        .ifBlank { tags.optString("addr:suburb") }
                        .ifBlank { tags.optString("addr:town") }
                        .ifBlank { "Nearby" }

                    val street = listOf(
                        tags.optString("addr:housenumber"),
                        tags.optString("addr:street"),
                        tags.optString("addr:full")
                    ).filter { it.isNotBlank() }.joinToString(" ")
                        .ifBlank { "GPS: ${String.format("%.4f", stLat)}, ${String.format("%.4f", stLon)}" }

                    val powerKw = parsePowerKw(tags)
                    val connectors = parseConnectors(tags)
                    val osmPhone = tags.optString("phone").ifBlank { tags.optString("contact:phone") }
                    val osmWebsite = tags.optString("website").ifBlank { tags.optString("contact:website") }
                    val openingHours = tags.optString("opening_hours").ifBlank { "24/7" }
                    val bayCapacity = tags.optString("capacity").toIntOrNull()?.coerceIn(1, 50) ?: 2
                    val opProfile = ChargingOperatorCatalog.resolveOperator(
                        provider = operatorRaw,
                        stationName = rawName,
                        customPhone = osmPhone,
                        customWebsite = osmWebsite
                    )

                    stations.add(
                        ChargingStation(
                            id = "osm_${el.optLong("id")}",
                            name = rawName,
                            provider = opProfile.displayName,
                            city = city,
                            address = street,
                            powerKw = powerKw,
                            connectorTypes = connectors,
                            isFavorite = false,
                            costPerKwh = 18.0,
                            latitude = stLat,
                            longitude = stLon,
                            distanceFromUserKm = distKm,
                            isLiveFetched = true,
                            operatorPhone = opProfile.supportPhone,
                            operatorWebsite = opProfile.portalUrl,
                            openingHours = openingHours,
                            bayCapacity = bayCapacity,
                            authMethods = opProfile.sessionAuthMethods,
                            ocpiNetworkCode = opProfile.ocpiNetworkId
                        )
                    )
                }

                Result.success(stations.sortedBy { it.distanceFromUserKm ?: Double.MAX_VALUE })
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun parsePowerKw(tags: JSONObject): Double {
        val candidates = listOf(
            tags.optString("socket:type2_combo:output"),
            tags.optString("socket:chademo:output"),
            tags.optString("socket:type2:output"),
            tags.optString("output"),
            tags.optString("power")
        )
        for (raw in candidates) {
            if (raw.isNotBlank()) {
                val num = Regex("""(\d+(\.\d+)?)""").find(raw)?.groupValues?.getOrNull(1)?.toDoubleOrNull()
                if (num != null && num > 0.0) return num
            }
        }
        return 22.0
    }

    private fun parseConnectors(tags: JSONObject): String {
        val list = mutableListOf<String>()
        if (tags.has("socket:type2_combo")) list.add("CCS2")
        if (tags.has("socket:type2")) list.add("Type 2")
        if (tags.has("socket:chademo")) list.add("CHAdeMO")
        if (tags.has("socket:tesla_supercharger") || tags.has("socket:nacs")) list.add("NACS/Tesla")
        if (tags.has("socket:schuko") || tags.has("socket:indian_3pin")) list.add("AC 3-Pin")
        return if (list.isEmpty()) "EV Fast / Type 2" else list.joinToString(", ")
    }
}
