package com.example.data.local

import androidx.room.TypeConverter
import com.example.data.model.Stop
import com.example.data.model.StopType
import org.json.JSONArray
import org.json.JSONObject

class TripConverters {

    @TypeConverter
    fun fromStopList(stops: List<Stop>?): String {
        if (stops.isNullOrEmpty()) return "[]"
        val array = JSONArray()
        for (stop in stops) {
            val obj = JSONObject().apply {
                put("id", stop.id)
                put("name", stop.name)
                put("type", stop.type.name)
                put("distanceToNextKm", stop.distanceToNextKm)
                put("targetBatteryAfterChargePercent", stop.targetBatteryAfterChargePercent)
                if (stop.actualChargedBatteryPercent != null) {
                    put("actualChargedBatteryPercent", stop.actualChargedBatteryPercent)
                }
                put("chargerPowerKw", stop.chargerPowerKw)
                put("costPerUnitInr", stop.costPerUnitInr)
            }
            array.put(obj)
        }
        return array.toString()
    }

    @TypeConverter
    fun toStopList(json: String?): List<Stop> {
        if (json.isNullOrBlank()) return emptyList()
        val list = mutableListOf<Stop>()
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val typeName = obj.optString("type", StopType.CHARGING_STATION.name)
                val stopType = try {
                    StopType.valueOf(typeName)
                } catch (e: Exception) {
                    StopType.CHARGING_STATION
                }
                val actual = if (obj.has("actualChargedBatteryPercent")) {
                    obj.optDouble("actualChargedBatteryPercent")
                } else null

                list.add(
                    Stop(
                        id = obj.optString("id", java.util.UUID.randomUUID().toString()),
                        name = obj.optString("name", "Stop $i"),
                        type = stopType,
                        distanceToNextKm = obj.optDouble("distanceToNextKm", 0.0),
                        targetBatteryAfterChargePercent = obj.optDouble("targetBatteryAfterChargePercent", 90.0),
                        actualChargedBatteryPercent = actual,
                        chargerPowerKw = obj.optDouble("chargerPowerKw", 22.0),
                        costPerUnitInr = obj.optDouble("costPerUnitInr", 18.0)
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }
}
