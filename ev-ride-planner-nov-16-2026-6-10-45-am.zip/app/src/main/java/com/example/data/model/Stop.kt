package com.example.data.model

import java.util.UUID

data class Stop(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: StopType,
    val distanceToNextKm: Double = 0.0,
    val targetBatteryAfterChargePercent: Double = 90.0,
    val actualChargedBatteryPercent: Double? = null,
    val chargerPowerKw: Double = 22.0,
    val costPerUnitInr: Double = 18.0
)
