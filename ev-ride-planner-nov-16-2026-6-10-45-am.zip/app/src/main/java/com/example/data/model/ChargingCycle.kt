package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "charging_cycles")
data class ChargingCycle(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val vehicleName: String,
    val stationName: String,
    val startPercent: Double,
    val endPercent: Double,
    val durationMinutes: Int,
    val chargerPowerKw: Double = 3.3,
    val createdAt: Long = System.currentTimeMillis()
) {
    val percentGained: Double
        get() = (endPercent - startPercent).coerceAtLeast(0.0)

    val percentPerMinute: Double
        get() = if (durationMinutes > 0 && percentGained > 0.0) {
            percentGained / durationMinutes.toDouble()
        } else {
            0.0
        }
}
