package com.example.data.model

data class SegmentAnalysis(
    val fromStop: Stop,
    val toStop: Stop,
    val distanceKm: Double,
    val batteryConsumedPercent: Double,
    val arrivalBatteryPercent: Double,
    val departureBatteryPercent: Double,
    val isSafe: Boolean,
    val isCritical: Boolean,
    val chargingCost: Double,
    val chargingMinutes: Int = 0,
    val driveMinutes: Int = 0,
    val isChargingTimeFromHistory: Boolean = false
)
