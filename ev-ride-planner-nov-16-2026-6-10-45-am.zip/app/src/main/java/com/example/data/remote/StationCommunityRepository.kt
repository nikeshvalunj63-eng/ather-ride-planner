package com.example.data.remote

import android.content.Context
import com.example.R
import com.example.data.model.AvailabilityStatus
import com.example.data.model.ChargingOperatorCatalog
import com.example.data.model.ChargingStation
import com.example.data.model.ReportCategory
import com.example.data.model.StationConfirmation
import com.example.data.model.StationPhoto
import com.example.data.model.StationReport
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class StationCommunityRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("Please sign in with Google before submitting community updates.")
    }

    fun observeCommunityReports(): Flow<List<StationReport>> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection(COLLECTION_REPORTS)
                .whereEqualTo("visibility", "community")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        StationReport::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, COLLECTION_REPORTS, auth)
                    }
                    throw error
                }
        )
    }

    fun observeCommunityConfirmations(): Flow<List<StationConfirmation>> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection(COLLECTION_CONFIRMATIONS)
                .whereEqualTo("visibility", "community")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        StationConfirmation::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { (it.updatedAt ?: it.createdAt)?.seconds ?: 0L }
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, COLLECTION_CONFIRMATIONS, auth)
                    }
                    throw error
                }
        )
    }

    fun observeCommunityPhotos(): Flow<List<StationPhoto>> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection(COLLECTION_PHOTOS)
                .whereEqualTo("visibility", "community")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        StationPhoto::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, COLLECTION_PHOTOS, auth)
                    }
                    throw error
                }
        )
    }

    suspend fun getReportsForStation(stationId: String): Result<List<StationReport>> {
        return try {
            requireUserId()
            val cleanStationId = sanitizeId(stationId)
            val snap = db.collection(COLLECTION_REPORTS)
                .whereEqualTo("visibility", "community")
                .get()
                .await()
            val list = snap.toObjects(
                StationReport::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ).filter { it.stationId == cleanStationId }
            Result.success(list)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, COLLECTION_REPORTS, auth)
            Result.failure(e)
        }
    }

    suspend fun submitStationReport(
        station: ChargingStation,
        category: ReportCategory,
        issueReason: String,
        notes: String,
        authorLabel: String,
        suggestedLat: Double = 0.0,
        suggestedLon: Double = 0.0,
        explicitReportId: String? = null
    ): Result<String> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val cleanId = explicitReportId?.takeIf { it.isNotBlank() }?.let(::sanitizeId)
            ?: "rep_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val docRef = db.collection(COLLECTION_REPORTS).document(cleanId)
        val operator = ChargingOperatorCatalog.resolveOperator(station.provider, station.name)
        val cleanAuthor = authorLabel.trim().ifBlank { "EV Rider" }.take(50)
        val cleanStationId = sanitizeId(station.id)
        val payload = mapOf(
            "userId" to uid,
            "authorLabel" to cleanAuthor,
            "stationId" to cleanStationId,
            "stationName" to station.name.trim().ifBlank { "EV Station" }.take(120),
            "operatorName" to operator.displayName.take(80),
            "reportCategory" to category.value,
            "issueReason" to issueReason.trim().ifBlank { category.label }.take(80),
            "notes" to notes.trim().take(400),
            "suggestedLat" to suggestedLat.coerceIn(-90.0, 90.0),
            "suggestedLon" to suggestedLon.coerceIn(-180.0, 180.0),
            "status" to "open",
            "visibility" to "community",
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return try {
            docRef.set(payload).await()
            Result.success(cleanId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun resolveStationReport(report: StationReport): Result<Unit> {
        try {
            requireUserId()
            require(report.id.isNotBlank()) { "Report ID cannot be blank" }
            requireNotNull(report.createdAt) { "Report createdAt cannot be null" }
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val docRef = db.collection(COLLECTION_REPORTS).document(report.id)
        return try {
            docRef.set(report.copy(status = "resolved", updatedAt = null)).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun confirmStationAvailability(
        station: ChargingStation,
        availabilityStatus: AvailabilityStatus,
        connectorUsed: String,
        comment: String,
        authorLabel: String
    ): Result<String> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val cleanStationId = sanitizeId(station.id)
        val docId = "${cleanStationId}_${sanitizeId(uid)}".take(128)
        val docRef = db.collection(COLLECTION_CONFIRMATIONS).document(docId)
        val cleanAuthor = authorLabel.trim().ifBlank { "EV Rider" }.take(50)

        return try {
            val existingQuery = db.collection(COLLECTION_CONFIRMATIONS)
                .whereEqualTo("userId", uid)
                .whereEqualTo("stationId", cleanStationId)
                .limit(1)
                .get()
                .await()

            if (!existingQuery.isEmpty) {
                val updates = mapOf(
                    "availabilityStatus" to availabilityStatus.value,
                    "connectorUsed" to connectorUsed.trim().take(50),
                    "comment" to comment.trim().take(240),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.update(updates).await()
            } else {
                val payload = mapOf(
                    "userId" to uid,
                    "authorLabel" to cleanAuthor,
                    "stationId" to cleanStationId,
                    "stationName" to station.name.trim().ifBlank { "EV Station" }.take(120),
                    "availabilityStatus" to availabilityStatus.value,
                    "connectorUsed" to connectorUsed.trim().take(50),
                    "comment" to comment.trim().take(240),
                    "visibility" to "community",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(payload).await()
            }
            Result.success(docId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun uploadStationPhoto(
        station: ChargingStation,
        caption: String,
        imageBase64: String,
        authorLabel: String,
        explicitPhotoId: String? = null
    ): Result<String> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val cleanId = explicitPhotoId?.takeIf { it.isNotBlank() }?.let(::sanitizeId)
            ?: "photo_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val docRef = db.collection(COLLECTION_PHOTOS).document(cleanId)
        val cleanAuthor = authorLabel.trim().ifBlank { "EV Rider" }.take(50)
        val payload = mapOf(
            "userId" to uid,
            "authorLabel" to cleanAuthor,
            "stationId" to sanitizeId(station.id),
            "stationName" to station.name.trim().ifBlank { "EV Station" }.take(120),
            "caption" to caption.trim().take(180),
            "imageBase64" to imageBase64.take(255000),
            "visibility" to "community",
            "createdAt" to FieldValue.serverTimestamp()
        )
        return try {
            docRef.set(payload).await()
            Result.success(cleanId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun deleteStationPhoto(photoId: String): Result<Unit> {
        try {
            requireUserId()
            require(photoId.isNotBlank()) { "Photo ID cannot be blank" }
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val docRef = db.collection(COLLECTION_PHOTOS).document(sanitizeId(photoId))
        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path, auth)
            Result.failure(e)
        }
    }

    companion object {
        const val COLLECTION_REPORTS = "station_reports"
        const val COLLECTION_CONFIRMATIONS = "station_confirmations"
        const val COLLECTION_PHOTOS = "station_photos"

        fun sanitizeId(raw: String): String {
            return raw.replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
                .trim('_')
                .ifBlank { "station_unknown" }
                .take(96)
        }
    }
}
