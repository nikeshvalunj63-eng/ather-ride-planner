package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

object EvConnectorCatalog {
    val ALL_CONNECTORS = listOf(
        "Type 2",
        "CCS2",
        "Ather Fast Dot",
        "CHAdeMO",
        "Bharat DC-001",
        "Bharat AC-001",
        "AC 3-Pin (15A)",
        "NACS/Tesla"
    )

    fun parseCsv(csv: String): Set<String> {
        return csv.split(",")
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .toSet()
    }

    fun toCsv(connectors: Set<String>): String {
        return connectors.map { it.trim() }.filter { it.isNotEmpty() }.joinToString(", ")
    }

    /**
     * Returns true if any connector in [vehicleConnectors] matches [stationConnectorsRaw].
     * Uses flexible token matching so e.g. "AC 3-Pin (15A)" matches "AC 3-Pin" and "CCS2" matches "CCS2, Type 2".
     */
    fun isStationCompatible(vehicleConnectors: Set<String>, stationConnectorsRaw: String): Boolean {
        if (vehicleConnectors.isEmpty()) return true
        val stationLower = stationConnectorsRaw.lowercase()
        return vehicleConnectors.any { conn ->
            val token = conn.substringBefore("(").trim().lowercase()
            token.isNotEmpty() && stationLower.contains(token)
        }
    }
}

@Entity(tableName = "garage_vehicles")
data class GarageVehicle(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val name: String,
    val category: String = "Electric Scooter",
    val range100Km: Double = 110.0,
    val batteryCapacityKWh: Double = 3.7,
    val reserveMarginPercent: Double = 15.0,
    val averageSpeedKmh: Double = 45.0,
    val compatibleConnectorsCsv: String = "Type 2, Ather Fast Dot",
    val isActive: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
) {
    val compatibleConnectors: Set<String>
        get() = EvConnectorCatalog.parseCsv(compatibleConnectorsCsv)
}
