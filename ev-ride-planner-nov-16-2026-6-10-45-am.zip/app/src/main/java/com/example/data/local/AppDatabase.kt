package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.data.model.ChargingCycle
import com.example.data.model.GarageVehicle
import com.example.data.model.TripPlan
import com.example.data.model.TripTelemetryRecord

@Database(
    entities = [
        TripPlan::class,
        ChargingCycle::class,
        GarageVehicle::class,
        TripTelemetryRecord::class
    ],
    version = 4,
    exportSchema = false
)
@TypeConverters(TripConverters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun tripDao(): TripDao
    abstract fun chargingCycleDao(): ChargingCycleDao
    abstract fun garageVehicleDao(): GarageVehicleDao
    abstract fun tripTelemetryDao(): TripTelemetryDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ev_ride_planner.db"
                ).fallbackToDestructiveMigration(dropAllTables = true).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
