package com.example.data.model

data class TripDashboardSummary(
    val totalDistanceKm: Double,
    val finalBatteryPercent: Double,
    val extraDistanceRemainingKm: Double,
    val totalChargingStops: Int,
    val totalEstimatedCost: Double,
    val isTripSafe: Boolean,
    val segments: List<SegmentAnalysis>,
    val failureReasons: List<String>,
    val totalDriveMinutes: Int = 0,
    val totalChargingMinutes: Int = 0,
    val totalTravelMinutes: Int = 0,
    val averageSpeedKmh: Double = 45.0,
    val chargingSpeedPercentPerMin: Double = 0.0,
    val chargingCyclesUsed: Int = 0,
    val isChargingTimeFromHistory: Boolean = false,
    val estimatedFullChargeMinutes: Int = 0
)
