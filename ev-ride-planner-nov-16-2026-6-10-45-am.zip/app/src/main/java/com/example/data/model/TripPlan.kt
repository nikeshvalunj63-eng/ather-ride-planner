package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trip_plans")
data class TripPlan(
    @PrimaryKey val id: String,
    val title: String,
    val vehicleName: String,
    val vehicleRange100: Double,
    val startingBatteryPercent: Double,
    val reserveMarginPercent: Double = 15.0,
    val batteryCapacityKWh: Double = 3.7,
    val stopsJson: String,
    val weatherCondition: String = "Clear",
    val createdAt: Long = System.currentTimeMillis()
)
