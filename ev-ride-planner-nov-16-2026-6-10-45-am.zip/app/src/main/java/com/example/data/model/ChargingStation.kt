package com.example.data.model

data class ChargingStation(
    val id: String,
    val name: String,
    val provider: String,
    val city: String,
    val address: String,
    val powerKw: Double,
    val connectorTypes: String,
    val isFavorite: Boolean = false,
    val costPerKwh: Double = 18.5,
    val latitude: Double,
    val longitude: Double,
    val distanceFromUserKm: Double? = null,
    val isLiveFetched: Boolean = false,
    val operatorPhone: String = "",
    val operatorWebsite: String = "",
    val openingHours: String = "24/7",
    val bayCapacity: Int = 2,
    val authMethods: String = "App / RFID / UPI",
    val ocpiNetworkCode: String = ""
)
