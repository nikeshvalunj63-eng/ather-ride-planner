package com.example.data.model

data class VehiclePreset(
    val id: String,
    val name: String,
    val category: String, // "Electric Scooter", "Electric Motorcycle", "Electric Car"
    val range100Km: Double,
    val batteryCapacityKWh: Double,
    val recommendedReserveMargin: Double = 15.0,
    val averageSpeedKmh: Double = 45.0,
    val compatibleConnectors: Set<String> = setOf("Type 2")
) {
    companion object {
        val PRESETS = listOf(
            VehiclePreset(
                id = "ather_450x",
                name = "Ather 450X Gen 3",
                category = "Electric Scooter",
                range100Km = 110.0,
                batteryCapacityKWh = 3.7,
                recommendedReserveMargin = 15.0,
                averageSpeedKmh = 45.0,
                compatibleConnectors = setOf("Ather Fast Dot", "Type 2", "AC 3-Pin (15A)")
            ),
            VehiclePreset(
                id = "ola_s1_pro",
                name = "Ola S1 Pro Gen 2",
                category = "Electric Scooter",
                range100Km = 145.0,
                batteryCapacityKWh = 4.0,
                recommendedReserveMargin = 15.0,
                averageSpeedKmh = 48.0,
                compatibleConnectors = setOf("AC 3-Pin (15A)", "Bharat AC-001")
            ),
            VehiclePreset(
                id = "tvs_iqube",
                name = "TVS iQube ST",
                category = "Electric Scooter",
                range100Km = 120.0,
                batteryCapacityKWh = 4.5,
                recommendedReserveMargin = 15.0,
                averageSpeedKmh = 42.0,
                compatibleConnectors = setOf("AC 3-Pin (15A)", "Type 2")
            ),
            VehiclePreset(
                id = "ultraviolette_f77",
                name = "Ultraviolette F77 Mach 2",
                category = "Electric Motorcycle",
                range100Km = 240.0,
                batteryCapacityKWh = 10.3,
                recommendedReserveMargin = 15.0,
                averageSpeedKmh = 65.0,
                compatibleConnectors = setOf("Type 2", "CCS2", "AC 3-Pin (15A)")
            ),
            VehiclePreset(
                id = "revolt_rv400",
                name = "Revolt RV400",
                category = "Electric Motorcycle",
                range100Km = 130.0,
                batteryCapacityKWh = 3.24,
                recommendedReserveMargin = 15.0,
                averageSpeedKmh = 50.0,
                compatibleConnectors = setOf("AC 3-Pin (15A)", "Bharat AC-001")
            ),
            VehiclePreset(
                id = "tata_nexon_ev",
                name = "Tata Nexon.ev Long Range",
                category = "Electric Car",
                range100Km = 360.0,
                batteryCapacityKWh = 40.5,
                recommendedReserveMargin = 15.0,
                averageSpeedKmh = 68.0,
                compatibleConnectors = setOf("CCS2", "Type 2", "Bharat DC-001")
            ),
            VehiclePreset(
                id = "mg_zs_ev",
                name = "MG ZS EV",
                category = "Electric Car",
                range100Km = 380.0,
                batteryCapacityKWh = 50.3,
                recommendedReserveMargin = 15.0,
                averageSpeedKmh = 70.0,
                compatibleConnectors = setOf("CCS2", "Type 2")
            ),
            VehiclePreset(
                id = "tesla_model_3",
                name = "Tesla Model 3 Long Range",
                category = "Electric Car",
                range100Km = 520.0,
                batteryCapacityKWh = 75.0,
                recommendedReserveMargin = 12.0,
                averageSpeedKmh = 80.0,
                compatibleConnectors = setOf("NACS/Tesla", "CCS2", "Type 2")
            )
        )
    }
}
