package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.ChargingCycle
import kotlinx.coroutines.flow.Flow

@Dao
interface ChargingCycleDao {

    @Query("SELECT * FROM charging_cycles ORDER BY createdAt DESC")
    fun getAllCycles(): Flow<List<ChargingCycle>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCycle(cycle: ChargingCycle)

    @Query("DELETE FROM charging_cycles WHERE id = :cycleId")
    suspend fun deleteCycleById(cycleId: String)
}
