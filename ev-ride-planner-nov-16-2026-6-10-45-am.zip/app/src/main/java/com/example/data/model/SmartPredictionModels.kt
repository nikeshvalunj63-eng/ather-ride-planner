package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

enum class AcUsageMode(val label: String, val powerKw: Double) {
    OFF("Off", 0.0),
    ECO("Eco AC", 1.1),
    FULL("Max AC", 2.2)
}

enum class RidingMode(val label: String, val multiplier: Double) {
    ECO("Eco", 0.88),
    NORMAL("Ride", 1.00),
    SPORT("Sport", 1.16),
    WARP("Warp", 1.30)
}

enum class PredictionSafetyStatus(val label: String) {
    SAFE("SAFE"),
    LOW_RESERVE("LOW RESERVE"),
    CRITICAL("CRITICAL")
}

data class SmartPredictionInput(
    val currentBatteryPercent: Double = 100.0,
    val distanceKm: Double = 45.0,
    val vehicleEfficiencyWhPerKm: Double = 33.6,
    val batteryCapacityKWh: Double = 3.7,
    val reserveMarginPercent: Double = 15.0,
    val speedKmh: Double = 45.0,
    val elevationGainMeters: Double = 120.0,
    val payloadKg: Double = 75.0,
    val weatherCondition: String = "Clear",
    val vehicleCategory: String = "Electric Scooter",
    val acUsageMode: AcUsageMode = AcUsageMode.OFF,
    val ridingMode: RidingMode = RidingMode.NORMAL,
    val vehicleName: String = "Ather 450X Gen 3",
    val compatibleConnectors: Set<String> = emptySet(),
    val useMlCalibrationIfReady: Boolean = true
) {
    val isCar: Boolean
        get() = vehicleCategory.equals("Electric Car", ignoreCase = true)

    val isTwoWheeler: Boolean
        get() = !isCar
}

data class EnergyComponentBreakdown(
    val baseDriveWh: Double,
    val speedDeltaWh: Double,
    val ridingModeDeltaWh: Double,
    val payloadDeltaWh: Double,
    val weatherDeltaWh: Double,
    val elevationDeltaWh: Double,
    val acAuxiliaryWh: Double,
    val mlResidualAdjustmentWh: Double,
    val totalWh: Double,
    val formulaSummary: String
)

data class RecommendedChargingPoint(
    val station: ChargingStation? = null,
    val headline: String,
    val detail: String,
    val actionRequired: Boolean,
    val recommendedTargetChargePercent: Double = 85.0,
    val safeMaxReachKm: Double = 0.0,
    val estimatedChargeMinutes: Int = 0
)

data class MlCalibrationStatus(
    val reliableTripsCount: Int,
    val requiredTripsForMl: Int = 10,
    val isMlReady: Boolean,
    val isMlActive: Boolean,
    val learnedScaleFactor: Double = 1.0,
    val meanAbsoluteErrorPercent: Double? = null,
    val statusHeadline: String
)

data class SmartPredictionResult(
    val expectedArrivalBatteryPercent: Double,
    val clampedArrivalBatteryPercent: Double,
    val energyConsumedKwh: Double,
    val energyConsumedPercent: Double,
    val effectiveWhPerKm: Double,
    val predictedRangeKm: Double,
    val safetyMarginPercent: Double,
    val surplusDistanceKm: Double,
    val safetyStatus: PredictionSafetyStatus,
    val estimatedTravelMinutes: Int,
    val breakdown: EnergyComponentBreakdown,
    val recommendedChargingPoint: RecommendedChargingPoint,
    val mlCalibrationStatus: MlCalibrationStatus
)

@Entity(tableName = "trip_telemetry_records")
data class TripTelemetryRecord(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val vehicleName: String,
    val vehicleCategory: String,
    val distanceKm: Double,
    val speedKmh: Double,
    val elevationGainMeters: Double,
    val payloadKg: Double,
    val weatherCondition: String,
    val acUsageMode: String = AcUsageMode.OFF.name,
    val ridingMode: String = RidingMode.NORMAL.name,
    val efficiencyWhPerKm: Double,
    val mathPredictedPercent: Double,
    val actualConsumedPercent: Double,
    val notes: String = "",
    val isReliable: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)
