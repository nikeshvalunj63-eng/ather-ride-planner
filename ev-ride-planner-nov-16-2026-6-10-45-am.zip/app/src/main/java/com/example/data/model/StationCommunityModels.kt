package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class ReportCategory(val value: String, val label: String) {
    CHARGER_DOWN("CHARGER_DOWN", "Charger Not Working"),
    WRONG_LOCATION("WRONG_LOCATION", "Incorrect Location")
}

enum class AvailabilityStatus(val value: String, val label: String) {
    WORKING("WORKING", "Working & Available"),
    BUSY("BUSY", "Busy / In Use"),
    NOT_WORKING("NOT_WORKING", "Not Working")
}

@IgnoreExtraProperties
data class StationReport(
    @DocumentId val id: String = "",
    val userId: String = "",
    val authorLabel: String = "",
    val stationId: String = "",
    val stationName: String = "",
    val operatorName: String = "",
    val reportCategory: String = ReportCategory.CHARGER_DOWN.value,
    val issueReason: String = "",
    val notes: String = "",
    val suggestedLat: Double = 0.0,
    val suggestedLon: Double = 0.0,
    val status: String = "open",
    val visibility: String = "community",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class StationConfirmation(
    @DocumentId val id: String = "",
    val userId: String = "",
    val authorLabel: String = "",
    val stationId: String = "",
    val stationName: String = "",
    val availabilityStatus: String = AvailabilityStatus.WORKING.value,
    val connectorUsed: String = "",
    val comment: String = "",
    val visibility: String = "community",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class StationPhoto(
    @DocumentId val id: String = "",
    val userId: String = "",
    val authorLabel: String = "",
    val stationId: String = "",
    val stationName: String = "",
    val caption: String = "",
    val imageBase64: String = "",
    val visibility: String = "community",
    @ServerTimestamp val createdAt: Timestamp? = null
)

data class StationCommunitySummary(
    val stationId: String,
    val workingCount: Int = 0,
    val busyCount: Int = 0,
    val notWorkingCount: Int = 0,
    val openDownReports: Int = 0,
    val wrongLocationReports: Int = 0,
    val photoCount: Int = 0,
    val latestConfirmationMillis: Long? = null,
    val latestConfirmerName: String? = null,
    val userVote: AvailabilityStatus? = null
) {
    val totalConfirmations: Int get() = workingCount + busyCount + notWorkingCount

    val headlineStatus: String
        get() = when {
            openDownReports > 0 || notWorkingCount > workingCount -> "Reported Not Working"
            workingCount > 0 && workingCount >= busyCount -> "Community Verified ($workingCount)"
            busyCount > 0 -> "Busy ($busyCount reports)"
            wrongLocationReports > 0 -> "Location Flagged"
            else -> "Unverified"
        }
}

object StationCommunityAggregator {
    fun buildSummaryMap(
        reports: List<StationReport>,
        confirmations: List<StationConfirmation>,
        photos: List<StationPhoto>,
        currentUserId: String?
    ): Map<String, StationCommunitySummary> {
        val allStationIds = buildSet {
            reports.forEach { add(it.stationId) }
            confirmations.forEach { add(it.stationId) }
            photos.forEach { add(it.stationId) }
        }

        return allStationIds.associateWith { stId ->
            val stConfirmations = confirmations.filter { it.stationId == stId }
            val stReports = reports.filter { it.stationId == stId && it.status == "open" }
            val stPhotos = photos.filter { it.stationId == stId }

            val latestConf = stConfirmations.maxByOrNull {
                (it.updatedAt ?: it.createdAt)?.toDate()?.time ?: 0L
            }
            val latestMillis = (latestConf?.updatedAt ?: latestConf?.createdAt)?.toDate()?.time
            val userVoteRaw = currentUserId?.let { uid ->
                stConfirmations.firstOrNull { it.userId == uid }?.availabilityStatus
            }
            val userVote = AvailabilityStatus.entries.firstOrNull { it.value == userVoteRaw }

            StationCommunitySummary(
                stationId = stId,
                workingCount = stConfirmations.count { it.availabilityStatus == AvailabilityStatus.WORKING.value },
                busyCount = stConfirmations.count { it.availabilityStatus == AvailabilityStatus.BUSY.value },
                notWorkingCount = stConfirmations.count { it.availabilityStatus == AvailabilityStatus.NOT_WORKING.value },
                openDownReports = stReports.count { it.reportCategory == ReportCategory.CHARGER_DOWN.value },
                wrongLocationReports = stReports.count { it.reportCategory == ReportCategory.WRONG_LOCATION.value },
                photoCount = stPhotos.size,
                latestConfirmationMillis = latestMillis,
                latestConfirmerName = latestConf?.authorLabel,
                userVote = userVote
            )
        }
    }
}
