package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.TripPlan
import kotlinx.coroutines.flow.Flow

@Dao
interface TripDao {

    @Query("SELECT * FROM trip_plans ORDER BY createdAt DESC")
    fun getAllTrips(): Flow<List<TripPlan>>

    @Query("SELECT * FROM trip_plans WHERE id = :tripId LIMIT 1")
    suspend fun getTripById(tripId: String): TripPlan?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateTrip(trip: TripPlan)

    @Delete
    suspend fun deleteTrip(trip: TripPlan)

    @Query("DELETE FROM trip_plans WHERE id = :tripId")
    suspend fun deleteTripById(tripId: String)
}
