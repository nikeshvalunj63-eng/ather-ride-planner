package com.example.data.model

import com.example.domain.GeoUtils
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class CommunityStation(
    @DocumentId val id: String = "",
    val userId: String = "",
    val authorLabel: String = "",
    val name: String = "",
    val provider: String = "",
    val city: String = "",
    val address: String = "",
    val powerKw: Double = 22.0,
    val connectorTypes: String = "Type 2",
    val costPerKwh: Double = 18.0,
    val bayCapacity: Int = 2,
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val openingHours: String = "24/7",
    val notes: String = "",
    val visibility: String = "community",
    @ServerTimestamp val createdAt: Timestamp? = null
) {
    fun toChargingStation(userLatitude: Double? = null, userLongitude: Double? = null): ChargingStation {
        val dist = if (userLatitude != null && userLongitude != null && (latitude != 0.0 || longitude != 0.0)) {
            GeoUtils.haversineDistanceKm(userLatitude, userLongitude, latitude, longitude)
        } else {
            null
        }
        return ChargingStation(
            id = id.ifBlank { "comm_${name.hashCode()}" },
            name = name,
            provider = provider.ifBlank { "Community Hub" },
            city = city,
            address = address,
            powerKw = powerKw,
            connectorTypes = connectorTypes,
            isFavorite = false,
            costPerKwh = costPerKwh,
            latitude = latitude,
            longitude = longitude,
            distanceFromUserKm = dist,
            openingHours = openingHours.ifBlank { "24/7" },
            bayCapacity = bayCapacity.coerceAtLeast(1),
            authMethods = "Community Submitted ($authorLabel)",
            ocpiNetworkCode = "COMM • Rider Added"
        )
    }
}

@IgnoreExtraProperties
data class VerifiedRoute(
    @DocumentId val id: String = "",
    val userId: String = "",
    val authorLabel: String = "",
    val title: String = "",
    val originCity: String = "",
    val destinationCity: String = "",
    val totalDistanceKm: Double = 0.0,
    val elevationGainMeters: Double = 0.0,
    val vehicleName: String = "",
    val vehicleCategory: String = "Electric Scooter",
    val chargingStopsCount: Int = 0,
    val arrivalBatteryPercent: Double = 20.0,
    val weatherCondition: String = "Clear",
    val stopsSummary: String = "",
    val stopsJson: String = "[]",
    val notes: String = "",
    val visibility: String = "community",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class RangeReport(
    @DocumentId val id: String = "",
    val userId: String = "",
    val authorLabel: String = "",
    val vehicleName: String = "",
    val vehicleCategory: String = "Electric Scooter",
    val claimedRangeKm: Double = 110.0,
    val observedRealRangeKm: Double = 90.0,
    val distanceDrivenKm: Double = 45.0,
    val batteryUsedPercent: Double = 50.0,
    val avgEfficiencyWhPerKm: Double = 35.0,
    val avgSpeedKmh: Double = 45.0,
    val weatherCondition: String = "Clear",
    val ridingOrAcMode: String = "Ride",
    val notes: String = "",
    val visibility: String = "community",
    @ServerTimestamp val createdAt: Timestamp? = null
) {
    val realWorldRatioPercent: Double
        get() = if (claimedRangeKm > 0.0) (observedRealRangeKm / claimedRangeKm) * 100.0 else 100.0
}

@IgnoreExtraProperties
data class EvOwnerReview(
    @DocumentId val id: String = "",
    val userId: String = "",
    val authorLabel: String = "",
    val vehicleName: String = "",
    val vehicleCategory: String = "Electric Scooter",
    val rating: Int = 5,
    val ownershipMonths: Int = 6,
    val odometerKm: Int = 2500,
    val headline: String = "",
    val pros: String = "",
    val cons: String = "",
    val reviewText: String = "",
    val visibility: String = "community",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class ChargingExperience(
    @DocumentId val id: String = "",
    val userId: String = "",
    val authorLabel: String = "",
    val stationName: String = "",
    val provider: String = "",
    val vehicleName: String = "",
    val connectorUsed: String = "",
    val peakPowerKw: Double = 22.0,
    val startPercent: Double = 20.0,
    val endPercent: Double = 85.0,
    val durationMinutes: Int = 40,
    val waitTimeMinutes: Int = 0,
    val rating: Int = 5,
    val experienceNotes: String = "",
    val visibility: String = "community",
    @ServerTimestamp val createdAt: Timestamp? = null
) {
    val chargeSpeedPercentPerMin: Double
        get() = if (durationMinutes > 0) (endPercent - startPercent).coerceAtLeast(0.0) / durationMinutes else 0.0
}

@IgnoreExtraProperties
data class TripRecommendation(
    @DocumentId val id: String = "",
    val userId: String = "",
    val authorLabel: String = "",
    val title: String = "",
    val corridor: String = "",
    val totalDistanceKm: Double = 80.0,
    val recommendedCategory: String = "All EVs",
    val difficulty: String = "Easy",
    val bestSeason: String = "All Year",
    val chargingTip: String = "",
    val highlights: String = "",
    val visibility: String = "community",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class CommunityEndorsement(
    @DocumentId val id: String = "",
    val userId: String = "",
    val targetType: String = "ROUTE",
    val targetId: String = "",
    val visibility: String = "community",
    @ServerTimestamp val createdAt: Timestamp? = null
)
