package com.example.data.model

data class ChargingOperatorProfile(
    val id: String,
    val displayName: String,
    val ocpiNetworkId: String,
    val roamingStatus: String,
    val supportPhone: String,
    val portalUrl: String,
    val sessionAuthMethods: String,
    val tariffNote: String
)

object ChargingOperatorCatalog {

    val operators: List<ChargingOperatorProfile> = listOf(
        ChargingOperatorProfile(
            id = "ather",
            displayName = "Ather Grid",
            ocpiNetworkId = "IN-ATH • Ather Telemetry",
            roamingStatus = "Live Grid Integration • Fast Dot & Type-2",
            supportPhone = "18002662843",
            portalUrl = "https://www.atherenergy.com/charging",
            sessionAuthMethods = "Ather App • Auto-Auth • UPI QR",
            tariffNote = "Pay-per-min / Flat grid session"
        ),
        ChargingOperatorProfile(
            id = "tata",
            displayName = "Tata Power EZ Charge",
            ocpiNetworkId = "IN-TPE • OCPI 2.2 Roaming",
            roamingStatus = "Operator Hub Connected • 24x7 NOC",
            supportPhone = "18008332233",
            portalUrl = "https://www.tatapower.com/ezcharge",
            sessionAuthMethods = "EZ Charge App • RFID Card • UPI",
            tariffNote = "Dynamic DC/AC per-kWh tariff"
        ),
        ChargingOperatorProfile(
            id = "statiq",
            displayName = "Statiq",
            ocpiNetworkId = "IN-STQ • OCPI 2.2",
            roamingStatus = "Smart Charger Aggregator • Live Queue",
            supportPhone = "18001230456",
            portalUrl = "https://www.statiq.in",
            sessionAuthMethods = "Statiq App • RFID • Wallet / UPI",
            tariffNote = "Per-kWh + parking grace window"
        ),
        ChargingOperatorProfile(
            id = "jiobp",
            displayName = "Jio-bp pulse",
            ocpiNetworkId = "IN-JBP • OCPI 2.2",
            roamingStatus = "High-Speed Express Corridor Partner",
            supportPhone = "18008919023",
            portalUrl = "https://www.jiobp.com/products-and-services/ev-charging",
            sessionAuthMethods = "Jio-bp pulse App • RFID • Credit/UPI",
            tariffNote = "24/7 fleet & highway ultra-fast rate"
        ),
        ChargingOperatorProfile(
            id = "zeon",
            displayName = "Zeon Charging",
            ocpiNetworkId = "IN-ZEN • OCPI 2.2",
            roamingStatus = "South Highway Fast Corridor Active",
            supportPhone = "09500501201",
            portalUrl = "https://www.zeoncharging.com",
            sessionAuthMethods = "Zeon App • Auto-Charge • UPI",
            tariffNote = "CCS2 & Type-2 metered per-kWh"
        ),
        ChargingOperatorProfile(
            id = "shell",
            displayName = "Shell Recharge",
            ocpiNetworkId = "IN-SHL • OCPI 2.2",
            roamingStatus = "100% Renewable Hub Integration",
            supportPhone = "18002104400",
            portalUrl = "https://www.shell.in/motorists/shell-recharge.html",
            sessionAuthMethods = "Shell Recharge App • Tap Card • UPI",
            tariffNote = "Commercial DC fast tariff"
        )
    )

    fun resolveOperator(
        provider: String,
        stationName: String = "",
        customPhone: String = "",
        customWebsite: String = ""
    ): ChargingOperatorProfile {
        val hay = "$provider $stationName".lowercase()
        val matched = when {
            hay.contains("ather") -> operators[0]
            hay.contains("tata") -> operators[1]
            hay.contains("statiq") -> operators[2]
            hay.contains("jio") -> operators[3]
            hay.contains("zeon") -> operators[4]
            hay.contains("shell") -> operators[5]
            else -> ChargingOperatorProfile(
                id = "public",
                displayName = provider.ifBlank { "Public EV Operator" },
                ocpiNetworkId = "OSM / OpenCharge Hub",
                roamingStatus = "Public Directory Listing",
                supportPhone = customPhone,
                portalUrl = customWebsite.ifBlank { "https://www.openstreetmap.org" },
                sessionAuthMethods = "Operator App • QR / RFID",
                tariffNote = "Check on-site kiosk tariff"
            )
        }
        return matched.copy(
            supportPhone = customPhone.ifBlank { matched.supportPhone },
            portalUrl = customWebsite.ifBlank { matched.portalUrl }
        )
    }
}
