package com.example.domain

import com.example.data.model.ChargingCycle
import com.example.data.model.SegmentAnalysis
import com.example.data.model.Stop
import com.example.data.model.StopType
import com.example.data.model.TripDashboardSummary
import kotlin.math.ceil
import kotlin.math.roundToInt

object BatteryCalculator {

    fun getWeatherMultiplier(weatherCondition: String): Double {
        return when (weatherCondition) {
            "Rain / Headwind" -> 1.15
            "Extreme Cold (<5°C)" -> 1.25
            "Hot (>35°C)" -> 1.08
            "Hilly / Elevation" -> 1.20
            else -> 1.0 // Clear / Normal
        }
    }

    fun getWeatherSpeedFactor(weatherCondition: String): Double {
        return when (weatherCondition) {
            "Rain / Headwind" -> 0.88
            "Extreme Cold (<5°C)" -> 0.92
            "Hot (>35°C)" -> 0.96
            "Hilly / Elevation" -> 0.80
            else -> 1.0
        }
    }

    fun calculateTrip(
        vehicleRange100: Double,
        startingBatteryPercent: Double,
        reserveMarginPercent: Double,
        batteryCapacityKWh: Double,
        stops: List<Stop>,
        weatherCondition: String,
        vehicleName: String = "",
        chargingCycles: List<ChargingCycle> = emptyList(),
        averageSpeedKmh: Double = 45.0
    ): TripDashboardSummary {
        val safeRange = vehicleRange100.coerceAtLeast(1.0)
        val safeSpeedKmh = averageSpeedKmh.coerceIn(5.0, 200.0)
        val effectiveSpeedKmh = (safeSpeedKmh * getWeatherSpeedFactor(weatherCondition)).coerceAtLeast(5.0)
        val weatherMultiplier = getWeatherMultiplier(weatherCondition)

        val speedProfile = ChargingTimeEstimator.buildSpeedProfile(
            vehicleName = vehicleName,
            batteryCapacityKWh = batteryCapacityKWh,
            defaultChargerPowerKw = 3.3,
            cycles = chargingCycles
        )

        if (stops.size < 2) {
            val clampedStart = startingBatteryPercent.coerceIn(0.0, 100.0)
            return TripDashboardSummary(
                totalDistanceKm = 0.0,
                finalBatteryPercent = clampedStart,
                extraDistanceRemainingKm = (clampedStart / 100.0) * safeRange / weatherMultiplier,
                totalChargingStops = 0,
                totalEstimatedCost = 0.0,
                isTripSafe = clampedStart >= reserveMarginPercent,
                segments = emptyList(),
                failureReasons = if (clampedStart < reserveMarginPercent) {
                    listOf("Starting battery (${String.format("%.0f", clampedStart)}%) is below reserve margin (${String.format("%.0f", reserveMarginPercent)}%).")
                } else emptyList(),
                totalDriveMinutes = 0,
                totalChargingMinutes = 0,
                totalTravelMinutes = 0,
                averageSpeedKmh = safeSpeedKmh,
                chargingSpeedPercentPerMin = speedProfile.avgPercentPerMinute,
                chargingCyclesUsed = speedProfile.cyclesUsedCount,
                isChargingTimeFromHistory = speedProfile.isBasedOnHistory,
                estimatedFullChargeMinutes = speedProfile.estimatedFullChargeMinutes
            )
        }

        val segments = mutableListOf<SegmentAnalysis>()
        val failureReasons = mutableListOf<String>()

        var currentDepartureBattery = startingBatteryPercent.coerceIn(0.0, 100.0)
        var totalDistance = 0.0
        var totalCost = 0.0
        var totalDriveMinutes = 0
        var totalChargingMinutes = 0
        var isTripSafe = true

        for (i in 0 until stops.size - 1) {
            val from = stops[i]
            val to = stops[i + 1]
            val distance = from.distanceToNextKm.coerceAtLeast(0.0)
            totalDistance += distance

            val segmentDriveMinutes = if (distance > 0.0) {
                ceil((distance / effectiveSpeedKmh) * 60.0).toInt().coerceAtLeast(1)
            } else {
                0
            }
            totalDriveMinutes += segmentDriveMinutes

            // Consumption formula: (distance / 100% Range) * 100 * weatherFactor
            val consumedPercent = (distance / safeRange) * 100.0 * weatherMultiplier
            val arrivalBattery = currentDepartureBattery - consumedPercent

            val isCritical = arrivalBattery <= 0.0
            val isSafe = arrivalBattery >= reserveMarginPercent

            if (isCritical) {
                isTripSafe = false
                val shortfallKm = ((0.0 - arrivalBattery) / (100.0 * weatherMultiplier)) * safeRange
                failureReasons.add(
                    "CRITICAL: Battery exhausts to 0% before reaching '${to.name}' (${String.format("%.1f", distance)} km leg). Estimated shortfall: ~${String.format("%.1f", shortfallKm)} km."
                )
            } else if (!isSafe) {
                isTripSafe = false
                failureReasons.add(
                    "WARNING: Arrival at '${to.name}' is ${String.format("%.1f", arrivalBattery)}%, breaching minimum safety reserve (${String.format("%.0f", reserveMarginPercent)}%)."
                )
            }

            // Charging at 'to' stop if it's a CHARGING_STATION or HOME
            var nextDepartureBattery = arrivalBattery.coerceAtLeast(0.0)
            var segmentChargingCost = 0.0
            var segmentChargingMinutes = 0

            if (to.type == StopType.CHARGING_STATION || to.type == StopType.HOME) {
                val targetCharge = to.actualChargedBatteryPercent ?: to.targetBatteryAfterChargePercent
                if (targetCharge > arrivalBattery) {
                    val startCharge = arrivalBattery.coerceAtLeast(0.0)
                    val addedPercent = (targetCharge - startCharge).coerceIn(0.0, 100.0)
                    val addedKWh = (addedPercent / 100.0) * batteryCapacityKWh.coerceAtLeast(1.0)
                    segmentChargingCost = addedKWh * to.costPerUnitInr
                    totalCost += segmentChargingCost

                    segmentChargingMinutes = ChargingTimeEstimator.estimateMinutes(
                        fromPercent = startCharge,
                        toPercent = targetCharge.coerceIn(0.0, 100.0),
                        batteryCapacityKWh = batteryCapacityKWh,
                        chargerPowerKw = to.chargerPowerKw,
                        speedProfile = speedProfile
                    )
                    totalChargingMinutes += segmentChargingMinutes
                    nextDepartureBattery = targetCharge.coerceIn(0.0, 100.0)
                }
            }

            segments.add(
                SegmentAnalysis(
                    fromStop = from,
                    toStop = to,
                    distanceKm = distance,
                    batteryConsumedPercent = consumedPercent,
                    arrivalBatteryPercent = arrivalBattery,
                    departureBatteryPercent = nextDepartureBattery,
                    isSafe = isSafe,
                    isCritical = isCritical,
                    chargingCost = segmentChargingCost,
                    chargingMinutes = segmentChargingMinutes,
                    driveMinutes = segmentDriveMinutes,
                    isChargingTimeFromHistory = speedProfile.isBasedOnHistory
                )
            )

            currentDepartureBattery = nextDepartureBattery
        }

        val finalArrivalBattery = segments.lastOrNull()?.arrivalBatteryPercent ?: startingBatteryPercent
        val extraDistPossible = if (finalArrivalBattery > 0.0) {
            (finalArrivalBattery / 100.0) * safeRange / weatherMultiplier
        } else {
            0.0
        }

        val chargingStopsCount = stops.drop(1).count { it.type == StopType.CHARGING_STATION }
        val totalTravelMinutes = totalDriveMinutes + totalChargingMinutes

        return TripDashboardSummary(
            totalDistanceKm = totalDistance,
            finalBatteryPercent = finalArrivalBattery,
            extraDistanceRemainingKm = extraDistPossible,
            totalChargingStops = chargingStopsCount,
            totalEstimatedCost = totalCost,
            isTripSafe = isTripSafe,
            segments = segments,
            failureReasons = failureReasons,
            totalDriveMinutes = totalDriveMinutes,
            totalChargingMinutes = totalChargingMinutes,
            totalTravelMinutes = totalTravelMinutes,
            averageSpeedKmh = (effectiveSpeedKmh * 10.0).roundToInt() / 10.0,
            chargingSpeedPercentPerMin = speedProfile.avgPercentPerMinute,
            chargingCyclesUsed = speedProfile.cyclesUsedCount,
            isChargingTimeFromHistory = speedProfile.isBasedOnHistory,
            estimatedFullChargeMinutes = speedProfile.estimatedFullChargeMinutes
        )
    }
}
