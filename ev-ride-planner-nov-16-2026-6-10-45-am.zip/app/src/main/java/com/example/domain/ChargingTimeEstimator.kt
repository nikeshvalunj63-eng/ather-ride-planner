package com.example.domain

import com.example.data.model.ChargingCycle
import kotlin.math.roundToInt

data class ChargingSpeedProfile(
    val avgPercentPerMinute: Double,
    val cyclesUsedCount: Int,
    val isBasedOnHistory: Boolean,
    val estimatedFullChargeMinutes: Int
)

object ChargingTimeEstimator {

    fun buildSpeedProfile(
        vehicleName: String,
        batteryCapacityKWh: Double,
        defaultChargerPowerKw: Double,
        cycles: List<ChargingCycle>
    ): ChargingSpeedProfile {
        val validCycles = cycles
            .filter { it.durationMinutes > 0 && it.percentGained > 0.5 }
            .sortedByDescending { it.createdAt }

        val vehicleCycles = validCycles.filter {
            it.vehicleName.equals(vehicleName, ignoreCase = true)
        }

        val targetCycles = if (vehicleCycles.isNotEmpty()) vehicleCycles else validCycles

        if (targetCycles.isNotEmpty()) {
            // Weighted average giving more weight to recent charging cycles
            var weightedRateSum = 0.0
            var totalWeight = 0.0
            targetCycles.forEachIndexed { index, cycle ->
                val weight = 1.0 / (index + 1).toDouble()
                weightedRateSum += cycle.percentPerMinute * weight
                totalWeight += weight
            }
            val avgRate = if (totalWeight > 0.0) weightedRateSum / totalWeight else 0.0
            val fullMinutes = if (avgRate > 0.0) (100.0 / avgRate).roundToInt() else 0

            return ChargingSpeedProfile(
                avgPercentPerMinute = avgRate,
                cyclesUsedCount = targetCycles.size,
                isBasedOnHistory = true,
                estimatedFullChargeMinutes = fullMinutes
            )
        }

        // Fallback physics estimate if user hasn't logged any previous charging cycle yet
        val safeKw = defaultChargerPowerKw.coerceAtLeast(0.5)
        val safeCap = batteryCapacityKWh.coerceAtLeast(0.5)
        val fullHours = (safeCap / safeKw) * 1.10 // 10% charging loss factor
        val fullMinutes = (fullHours * 60.0).roundToInt().coerceAtLeast(1)
        val fallbackRate = 100.0 / fullMinutes.toDouble()

        return ChargingSpeedProfile(
            avgPercentPerMinute = fallbackRate,
            cyclesUsedCount = 0,
            isBasedOnHistory = false,
            estimatedFullChargeMinutes = fullMinutes
        )
    }

    fun estimateMinutes(
        fromPercent: Double,
        toPercent: Double,
        batteryCapacityKWh: Double,
        chargerPowerKw: Double,
        speedProfile: ChargingSpeedProfile
    ): Int {
        val start = fromPercent.coerceIn(0.0, 100.0)
        val target = toPercent.coerceIn(0.0, 100.0)
        if (target <= start) return 0

        val addedPercent = target - start

        return if (speedProfile.isBasedOnHistory && speedProfile.avgPercentPerMinute > 0.0) {
            (addedPercent / speedProfile.avgPercentPerMinute).roundToInt().coerceAtLeast(1)
        } else {
            val safeKw = chargerPowerKw.coerceAtLeast(0.5)
            val addedKWh = (addedPercent / 100.0) * batteryCapacityKWh.coerceAtLeast(0.5)
            ((addedKWh / safeKw) * 60.0 * 1.10).roundToInt().coerceAtLeast(1)
        }
    }

    fun formatDuration(totalMinutes: Int): String {
        if (totalMinutes <= 0) return "0 min"
        val hours = totalMinutes / 60
        val mins = totalMinutes % 60
        return when {
            hours == 0 -> "$mins min"
            mins == 0 -> "${hours}h"
            else -> "${hours}h ${mins}m"
        }
    }
}
