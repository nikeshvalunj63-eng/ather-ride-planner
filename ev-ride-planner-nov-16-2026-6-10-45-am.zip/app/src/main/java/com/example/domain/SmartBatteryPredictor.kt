package com.example.domain

import com.example.data.model.ChargingCycle
import com.example.data.model.ChargingStation
import com.example.data.model.EnergyComponentBreakdown
import com.example.data.model.EvConnectorCatalog
import com.example.data.model.MlCalibrationStatus
import com.example.data.model.PredictionSafetyStatus
import com.example.data.model.RecommendedChargingPoint
import com.example.data.model.SmartPredictionInput
import com.example.data.model.SmartPredictionResult
import com.example.data.model.StationCommunitySummary
import com.example.data.model.TripTelemetryRecord
import com.example.data.remote.StationCommunityRepository
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Transparent physics-based EV battery consumption and arrival predictor.
 *
 * Strictly uses deterministic mathematical equations until at least
 * [MIN_RELIABLE_TRIPS_FOR_ML] reliable completed trip records are collected,
 * at which point an optional bounded linear residual calibration layer activates.
 */
object SmartBatteryPredictor {

    const val MIN_RELIABLE_TRIPS_FOR_ML = 10
    private const val GRAVITY_MPS2 = 9.81
    private const val UPGRADE_DRIVETRAIN_EFFICIENCY = 0.85
    private const val DOWNGRADE_REGEN_RECOVERY = 0.55

    fun defaultEfficiencyWhPerKm(batteryCapacityKWh: Double, range100Km: Double): Double {
        val wh = (batteryCapacityKWh.coerceAtLeast(0.5) * 1000.0) / range100Km.coerceAtLeast(1.0)
        return (wh * 10.0).roundToInt() / 10.0
    }

    fun baselineVehicleMassKg(vehicleCategory: String): Double {
        return when {
            vehicleCategory.equals("Electric Car", ignoreCase = true) -> 1600.0
            vehicleCategory.equals("Electric Motorcycle", ignoreCase = true) -> 175.0
            else -> 115.0 // Electric Scooter
        }
    }

    fun defaultPayloadKg(vehicleCategory: String): Double {
        return if (vehicleCategory.equals("Electric Car", ignoreCase = true)) 150.0 else 75.0
    }

    fun getWeatherMultiplier(weatherCondition: String): Double {
        return when (weatherCondition) {
            "Rain / Headwind" -> 1.15
            "Extreme Cold (<5°C)" -> 1.25
            "Hot (>35°C)" -> 1.08
            "Hilly / Elevation" -> 1.12
            else -> 1.0 // Clear
        }
    }

    fun getSpeedMultiplier(speedKmh: Double, isCar: Boolean): Double {
        val safeSpeed = speedKmh.coerceIn(5.0, 200.0)
        return if (isCar) {
            (1.0 + (safeSpeed - 65.0) * 0.0065).coerceIn(0.88, 1.45)
        } else {
            (1.0 + (safeSpeed - 45.0) * 0.0085).coerceIn(0.85, 1.55)
        }
    }

    fun getPayloadMultiplier(payloadKg: Double, vehicleCategory: String): Double {
        val baseMass = baselineVehicleMassKg(vehicleCategory)
        val refPayload = defaultPayloadKg(vehicleCategory)
        val safePayload = payloadKg.coerceIn(0.0, 1000.0)
        val refTotalMass = baseMass + refPayload
        val actualTotalMass = baseMass + safePayload
        return (1.0 + ((actualTotalMass - refTotalMass) / refTotalMass) * 0.65).coerceIn(0.90, 1.45)
    }

    fun buildCalibrationStatus(
        telemetryHistory: List<TripTelemetryRecord>,
        vehicleCategory: String,
        useMlCalibrationIfReady: Boolean
    ): MlCalibrationStatus {
        val reliableAll = telemetryHistory.filter {
            it.isReliable &&
                it.distanceKm >= 2.0 &&
                it.actualConsumedPercent in 0.5..99.5 &&
                it.mathPredictedPercent in 0.5..120.0
        }
        val categoryMatches = reliableAll.filter {
            it.vehicleCategory.equals(vehicleCategory, ignoreCase = true)
        }
        val trainingSet = if (categoryMatches.size >= MIN_RELIABLE_TRIPS_FOR_ML) categoryMatches else reliableAll
        val count = reliableAll.size
        val isReady = count >= MIN_RELIABLE_TRIPS_FOR_ML

        if (!isReady) {
            return MlCalibrationStatus(
                reliableTripsCount = count,
                requiredTripsForMl = MIN_RELIABLE_TRIPS_FOR_ML,
                isMlReady = false,
                isMlActive = false,
                learnedScaleFactor = 1.0,
                meanAbsoluteErrorPercent = computeMae(reliableAll),
                statusHeadline = "Transparent Math Model ($count/$MIN_RELIABLE_TRIPS_FOR_ML reliable trips for ML)"
            )
        }

        // Regularized ordinary least squares: y = k * x with ridge prior toward k = 1.0
        val lambda = 3.0
        var sumXY = lambda * 1.0
        var sumXX = lambda * 1.0
        for (record in trainingSet) {
            val x = record.mathPredictedPercent
            val y = record.actualConsumedPercent
            sumXY += x * y
            sumXX += x * x
        }
        val rawSlope = if (sumXX > 0.0) sumXY / sumXX else 1.0
        val learnedFactor = ((rawSlope.coerceIn(0.75, 1.30)) * 1000.0).roundToInt() / 1000.0
        val active = useMlCalibrationIfReady

        return MlCalibrationStatus(
            reliableTripsCount = count,
            requiredTripsForMl = MIN_RELIABLE_TRIPS_FOR_ML,
            isMlReady = true,
            isMlActive = active,
            learnedScaleFactor = learnedFactor,
            meanAbsoluteErrorPercent = computeMae(trainingSet),
            statusHeadline = if (active) {
                "ML Calibration Active ($count trips • ${String.format("%.2f", learnedFactor)}x scale)"
            } else {
                "ML Ready ($count trips) — Using Pure Math Mode"
            }
        )
    }

    private fun computeMae(records: List<TripTelemetryRecord>): Double? {
        if (records.isEmpty()) return null
        val avg = records.map { abs(it.actualConsumedPercent - it.mathPredictedPercent) }.average()
        return (avg * 100.0).roundToInt() / 100.0
    }

    fun predict(
        input: SmartPredictionInput,
        stations: List<ChargingStation> = emptyList(),
        communitySummaries: Map<String, StationCommunitySummary> = emptyMap(),
        chargingCycles: List<ChargingCycle> = emptyList(),
        telemetryHistory: List<TripTelemetryRecord> = emptyList()
    ): SmartPredictionResult {
        val currentBatt = input.currentBatteryPercent.coerceIn(0.0, 100.0)
        val distanceKm = input.distanceKm.coerceAtLeast(0.0)
        val efficiencyWhKm = input.vehicleEfficiencyWhPerKm.coerceIn(10.0, 600.0)
        val capacityWh = input.batteryCapacityKWh.coerceAtLeast(0.5) * 1000.0
        val speedKmh = input.speedKmh.coerceIn(5.0, 200.0)
        val reservePct = input.reserveMarginPercent.coerceIn(0.0, 60.0)

        val baseMass = baselineVehicleMassKg(input.vehicleCategory)
        val totalMassKg = baseMass + input.payloadKg.coerceIn(0.0, 1000.0)

        // 1. Base mechanical/electrical drive demand
        val baseDriveWh = distanceKm * efficiencyWhKm

        // 2. Aerodynamic speed adjustment
        val speedMultiplier = getSpeedMultiplier(speedKmh, input.isCar)
        val afterSpeedWh = baseDriveWh * speedMultiplier
        val speedDeltaWh = afterSpeedWh - baseDriveWh

        // 3. Riding mode adjustment (two-wheelers only)
        val modeMultiplier = if (input.isTwoWheeler) input.ridingMode.multiplier else 1.0
        val afterModeWh = afterSpeedWh * modeMultiplier
        val ridingModeDeltaWh = afterModeWh - afterSpeedWh

        // 4. Payload rolling & inertia mass adjustment
        val payloadMultiplier = getPayloadMultiplier(input.payloadKg, input.vehicleCategory)
        val afterPayloadWh = afterModeWh * payloadMultiplier
        val payloadDeltaWh = afterPayloadWh - afterModeWh

        // 5. Ambient weather multiplier
        val weatherMultiplier = getWeatherMultiplier(input.weatherCondition)
        val afterWeatherWh = afterPayloadWh * weatherMultiplier
        val weatherDeltaWh = afterWeatherWh - afterPayloadWh

        // 6. Gravitational potential energy from net road elevation change
        val elevationDeltaWh = if (distanceKm > 0.0) {
            val rawPotentialWh = (totalMassKg * GRAVITY_MPS2 * input.elevationGainMeters) / 3600.0
            if (input.elevationGainMeters >= 0.0) {
                rawPotentialWh / UPGRADE_DRIVETRAIN_EFFICIENCY
            } else {
                rawPotentialWh * DOWNGRADE_REGEN_RECOVERY
            }
        } else {
            0.0
        }

        // 7. Cabin AC auxiliary load (electric cars only)
        val weatherSpeedFactor = BatteryCalculator.getWeatherSpeedFactor(input.weatherCondition)
        val effectiveSpeedKmh = (speedKmh * weatherSpeedFactor).coerceAtLeast(5.0)
        val travelHours = if (distanceKm > 0.0) distanceKm / effectiveSpeedKmh else 0.0
        val travelMinutes = if (distanceKm > 0.0) ceil(travelHours * 60.0).toInt().coerceAtLeast(1) else 0
        val acAuxiliaryWh = if (input.isCar && distanceKm > 0.0) {
            input.acUsageMode.powerKw * 1000.0 * travelHours
        } else {
            0.0
        }

        // Baseline transparent mathematical energy total
        val mathTotalWh = if (distanceKm > 0.0) {
            max(afterWeatherWh + elevationDeltaWh + acAuxiliaryWh, distanceKm * 5.0)
        } else {
            0.0
        }

        // 8. Gated ML calibration (only active after >= 10 reliable trips are logged)
        val calibrationStatus = buildCalibrationStatus(
            telemetryHistory = telemetryHistory,
            vehicleCategory = input.vehicleCategory,
            useMlCalibrationIfReady = input.useMlCalibrationIfReady
        )
        val mlAdjustmentWh = if (calibrationStatus.isMlActive && mathTotalWh > 0.0) {
            mathTotalWh * (calibrationStatus.learnedScaleFactor - 1.0)
        } else {
            0.0
        }

        val totalEnergyWh = if (distanceKm > 0.0) {
            max(mathTotalWh + mlAdjustmentWh, distanceKm * 5.0)
        } else {
            0.0
        }

        val energyConsumedKwh = totalEnergyWh / 1000.0
        val energyConsumedPercent = (totalEnergyWh / capacityWh) * 100.0
        val expectedArrivalPercent = currentBatt - energyConsumedPercent
        val clampedArrivalPercent = expectedArrivalPercent.coerceIn(0.0, 100.0)

        val effectiveWhPerKm = if (distanceKm > 0.0) {
            totalEnergyWh / distanceKm
        } else {
            efficiencyWhKm * speedMultiplier * modeMultiplier * payloadMultiplier * weatherMultiplier *
                (if (calibrationStatus.isMlActive) calibrationStatus.learnedScaleFactor else 1.0)
        }

        val safetyMarginPercent = expectedArrivalPercent - reservePct
        val predictedRangeKm = ((currentBatt / 100.0) * capacityWh) / effectiveWhPerKm.coerceAtLeast(1.0)
        val surplusDistanceKm = if (expectedArrivalPercent > 0.0) {
            ((expectedArrivalPercent / 100.0) * capacityWh) / effectiveWhPerKm.coerceAtLeast(1.0)
        } else {
            -((0.0 - expectedArrivalPercent) / 100.0 * capacityWh) / effectiveWhPerKm.coerceAtLeast(1.0)
        }

        val safetyStatus = when {
            expectedArrivalPercent <= 0.0 -> PredictionSafetyStatus.CRITICAL
            expectedArrivalPercent < reservePct -> PredictionSafetyStatus.LOW_RESERVE
            else -> PredictionSafetyStatus.SAFE
        }

        val modeLabel = if (input.isCar) "AC=${input.acUsageMode.label}" else "Mode=${input.ridingMode.label}"
        val formulaSummary = if (distanceKm > 0.0) {
            "E = (${String.format("%.1f", distanceKm)}km × ${String.format("%.1f", efficiencyWhKm)}Wh/km)" +
                " × ${String.format("%.2f", speedMultiplier)}[spd]" +
                " × ${String.format("%.2f", modeMultiplier)}[$modeLabel]" +
                " × ${String.format("%.2f", payloadMultiplier)}[mass]" +
                " × ${String.format("%.2f", weatherMultiplier)}[wx]" +
                " + ${String.format("%.0f", elevationDeltaWh)}Wh[elev]" +
                (if (input.isCar) " + ${String.format("%.0f", acAuxiliaryWh)}Wh[AC]" else "") +
                (if (calibrationStatus.isMlActive) " × ${String.format("%.2f", calibrationStatus.learnedScaleFactor)}[ML]" else "")
        } else {
            "Enter distance > 0 km to evaluate full energy equation."
        }

        val breakdown = EnergyComponentBreakdown(
            baseDriveWh = baseDriveWh,
            speedDeltaWh = speedDeltaWh,
            ridingModeDeltaWh = ridingModeDeltaWh,
            payloadDeltaWh = payloadDeltaWh,
            weatherDeltaWh = weatherDeltaWh,
            elevationDeltaWh = elevationDeltaWh,
            acAuxiliaryWh = acAuxiliaryWh,
            mlResidualAdjustmentWh = mlAdjustmentWh,
            totalWh = totalEnergyWh,
            formulaSummary = formulaSummary
        )

        val recommendedPoint = recommendChargingPoint(
            input = input,
            expectedArrivalPercent = expectedArrivalPercent,
            energyConsumedPercent = energyConsumedPercent,
            effectiveWhPerKm = effectiveWhPerKm,
            capacityWh = capacityWh,
            stations = stations,
            communitySummaries = communitySummaries,
            chargingCycles = chargingCycles
        )

        return SmartPredictionResult(
            expectedArrivalBatteryPercent = expectedArrivalPercent,
            clampedArrivalBatteryPercent = clampedArrivalPercent,
            energyConsumedKwh = energyConsumedKwh,
            energyConsumedPercent = energyConsumedPercent,
            effectiveWhPerKm = effectiveWhPerKm,
            predictedRangeKm = predictedRangeKm,
            safetyMarginPercent = safetyMarginPercent,
            surplusDistanceKm = surplusDistanceKm,
            safetyStatus = safetyStatus,
            estimatedTravelMinutes = travelMinutes,
            breakdown = breakdown,
            recommendedChargingPoint = recommendedPoint,
            mlCalibrationStatus = calibrationStatus
        )
    }

    private fun recommendChargingPoint(
        input: SmartPredictionInput,
        expectedArrivalPercent: Double,
        energyConsumedPercent: Double,
        effectiveWhPerKm: Double,
        capacityWh: Double,
        stations: List<ChargingStation>,
        communitySummaries: Map<String, StationCommunitySummary>,
        chargingCycles: List<ChargingCycle>
    ): RecommendedChargingPoint {
        val currentBatt = input.currentBatteryPercent.coerceIn(0.0, 100.0)
        val reservePct = input.reserveMarginPercent.coerceIn(0.0, 60.0)
        val usableBeforeReservePct = (currentBatt - reservePct).coerceAtLeast(0.0)
        val safeMaxReachKm = ((usableBeforeReservePct / 100.0) * capacityWh) / effectiveWhPerKm.coerceAtLeast(1.0)

        // Filter healthy & plug-compatible candidates
        val compatibleStations = stations.filter { station ->
            EvConnectorCatalog.isStationCompatible(input.compatibleConnectors, station.connectorTypes)
        }
        val pool = compatibleStations.ifEmpty { stations }

        val rankedPool = pool.sortedWith(
            compareBy<ChargingStation>(
                { st ->
                    val sum = communitySummaries[StationCommunityRepository.sanitizeId(st.id)]
                    when {
                        sum != null && (sum.openDownReports > 0 || sum.notWorkingCount > sum.workingCount) -> 2
                        sum != null && sum.workingCount > 0 -> 0
                        else -> 1
                    }
                },
                { st -> st.distanceFromUserKm ?: Double.MAX_VALUE },
                { st -> -st.powerKw }
            )
        )

        if (input.distanceKm <= 0.0) {
            val backup = rankedPool.firstOrNull()
            return RecommendedChargingPoint(
                station = backup,
                headline = backup?.name ?: "No route distance entered",
                detail = if (backup != null) {
                    "Nearest compatible charger ready (${backup.powerKw.toInt()} kW • ${backup.city}). Safe reach: ${String.format("%.1f", safeMaxReachKm)} km."
                } else {
                    "Enter trip distance to evaluate charging stop needs."
                },
                actionRequired = false,
                safeMaxReachKm = safeMaxReachKm
            )
        }

        // Trip finishes safely without charging
        if (expectedArrivalPercent >= reservePct) {
            val backup = rankedPool.firstOrNull()
            val backupLine = if (backup != null) {
                val distTag = backup.distanceFromUserKm?.let { "${String.format("%.1f", it)} km away • " } ?: ""
                " Backup: ${backup.name} ($distTag${backup.powerKw.toInt()} kW)."
            } else ""

            return RecommendedChargingPoint(
                station = backup,
                headline = "No Stop Needed — Direct Arrival (${String.format("%.1f", expectedArrivalPercent)}%)",
                detail = "Safe margin of +${String.format("%.1f", expectedArrivalPercent - reservePct)}% above ${reservePct.toInt()}% reserve.$backupLine",
                actionRequired = false,
                safeMaxReachKm = safeMaxReachKm
            )
        }

        // Charging required before or around safeMaxReachKm!
        val deficitPct = (reservePct - expectedArrivalPercent).coerceAtLeast(1.0)
        val recommendedTargetPct = (reservePct + deficitPct.coerceAtMost(75.0) + 10.0).coerceIn(reservePct + 15.0, 95.0)

        // Prefer a healthy station reachable within safeMaxReachKm (ideally near 65-95% of safeMaxReachKm to minimize stops)
        val reachableHealthy = rankedPool.filter { st ->
            val d = st.distanceFromUserKm
            val sum = communitySummaries[StationCommunityRepository.sanitizeId(st.id)]
            val notBroken = sum == null || (sum.openDownReports == 0 && sum.notWorkingCount <= sum.workingCount)
            notBroken && (d == null || d <= safeMaxReachKm.coerceAtLeast(5.0))
        }

        val chosen = reachableHealthy.maxByOrNull { st ->
            // Prefer closer to optimal stop point (around 75% of safe reach if distances known)
            val d = st.distanceFromUserKm ?: 0.0
            val idealKm = (safeMaxReachKm * 0.75).coerceAtMost(input.distanceKm * 0.65)
            val distScore = if (st.distanceFromUserKm != null) -abs(d - idealKm) else -100.0
            val verifiedBonus = if ((communitySummaries[StationCommunityRepository.sanitizeId(st.id)]?.workingCount ?: 0) > 0) 20.0 else 0.0
            distScore + verifiedBonus + (st.powerKw * 0.1)
        } ?: rankedPool.firstOrNull()

        val estArrivalAtChargerPct = if (chosen?.distanceFromUserKm != null && input.distanceKm > 0.0) {
            val legPct = energyConsumedPercent * (chosen.distanceFromUserKm / input.distanceKm).coerceIn(0.05, 1.0)
            (currentBatt - legPct).coerceIn(5.0, 95.0)
        } else {
            reservePct.coerceIn(10.0, 50.0)
        }

        val speedProfile = ChargingTimeEstimator.buildSpeedProfile(
            vehicleName = input.vehicleName,
            batteryCapacityKWh = input.batteryCapacityKWh,
            defaultChargerPowerKw = chosen?.powerKw ?: 22.0,
            cycles = chargingCycles
        )
        val estChargeMins = ChargingTimeEstimator.estimateMinutes(
            fromPercent = estArrivalAtChargerPct,
            toPercent = recommendedTargetPct,
            batteryCapacityKWh = input.batteryCapacityKWh,
            chargerPowerKw = chosen?.powerKw ?: 22.0,
            speedProfile = speedProfile
        )

        return if (chosen != null) {
            val distStr = chosen.distanceFromUserKm?.let { "at ${String.format("%.1f", it)} km" } ?: "in ${chosen.city}"
            RecommendedChargingPoint(
                station = chosen,
                headline = "${chosen.name} (${chosen.powerKw.toInt()} kW)",
                detail = "Reachable max before ${reservePct.toInt()}% reserve is ${String.format("%.1f", safeMaxReachKm)} km. " +
                    "Stop $distStr and charge to ${recommendedTargetPct.toInt()}% (~${ChargingTimeEstimator.formatDuration(estChargeMins)}).",
                actionRequired = true,
                recommendedTargetChargePercent = recommendedTargetPct,
                safeMaxReachKm = safeMaxReachKm,
                estimatedChargeMinutes = estChargeMins
            )
        } else {
            RecommendedChargingPoint(
                station = null,
                headline = "Charge Needed Before ${String.format("%.1f", safeMaxReachKm)} km",
                detail = "Predicted arrival (${String.format("%.1f", expectedArrivalPercent)}%) is below ${reservePct.toInt()}% reserve. Fetch live stations to pick an en-route charger.",
                actionRequired = true,
                recommendedTargetChargePercent = recommendedTargetPct,
                safeMaxReachKm = safeMaxReachKm,
                estimatedChargeMinutes = estChargeMins
            )
        }
    }
}
