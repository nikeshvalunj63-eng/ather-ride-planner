package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import kotlin.math.max

object StationPhotoHelper {

    /**
     * Reads a photo selected from Android Photo Picker (zero storage permission required),
     * downscales to max 480px on the longest edge, compresses to JPEG, and returns Base64
     * well within Firestore's document size constraints.
     */
    suspend fun encodeUriToCompressedBase64(context: Context, uri: Uri): Result<String> =
        withContext(Dispatchers.IO) {
            try {
                val resolver = context.contentResolver
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                resolver.openInputStream(uri)?.use { stream ->
                    BitmapFactory.decodeStream(stream, null, bounds)
                }

                val maxDim = max(bounds.outWidth, bounds.outHeight).coerceAtLeast(1)
                var sampleSize = 1
                while (maxDim / sampleSize > 960) {
                    sampleSize *= 2
                }

                val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
                val decoded = resolver.openInputStream(uri)?.use { stream ->
                    BitmapFactory.decodeStream(stream, null, decodeOpts)
                } ?: return@withContext Result.failure(IllegalArgumentException("Unable to read selected image"))

                val scale = if (max(decoded.width, decoded.height) > 480) {
                    480f / max(decoded.width, decoded.height).toFloat()
                } else {
                    1f
                }

                val targetW = (decoded.width * scale).toInt().coerceAtLeast(1)
                val targetH = (decoded.height * scale).toInt().coerceAtLeast(1)
                val scaled = if (scale < 1f) {
                    Bitmap.createScaledBitmap(decoded, targetW, targetH, true)
                } else {
                    decoded
                }

                val out = ByteArrayOutputStream()
                var quality = 72
                scaled.compress(Bitmap.CompressFormat.JPEG, quality, out)
                while (out.size() > 160_000 && quality > 35) {
                    out.reset()
                    quality -= 10
                    scaled.compress(Bitmap.CompressFormat.JPEG, quality, out)
                }

                if (scaled !== decoded) decoded.recycle()
                scaled.recycle()

                val base64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                Result.success(base64)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    fun decodeBase64ToBitmap(base64: String): Bitmap? {
        if (base64.isBlank()) return null
        return try {
            val bytes = Base64.decode(base64, Base64.DEFAULT)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (_: Exception) {
            null
        }
    }
}
