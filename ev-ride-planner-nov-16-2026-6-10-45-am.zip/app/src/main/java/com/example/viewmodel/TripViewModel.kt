package com.example.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.auth.GoogleAuthHelper.authStateFlow
import com.example.data.local.AppDatabase
import com.example.data.local.TripConverters
import com.example.data.model.AcUsageMode
import com.example.data.model.AvailabilityStatus
import com.example.data.model.ChargingCycle
import com.example.data.model.ChargingExperience
import com.example.data.model.ChargingStation
import com.example.data.model.CommunityEndorsement
import com.example.data.model.CommunityStation
import com.example.data.model.EvConnectorCatalog
import com.example.data.model.EvOwnerReview
import com.example.data.model.GarageVehicle
import com.example.data.model.RangeReport
import com.example.data.model.ReportCategory
import com.example.data.model.RiderProfile
import com.example.data.model.RidingMode
import com.example.data.model.SmartPredictionInput
import com.example.data.model.SmartPredictionResult
import com.example.data.model.StationCommunityAggregator
import com.example.data.model.StationCommunitySummary
import com.example.data.model.StationConfirmation
import com.example.data.model.StationPhoto
import com.example.data.model.StationReport
import com.example.data.model.Stop
import com.example.data.model.StopType
import com.example.data.model.TripDashboardSummary
import com.example.data.model.TripPlan
import com.example.data.model.TripRecommendation
import com.example.data.model.TripTelemetryRecord
import com.example.data.model.VehiclePreset
import com.example.data.model.VerifiedRoute
import com.example.data.remote.EvCommunityRepository
import com.example.data.remote.OverpassStationService
import com.example.data.remote.StationCommunityRepository
import com.example.data.repository.TripRepository
import com.example.domain.BatteryCalculator
import com.example.domain.GeoUtils
import com.example.domain.SmartBatteryPredictor
import com.example.location.LocationHelper
import com.google.firebase.Firebase
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import kotlin.math.roundToInt

data class UiTripState(
    val currentTripId: String? = null,
    val tripVersion: Int = 0,
    val title: String = "My EV Trip",
    val activeVehicleId: String? = null,
    val selectedVehicleName: String = "Ather 450X Gen 3",
    val selectedVehicleCategory: String = "Electric Scooter",
    val vehicleRange100: Double = 110.0,
    val startBattery: Double = 100.0,
    val reserveMargin: Double = 15.0,
    val batteryCapacityKWh: Double = 3.7,
    val averageSpeedKmh: Double = 45.0,
    val compatibleConnectors: Set<String> = setOf("Ather Fast Dot", "Type 2", "AC 3-Pin (15A)"),
    val weatherCondition: String = "Clear",
    // Default route: ONLY Home with 100% charging
    val stops: List<Stop> = defaultHomeOnlyStops(),
    val calculationSummary: TripDashboardSummary = TripDashboardSummary(
        totalDistanceKm = 0.0,
        finalBatteryPercent = 100.0,
        extraDistanceRemainingKm = 110.0,
        totalChargingStops = 0,
        totalEstimatedCost = 0.0,
        isTripSafe = true,
        segments = emptyList(),
        failureReasons = emptyList()
    ),
    val allStations: List<ChargingStation> = emptyList(),
    val favoriteStationIds: Set<String> = emptySet(),
    val stationSearchQuery: String = "",
    val stationRadiusFilterKm: Double? = 100.0, // Default 100 km around live location
    val showCompatibleStationsOnly: Boolean = false,
    val userLatitude: Double? = null,
    val userLongitude: Double? = null,
    val locationAreaLabel: String? = null,
    val isLoadingLocation: Boolean = false,
    val stationStatusMessage: String? = null,
    val riderProfile: RiderProfile = RiderProfile(),
    val showGoogleSignInDialog: Boolean = false,
    val showLogCycleDialog: Boolean = false,
    val logCycleDefaultStation: String = "Home Charger",
    val logCycleDefaultStartPct: Double = 20.0,
    val logCycleDefaultEndPct: Double = 90.0,
    val statusToastMessage: String? = null,
    val communityReports: List<StationReport> = emptyList(),
    val communityConfirmations: List<StationConfirmation> = emptyList(),
    val communityPhotos: List<StationPhoto> = emptyList(),
    val communitySummaries: Map<String, StationCommunitySummary> = emptyMap(),
    val selectedStationForSheet: ChargingStation? = null,
    val selectedStationSheetInitialTab: Int = 0,
    val isSubmittingCommunityAction: Boolean = false,
    val stationWorkingFilterOnly: Boolean = false,
    val smartPredictionInput: SmartPredictionInput = SmartPredictionInput(),
    val smartPredictionResult: SmartPredictionResult = SmartBatteryPredictor.predict(SmartPredictionInput()),
    val predictionSyncVersion: Int = 0,
    val communityStations: List<CommunityStation> = emptyList(),
    val verifiedRoutes: List<VerifiedRoute> = emptyList(),
    val rangeReports: List<RangeReport> = emptyList(),
    val evOwnerReviews: List<EvOwnerReview> = emptyList(),
    val chargingExperiences: List<ChargingExperience> = emptyList(),
    val tripRecommendations: List<TripRecommendation> = emptyList(),
    val communityEndorsements: List<CommunityEndorsement> = emptyList(),
    val selectedCommunityTab: Int = 0,
    val isSubmittingEvCommunity: Boolean = false
)

fun defaultHomeOnlyStops(): List<Stop> = listOf(
    Stop(
        name = "Home",
        type = StopType.HOME,
        distanceToNextKm = 0.0,
        targetBatteryAfterChargePercent = 100.0
    )
)

class TripViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: TripRepository
    private val converters = TripConverters()
    private val curatedStations: List<ChargingStation>
    private var liveOsmStations: List<ChargingStation> = emptyList()
    private var communityRepository: StationCommunityRepository? = null
    private var evCommunityRepository: EvCommunityRepository? = null
    private var firebaseAuth: FirebaseAuth? = null
    private var communitySyncJob: Job? = null

    private val _uiState = MutableStateFlow(UiTripState())
    val uiState: StateFlow<UiTripState> = _uiState.asStateFlow()

    val savedTrips: StateFlow<List<TripPlan>>
    val chargingCycles: StateFlow<List<ChargingCycle>>
    val garageVehicles: StateFlow<List<GarageVehicle>>
    val telemetryRecords: StateFlow<List<TripTelemetryRecord>>
    private var initialGarageApplied = false

    init {
        val db = AppDatabase.getInstance(application)
        repository = TripRepository(
            tripDao = db.tripDao(),
            chargingCycleDao = db.chargingCycleDao(),
            garageVehicleDao = db.garageVehicleDao(),
            tripTelemetryDao = db.tripTelemetryDao()
        )
        curatedStations = repository.getPreloadedStations()

        savedTrips = repository.getAllSavedTrips().stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        chargingCycles = (repository.getAllChargingCycles() ?: MutableStateFlow(emptyList())).stateIn(
            viewModelScope,
            SharingStarted.Eagerly,
            emptyList()
        )

        garageVehicles = (repository.getAllGarageVehicles() ?: MutableStateFlow(emptyList())).stateIn(
            viewModelScope,
            SharingStarted.Eagerly,
            emptyList()
        )

        telemetryRecords = (repository.getAllTelemetryRecords() ?: MutableStateFlow(emptyList())).stateIn(
            viewModelScope,
            SharingStarted.Eagerly,
            emptyList()
        )

        viewModelScope.launch {
            chargingCycles.collect {
                recalculateTrip()
            }
        }

        viewModelScope.launch {
            telemetryRecords.collect {
                recalculateSmartPrediction()
            }
        }

        viewModelScope.launch {
            garageVehicles.collect { vehicles ->
                if (!initialGarageApplied && vehicles.isNotEmpty()) {
                    initialGarageApplied = true
                    val active = vehicles.firstOrNull { it.isActive } ?: vehicles.first()
                    applyGarageVehicleToState(active, showToast = false)
                }
            }
        }

        val initialFavs = curatedStations.filter { it.isFavorite }.map { it.id }.toSet()
        _uiState.update {
            it.copy(
                allStations = curatedStations,
                favoriteStationIds = initialFavs
            )
        }
        initializeFirebaseCommunitySync(application)
        recalculateTrip()
    }

    private fun initializeFirebaseCommunitySync(application: Application) {
        runCatching {
            if (FirebaseApp.getApps(application).isEmpty()) {
                FirebaseApp.initializeApp(application)
            }
            val auth = Firebase.auth
            firebaseAuth = auth
            communityRepository = StationCommunityRepository(application)
            evCommunityRepository = EvCommunityRepository(application)

            viewModelScope.launch {
                auth.authStateFlow().collect { firebaseUser ->
                    if (firebaseUser != null) {
                        onAuthSessionConfirmed(
                            uid = firebaseUser.uid,
                            displayName = firebaseUser.displayName ?: "EV Rider",
                            email = firebaseUser.email ?: "",
                            photoUrl = firebaseUser.photoUrl?.toString()
                        )
                    } else {
                        stopCommunityListeners()
                    }
                }
            }
        }
    }

    private fun startCommunityListeners(uid: String) {
        val repo = communityRepository ?: return
        val evRepo = evCommunityRepository
        if (communitySyncJob?.isActive == true && _uiState.value.riderProfile.uid == uid) return
        communitySyncJob?.cancel()
        communitySyncJob = viewModelScope.launch {
            launch {
                repo.observeCommunityReports()
                    .catch { /* logged in repo */ }
                    .collect { reports ->
                        _uiState.update { current ->
                            val nextSummaries = StationCommunityAggregator.buildSummaryMap(
                                reports = reports,
                                confirmations = current.communityConfirmations,
                                photos = current.communityPhotos,
                                currentUserId = uid
                            )
                            current.copy(
                                communityReports = reports,
                                communitySummaries = nextSummaries
                            )
                        }
                        recalculateSmartPrediction()
                    }
            }
            launch {
                repo.observeCommunityConfirmations()
                    .catch { /* logged in repo */ }
                    .collect { confirmations ->
                        _uiState.update { current ->
                            val nextSummaries = StationCommunityAggregator.buildSummaryMap(
                                reports = current.communityReports,
                                confirmations = confirmations,
                                photos = current.communityPhotos,
                                currentUserId = uid
                            )
                            current.copy(
                                communityConfirmations = confirmations,
                                communitySummaries = nextSummaries
                            )
                        }
                        recalculateSmartPrediction()
                    }
            }
            launch {
                repo.observeCommunityPhotos()
                    .catch { /* logged in repo */ }
                    .collect { photos ->
                        _uiState.update { current ->
                            val nextSummaries = StationCommunityAggregator.buildSummaryMap(
                                reports = current.communityReports,
                                confirmations = current.communityConfirmations,
                                photos = photos,
                                currentUserId = uid
                            )
                            current.copy(
                                communityPhotos = photos,
                                communitySummaries = nextSummaries
                            )
                        }
                        recalculateSmartPrediction()
                    }
            }
            if (evRepo != null) {
                launch {
                    evRepo.observeCommunityStations()
                        .catch { /* logged in repo */ }
                        .collect { list ->
                            _uiState.update { it.copy(communityStations = list) }
                            rebuildAllStations()
                            recalculateSmartPrediction()
                        }
                }
                launch {
                    evRepo.observeVerifiedRoutes()
                        .catch { /* logged in repo */ }
                        .collect { list ->
                            _uiState.update { it.copy(verifiedRoutes = list) }
                        }
                }
                launch {
                    evRepo.observeRangeReports()
                        .catch { /* logged in repo */ }
                        .collect { list ->
                            _uiState.update { it.copy(rangeReports = list) }
                        }
                }
                launch {
                    evRepo.observeOwnerReviews()
                        .catch { /* logged in repo */ }
                        .collect { list ->
                            _uiState.update { it.copy(evOwnerReviews = list) }
                        }
                }
                launch {
                    evRepo.observeChargingExperiences()
                        .catch { /* logged in repo */ }
                        .collect { list ->
                            _uiState.update { it.copy(chargingExperiences = list) }
                        }
                }
                launch {
                    evRepo.observeTripRecommendations()
                        .catch { /* logged in repo */ }
                        .collect { list ->
                            _uiState.update { it.copy(tripRecommendations = list) }
                        }
                }
                launch {
                    evRepo.observeEndorsements()
                        .catch { /* logged in repo */ }
                        .collect { list ->
                            _uiState.update { it.copy(communityEndorsements = list) }
                        }
                }
            }
        }
    }

    private fun stopCommunityListeners() {
        communitySyncJob?.cancel()
        communitySyncJob = null
        _uiState.update {
            it.copy(
                riderProfile = RiderProfile(isSignedIn = false, selectedVehicleName = it.selectedVehicleName),
                communityReports = emptyList(),
                communityConfirmations = emptyList(),
                communityPhotos = emptyList(),
                communitySummaries = emptyMap(),
                communityStations = emptyList(),
                verifiedRoutes = emptyList(),
                rangeReports = emptyList(),
                evOwnerReviews = emptyList(),
                chargingExperiences = emptyList(),
                tripRecommendations = emptyList(),
                communityEndorsements = emptyList()
            )
        }
        rebuildAllStations()
    }

    fun applyVehiclePreset(preset: VehiclePreset) {
        val defaultEff = SmartBatteryPredictor.defaultEfficiencyWhPerKm(preset.batteryCapacityKWh, preset.range100Km)
        _uiState.update {
            it.copy(
                activeVehicleId = null,
                selectedVehicleName = preset.name,
                selectedVehicleCategory = preset.category,
                vehicleRange100 = preset.range100Km,
                batteryCapacityKWh = preset.batteryCapacityKWh,
                reserveMargin = preset.recommendedReserveMargin,
                averageSpeedKmh = preset.averageSpeedKmh,
                compatibleConnectors = preset.compatibleConnectors,
                smartPredictionInput = it.smartPredictionInput.copy(
                    vehicleName = preset.name,
                    vehicleCategory = preset.category,
                    batteryCapacityKWh = preset.batteryCapacityKWh,
                    reserveMarginPercent = preset.recommendedReserveMargin,
                    vehicleEfficiencyWhPerKm = defaultEff,
                    speedKmh = preset.averageSpeedKmh,
                    payloadKg = SmartBatteryPredictor.defaultPayloadKg(preset.category),
                    compatibleConnectors = preset.compatibleConnectors,
                    acUsageMode = if (preset.category.equals("Electric Car", ignoreCase = true)) {
                        AcUsageMode.ECO
                    } else {
                        AcUsageMode.OFF
                    }
                ),
                predictionSyncVersion = it.predictionSyncVersion + 1,
                tripVersion = it.tripVersion + 1
            )
        }
        recalculateTrip()
    }

    fun updateTitle(title: String) {
        _uiState.update { it.copy(title = title) }
    }

    fun updateVehicleName(name: String) {
        _uiState.update { it.copy(selectedVehicleName = name) }
    }

    fun updateRange(range: Double) {
        _uiState.update { it.copy(vehicleRange100 = range.coerceAtLeast(1.0)) }
        recalculateTrip()
    }

    fun updateStartBattery(battery: Double) {
        _uiState.update { it.copy(startBattery = battery.coerceIn(0.0, 100.0)) }
        recalculateTrip()
    }

    fun updateReserveMargin(margin: Double) {
        _uiState.update { it.copy(reserveMargin = margin.coerceIn(0.0, 60.0)) }
        recalculateTrip()
    }

    fun updateCapacity(capacity: Double) {
        _uiState.update { it.copy(batteryCapacityKWh = capacity.coerceAtLeast(0.5)) }
        recalculateTrip()
    }

    fun updateAverageSpeed(speedKmh: Double) {
        _uiState.update { it.copy(averageSpeedKmh = speedKmh.coerceIn(5.0, 200.0)) }
        recalculateTrip()
    }

    fun toggleConnectorType(connector: String) {
        _uiState.update { current ->
            val next = current.compatibleConnectors.toMutableSet()
            if (next.contains(connector)) {
                next.remove(connector)
            } else {
                next.add(connector)
            }
            current.copy(compatibleConnectors = next)
        }
    }

    fun toggleCompatibleStationsOnly() {
        _uiState.update { it.copy(showCompatibleStationsOnly = !it.showCompatibleStationsOnly) }
    }

    fun updateWeather(weather: String) {
        _uiState.update { it.copy(weatherCondition = weather) }
        recalculateTrip()
    }

    // --- Vehicle Garage (Multiple Saved Vehicles & Connector Types) ---

    fun saveCurrentVehicleToGarage() {
        val current = _uiState.value
        saveGarageVehicle(
            id = current.activeVehicleId,
            name = current.selectedVehicleName.ifBlank { "My EV" },
            category = current.selectedVehicleCategory,
            range100Km = current.vehicleRange100,
            batteryCapacityKWh = current.batteryCapacityKWh,
            reserveMarginPercent = current.reserveMargin,
            averageSpeedKmh = current.averageSpeedKmh,
            compatibleConnectors = current.compatibleConnectors,
            setActive = true
        )
    }

    fun saveGarageVehicle(
        id: String? = null,
        name: String,
        category: String,
        range100Km: Double,
        batteryCapacityKWh: Double,
        reserveMarginPercent: Double,
        averageSpeedKmh: Double,
        compatibleConnectors: Set<String>,
        setActive: Boolean = true
    ) {
        val cleanName = name.trim().ifBlank { "My EV" }
        val finalId = id ?: UUID.randomUUID().toString()
        val connectorsCsv = EvConnectorCatalog.toCsv(
            compatibleConnectors.ifEmpty { setOf("Type 2") }
        )
        val vehicle = GarageVehicle(
            id = finalId,
            name = cleanName,
            category = category,
            range100Km = range100Km.coerceAtLeast(1.0),
            batteryCapacityKWh = batteryCapacityKWh.coerceAtLeast(0.5),
            reserveMarginPercent = reserveMarginPercent.coerceIn(0.0, 60.0),
            averageSpeedKmh = averageSpeedKmh.coerceIn(5.0, 200.0),
            compatibleConnectorsCsv = connectorsCsv,
            isActive = setActive
        )

        initialGarageApplied = true
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                repository.saveGarageVehicle(vehicle)
            }
            if (setActive) {
                applyGarageVehicleToState(vehicle, showToast = false)
            }
            _uiState.update {
                it.copy(statusToastMessage = "Saved '$cleanName' to Vehicle Garage!")
            }
        }
    }

    fun selectGarageVehicle(vehicle: GarageVehicle) {
        initialGarageApplied = true
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                repository.setActiveGarageVehicle(vehicle.id)
            }
        }
        applyGarageVehicleToState(vehicle, showToast = true)
    }

    private fun applyGarageVehicleToState(vehicle: GarageVehicle, showToast: Boolean) {
        val defaultEff = SmartBatteryPredictor.defaultEfficiencyWhPerKm(vehicle.batteryCapacityKWh, vehicle.range100Km)
        val connectors = vehicle.compatibleConnectors.ifEmpty { setOf("Type 2") }
        _uiState.update {
            it.copy(
                activeVehicleId = vehicle.id,
                selectedVehicleName = vehicle.name,
                selectedVehicleCategory = vehicle.category,
                vehicleRange100 = vehicle.range100Km,
                batteryCapacityKWh = vehicle.batteryCapacityKWh,
                reserveMargin = vehicle.reserveMarginPercent,
                averageSpeedKmh = vehicle.averageSpeedKmh,
                compatibleConnectors = connectors,
                smartPredictionInput = it.smartPredictionInput.copy(
                    vehicleName = vehicle.name,
                    vehicleCategory = vehicle.category,
                    batteryCapacityKWh = vehicle.batteryCapacityKWh,
                    reserveMarginPercent = vehicle.reserveMarginPercent,
                    vehicleEfficiencyWhPerKm = defaultEff,
                    speedKmh = vehicle.averageSpeedKmh,
                    payloadKg = SmartBatteryPredictor.defaultPayloadKg(vehicle.category),
                    compatibleConnectors = connectors,
                    acUsageMode = if (vehicle.category.equals("Electric Car", ignoreCase = true)) {
                        AcUsageMode.ECO
                    } else {
                        AcUsageMode.OFF
                    }
                ),
                predictionSyncVersion = it.predictionSyncVersion + 1,
                tripVersion = it.tripVersion + 1,
                statusToastMessage = if (showToast) "Switched active EV to '${vehicle.name}'" else it.statusToastMessage
            )
        }
        recalculateTrip()
    }

    fun deleteGarageVehicle(vehicleId: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                repository.deleteGarageVehicle(vehicleId)
            }
            _uiState.update { current ->
                current.copy(
                    activeVehicleId = if (current.activeVehicleId == vehicleId) null else current.activeVehicleId,
                    statusToastMessage = "Removed vehicle from Garage"
                )
            }
        }
    }

    fun resetToHomeOnly() {
        _uiState.update {
            it.copy(
                currentTripId = null,
                title = "My EV Trip",
                startBattery = 100.0,
                stops = defaultHomeOnlyStops(),
                tripVersion = it.tripVersion + 1,
                statusToastMessage = "Reset route to Home (100%)"
            )
        }
        recalculateTrip()
    }

    /**
     * Appends a new stop to the route and sets the previous stop's leg distance
     * to [distanceFromPreviousKm] so the user can smoothly build Home -> Stop 1 -> Stop 2.
     */
    fun addStop(
        name: String,
        type: StopType,
        distanceFromPreviousKm: Double = 0.0,
        targetCharge: Double = if (type == StopType.HOME) 100.0 else 90.0,
        chargerPower: Double = 22.0,
        costPerUnit: Double = 18.0
    ) {
        val list = _uiState.value.stops.toMutableList()
        if (list.isNotEmpty()) {
            val lastIdx = list.size - 1
            list[lastIdx] = list[lastIdx].copy(
                distanceToNextKm = distanceFromPreviousKm.coerceAtLeast(0.0)
            )
        }
        val newStop = Stop(
            name = name.trim(),
            type = type,
            distanceToNextKm = 0.0,
            targetBatteryAfterChargePercent = targetCharge.coerceIn(10.0, 100.0),
            chargerPowerKw = chargerPower,
            costPerUnitInr = costPerUnit
        )
        list.add(newStop)
        _uiState.update { it.copy(stops = list) }
        recalculateTrip()
    }

    fun updateStop(index: Int, updatedStop: Stop) {
        val list = _uiState.value.stops.toMutableList()
        if (index in list.indices) {
            list[index] = updatedStop
            _uiState.update { it.copy(stops = list) }
            recalculateTrip()
        }
    }

    fun deleteStop(index: Int) {
        val list = _uiState.value.stops.toMutableList()
        if (index in list.indices && list.size > 1) {
            list.removeAt(index)
            if (list.isNotEmpty()) {
                val lastIdx = list.size - 1
                list[lastIdx] = list[lastIdx].copy(distanceToNextKm = 0.0)
            }
            _uiState.update { it.copy(stops = list) }
            recalculateTrip()
        }
    }

    fun moveStop(fromIndex: Int, toIndex: Int) {
        val list = _uiState.value.stops.toMutableList()
        if (fromIndex in list.indices && toIndex in list.indices) {
            val item = list.removeAt(fromIndex)
            list.add(toIndex, item)
            // Keep final stop's distanceToNextKm = 0.0
            if (list.isNotEmpty()) {
                val lastIdx = list.size - 1
                list[lastIdx] = list[lastIdx].copy(distanceToNextKm = 0.0)
            }
            _uiState.update { it.copy(stops = list, tripVersion = it.tripVersion + 1) }
            recalculateTrip()
        }
    }

    fun updateActualChargedBattery(stopIndex: Int, actualPercent: Double?) {
        val list = _uiState.value.stops.toMutableList()
        if (stopIndex in list.indices) {
            val s = list[stopIndex]
            list[stopIndex] = s.copy(
                actualChargedBatteryPercent = actualPercent?.coerceIn(0.0, 100.0)
            )
            _uiState.update { it.copy(stops = list) }
            recalculateTrip()
        }
    }

    fun createReturnTrip() {
        val currentStops = _uiState.value.stops
        if (currentStops.size < 2) {
            _uiState.update {
                it.copy(statusToastMessage = "Add at least 1 destination before creating a round trip.")
            }
            return
        }

        // Mirror return leg distances accurately
        val newStops = currentStops.toMutableList()
        val returnStops = mutableListOf<Stop>()
        for (i in currentStops.size - 1 downTo 1) {
            val prevStop = currentStops[i - 1]
            val targetReturnStop = prevStop.copy(
                id = UUID.randomUUID().toString(),
                name = if (i - 1 == 0) "${prevStop.name} (Return)" else "${prevStop.name} (Return)",
                distanceToNextKm = 0.0,
                actualChargedBatteryPercent = null
            )
            // The distance from current stop (i) back to (i-1) equals prevStop.distanceToNextKm
            val currentLast = returnStops.lastOrNull() ?: newStops.last()
            if (returnStops.isEmpty()) {
                newStops[newStops.lastIndex] = currentLast.copy(distanceToNextKm = prevStop.distanceToNextKm)
            } else {
                returnStops[returnStops.lastIndex] = currentLast.copy(distanceToNextKm = prevStop.distanceToNextKm)
            }
            returnStops.add(targetReturnStop)
        }

        val combined = newStops + returnStops
        _uiState.update {
            it.copy(
                stops = combined,
                tripVersion = it.tripVersion + 1,
                statusToastMessage = "Round-trip legs added!"
            )
        }
        recalculateTrip()
    }

    // --- Live Location & Nearby 100 km Charging Stations ---

    fun fetchLiveLocationAndStations(context: Context) {
        if (_uiState.value.isLoadingLocation) return
        _uiState.update {
            it.copy(
                isLoadingLocation = true,
                stationStatusMessage = "Getting live GPS location..."
            )
        }

        viewModelScope.launch {
            val locationResult = LocationHelper.getCurrentLocation(context)
            if (locationResult == null) {
                _uiState.update {
                    it.copy(
                        isLoadingLocation = false,
                        stationStatusMessage = "Could not read GPS fix. Ensure Location is turned on."
                    )
                }
                return@launch
            }

            applyLiveCoordinates(
                latitude = locationResult.latitude,
                longitude = locationResult.longitude,
                areaLabel = locationResult.areaLabel
            )
        }
    }

    fun applyLiveCoordinates(latitude: Double, longitude: Double, areaLabel: String) {
        _uiState.update {
            it.copy(
                userLatitude = latitude,
                userLongitude = longitude,
                locationAreaLabel = areaLabel,
                isLoadingLocation = true,
                stationStatusMessage = "Finding EV chargers within 100 km of $areaLabel..."
            )
        }
        val immediateCount = rebuildAllStations()

        viewModelScope.launch {
            val liveResult = OverpassStationService.fetchNearbyStations(
                latitude = latitude,
                longitude = longitude,
                radiusKm = 100.0
            )

            liveOsmStations = liveResult.getOrDefault(emptyList())
            val nearbyCount = rebuildAllStations()
            val finalNearby = if (nearbyCount > 0) nearbyCount else immediateCount

            val msg = if (liveResult.isFailure && finalNearby == 0) {
                "Live search offline; showing saved EV hubs sorted near to far."
            } else if (finalNearby == 0) {
                "No stations found within 100 km of $areaLabel. Showing nearest EV hubs."
            } else {
                "Live GPS ($areaLabel) • $finalNearby stations within 100 km (Near → Far)"
            }

            _uiState.update {
                it.copy(
                    isLoadingLocation = false,
                    stationStatusMessage = msg
                )
            }
            recalculateSmartPrediction()
        }
    }

    private fun rebuildAllStations(): Int {
        val state = _uiState.value
        val favIds = state.favoriteStationIds
        val lat = state.userLatitude
        val lon = state.userLongitude

        val communityMapped = state.communityStations.map { comm ->
            comm.toChargingStation(lat, lon).copy(
                isFavorite = favIds.contains(comm.id.ifBlank { "comm_${comm.name.hashCode()}" })
            )
        }
        val liveMapped = liveOsmStations.map { st ->
            val d = if (lat != null && lon != null) GeoUtils.haversineDistanceKm(lat, lon, st.latitude, st.longitude) else st.distanceFromUserKm
            st.copy(distanceFromUserKm = d, isFavorite = favIds.contains(st.id))
        }
        val curatedMapped = curatedStations.map { st ->
            val d = if (lat != null && lon != null) GeoUtils.haversineDistanceKm(lat, lon, st.latitude, st.longitude) else null
            st.copy(distanceFromUserKm = d, isFavorite = favIds.contains(st.id))
        }

        val combined = (communityMapped + liveMapped + curatedMapped)
            .distinctBy { "${it.name.lowercase()}_${(it.latitude * 100).roundToInt()}_${(it.longitude * 100).roundToInt()}" }
            .let { list ->
                if (lat != null && lon != null) {
                    list.sortedBy { it.distanceFromUserKm ?: Double.MAX_VALUE }
                } else {
                    list
                }
            }

        _uiState.update { it.copy(allStations = combined) }
        return if (lat != null && lon != null) {
            combined.count { (it.distanceFromUserKm ?: Double.MAX_VALUE) <= 100.0 }
        } else {
            combined.size
        }
    }

    fun updateStationSearchQuery(query: String) {
        _uiState.update { it.copy(stationSearchQuery = query) }
    }

    fun updateStationRadiusFilter(radiusKm: Double?) {
        _uiState.update { it.copy(stationRadiusFilterKm = radiusKm) }
    }

    fun toggleFavoriteStation(stationId: String) {
        _uiState.update { current ->
            val updatedFavs = current.favoriteStationIds.toMutableSet()
            if (updatedFavs.contains(stationId)) {
                updatedFavs.remove(stationId)
            } else {
                updatedFavs.add(stationId)
            }
            val updatedStations = current.allStations.map { st ->
                if (st.id == stationId) st.copy(isFavorite = updatedFavs.contains(stationId)) else st
            }
            current.copy(
                favoriteStationIds = updatedFavs,
                allStations = updatedStations
            )
        }
    }

    fun addStationToTrip(station: ChargingStation) {
        val list = _uiState.value.stops.toMutableList()
        val liveDistanceRounded = station.distanceFromUserKm?.let {
            ((it * 10.0).roundToInt() / 10.0).coerceAtLeast(1.0)
        } ?: 25.0

        val newStop = Stop(
            name = station.name,
            type = StopType.CHARGING_STATION,
            distanceToNextKm = 0.0,
            targetBatteryAfterChargePercent = 90.0,
            chargerPowerKw = station.powerKw,
            costPerUnitInr = station.costPerKwh
        )

        if (list.size == 1) {
            // Only Home exists: connect Home -> Charging Station with live distance
            list[0] = list[0].copy(distanceToNextKm = liveDistanceRounded)
            list.add(newStop)
        } else if (list.last().type == StopType.DESTINATION) {
            // Insert before final Destination
            val insertPos = list.size - 1
            val prevIdx = insertPos - 1
            val originalLegDist = list[prevIdx].distanceToNextKm
            if (originalLegDist > 0.0) {
                val firstHalf = ((originalLegDist / 2.0) * 10.0).roundToInt() / 10.0
                val secondHalf = ((originalLegDist - firstHalf) * 10.0).roundToInt() / 10.0
                list[prevIdx] = list[prevIdx].copy(distanceToNextKm = firstHalf)
                list.add(insertPos, newStop.copy(distanceToNextKm = secondHalf))
            } else {
                list[prevIdx] = list[prevIdx].copy(distanceToNextKm = liveDistanceRounded)
                list.add(insertPos, newStop.copy(distanceToNextKm = 20.0))
            }
        } else {
            val lastIdx = list.size - 1
            list[lastIdx] = list[lastIdx].copy(distanceToNextKm = liveDistanceRounded)
            list.add(newStop)
        }

        _uiState.update {
            it.copy(
                stops = list,
                tripVersion = it.tripVersion + 1,
                statusToastMessage = "Added '${station.name}' to route!"
            )
        }
        recalculateTrip()
    }

    // --- Save / Load / Delete / Export / Import ---

    fun saveCurrentTrip(customTitle: String? = null, saveAsNew: Boolean = false) {
        viewModelScope.launch {
            val current = _uiState.value
            val titleToUse = customTitle?.trim()?.takeIf { it.isNotBlank() } ?: current.title.ifBlank { "My EV Trip" }
            val tripId = if (saveAsNew || current.currentTripId == null) {
                UUID.randomUUID().toString()
            } else {
                current.currentTripId
            }

            val plan = TripPlan(
                id = tripId,
                title = titleToUse,
                vehicleName = current.selectedVehicleName,
                vehicleRange100 = current.vehicleRange100,
                startingBatteryPercent = current.startBattery,
                reserveMarginPercent = current.reserveMargin,
                batteryCapacityKWh = current.batteryCapacityKWh,
                stopsJson = converters.fromStopList(current.stops),
                weatherCondition = current.weatherCondition,
                createdAt = System.currentTimeMillis()
            )

            try {
                withContext(Dispatchers.IO) {
                    repository.saveTrip(plan)
                }
                _uiState.update {
                    it.copy(
                        currentTripId = tripId,
                        title = titleToUse,
                        statusToastMessage = "Saved '$titleToUse' to offline trips!"
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        statusToastMessage = "Failed to save trip: ${e.localizedMessage ?: "Storage error"}"
                    )
                }
            }
        }
    }

    fun loadTrip(trip: TripPlan) {
        val parsedStops = converters.toStopList(trip.stopsJson)
        _uiState.update {
            it.copy(
                currentTripId = trip.id,
                title = trip.title,
                selectedVehicleName = trip.vehicleName,
                vehicleRange100 = trip.vehicleRange100,
                startBattery = trip.startingBatteryPercent,
                reserveMargin = trip.reserveMarginPercent,
                batteryCapacityKWh = trip.batteryCapacityKWh,
                stops = if (parsedStops.isNotEmpty()) parsedStops else defaultHomeOnlyStops(),
                weatherCondition = trip.weatherCondition,
                tripVersion = it.tripVersion + 1,
                statusToastMessage = "Loaded '${trip.title}'"
            )
        }
        recalculateTrip()
    }

    fun deleteSavedTrip(id: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                repository.deleteTrip(id)
            }
            _uiState.update { current ->
                current.copy(
                    currentTripId = if (current.currentTripId == id) null else current.currentTripId,
                    statusToastMessage = "Trip deleted"
                )
            }
        }
    }

    fun exportTripAsJson(): String {
        val state = _uiState.value
        val json = JSONObject().apply {
            put("title", state.title)
            put("vehicleName", state.selectedVehicleName)
            put("vehicleRange100", state.vehicleRange100)
            put("startBattery", state.startBattery)
            put("reserveMargin", state.reserveMargin)
            put("batteryCapacityKWh", state.batteryCapacityKWh)
            put("weatherCondition", state.weatherCondition)
            put("stops", JSONArray(converters.fromStopList(state.stops)))
        }
        return json.toString(2)
    }

    fun importTripFromJson(jsonString: String): Boolean {
        return try {
            val obj = JSONObject(jsonString)
            val title = obj.optString("title", "Imported Trip")
            val vehicle = obj.optString("vehicleName", "Electric Vehicle")
            val range = obj.optDouble("vehicleRange100", 120.0)
            val startBatt = obj.optDouble("startBattery", 100.0)
            val margin = obj.optDouble("reserveMargin", 15.0)
            val cap = obj.optDouble("batteryCapacityKWh", 3.7)
            val weather = obj.optString("weatherCondition", "Clear")
            val stopsArray = obj.optJSONArray("stops")
            val stopsList = converters.toStopList(stopsArray?.toString())

            _uiState.update {
                it.copy(
                    currentTripId = null,
                    title = title,
                    selectedVehicleName = vehicle,
                    vehicleRange100 = range,
                    startBattery = startBatt,
                    reserveMargin = margin,
                    batteryCapacityKWh = cap,
                    weatherCondition = weather,
                    stops = if (stopsList.isNotEmpty()) stopsList else defaultHomeOnlyStops(),
                    tripVersion = it.tripVersion + 1,
                    statusToastMessage = "Imported trip '$title' successfully!"
                )
            }
            recalculateTrip()
            true
        } catch (e: Exception) {
            _uiState.update { it.copy(statusToastMessage = "Failed to import JSON: ${e.localizedMessage}") }
            false
        }
    }

    // --- Google Sign-In & Community Station Operations ---
    fun setGoogleSignInDialogVisible(visible: Boolean) {
        _uiState.update { it.copy(showGoogleSignInDialog = visible) }
    }

    fun onAuthSessionConfirmed(uid: String, displayName: String, email: String, photoUrl: String?) {
        _uiState.update {
            it.copy(
                riderProfile = RiderProfile(
                    uid = uid,
                    isSignedIn = true,
                    displayName = displayName.ifBlank { "EV Rider" },
                    email = email,
                    photoUrl = photoUrl,
                    selectedVehicleName = it.selectedVehicleName,
                    totalKmTracked = 582.4,
                    totalCo2SavedKg = 69.8
                ),
                showGoogleSignInDialog = false
            )
        }
        startCommunityListeners(uid)
    }

    fun onAuthSessionSignedOut() {
        stopCommunityListeners()
        _uiState.update {
            it.copy(
                showGoogleSignInDialog = false,
                statusToastMessage = "Signed out of Google account"
            )
        }
    }

    fun openStationSheet(station: ChargingStation, initialTab: Int = 0) {
        _uiState.update {
            it.copy(
                selectedStationForSheet = station,
                selectedStationSheetInitialTab = initialTab
            )
        }
    }

    fun closeStationSheet() {
        _uiState.update { it.copy(selectedStationForSheet = null) }
    }

    fun toggleWorkingStationsFilter() {
        _uiState.update { it.copy(stationWorkingFilterOnly = !it.stationWorkingFilterOnly) }
    }

    fun submitStationAvailability(
        station: ChargingStation,
        status: AvailabilityStatus,
        connectorUsed: String,
        comment: String
    ) {
        val repo = communityRepository
        val authorLabel = _uiState.value.riderProfile.displayName.ifBlank { "EV Rider" }
        if (repo == null || !_uiState.value.riderProfile.isSignedIn) {
            _uiState.update { it.copy(statusToastMessage = "Please sign in with Google to confirm availability.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isSubmittingCommunityAction = true) }
            val result = repo.confirmStationAvailability(station, status, connectorUsed, comment, authorLabel)
            _uiState.update { current ->
                current.copy(
                    isSubmittingCommunityAction = false,
                    statusToastMessage = if (result.isSuccess) {
                        "Confirmed '${station.name}' as ${status.label}"
                    } else {
                        result.exceptionOrNull()?.localizedMessage ?: "Failed to save availability"
                    }
                )
            }
        }
    }

    fun submitChargerDownReport(
        station: ChargingStation,
        issueReason: String,
        notes: String
    ) {
        val repo = communityRepository
        val authorLabel = _uiState.value.riderProfile.displayName.ifBlank { "EV Rider" }
        if (repo == null || !_uiState.value.riderProfile.isSignedIn) {
            _uiState.update { it.copy(statusToastMessage = "Please sign in with Google to report a charger.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isSubmittingCommunityAction = true) }
            val result = repo.submitStationReport(
                station = station,
                category = ReportCategory.CHARGER_DOWN,
                issueReason = issueReason,
                notes = notes,
                authorLabel = authorLabel
            )
            _uiState.update { current ->
                current.copy(
                    isSubmittingCommunityAction = false,
                    statusToastMessage = if (result.isSuccess) {
                        "Reported '${station.name}' fault to EV community."
                    } else {
                        result.exceptionOrNull()?.localizedMessage ?: "Failed to submit report"
                    }
                )
            }
        }
    }

    fun submitWrongLocationReport(
        station: ChargingStation,
        issueReason: String,
        notes: String,
        suggestedLat: Double,
        suggestedLon: Double
    ) {
        val repo = communityRepository
        val authorLabel = _uiState.value.riderProfile.displayName.ifBlank { "EV Rider" }
        if (repo == null || !_uiState.value.riderProfile.isSignedIn) {
            _uiState.update { it.copy(statusToastMessage = "Please sign in with Google to submit a location fix.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isSubmittingCommunityAction = true) }
            val result = repo.submitStationReport(
                station = station,
                category = ReportCategory.WRONG_LOCATION,
                issueReason = issueReason,
                notes = notes,
                authorLabel = authorLabel,
                suggestedLat = suggestedLat,
                suggestedLon = suggestedLon
            )
            _uiState.update { current ->
                current.copy(
                    isSubmittingCommunityAction = false,
                    statusToastMessage = if (result.isSuccess) {
                        "Submitted pin correction for '${station.name}'."
                    } else {
                        result.exceptionOrNull()?.localizedMessage ?: "Failed to submit location report"
                    }
                )
            }
        }
    }

    fun resolveStationReport(report: StationReport) {
        val repo = communityRepository ?: return
        viewModelScope.launch {
            val result = repo.resolveStationReport(report)
            _uiState.update { current ->
                current.copy(
                    statusToastMessage = if (result.isSuccess) {
                        "Marked report as resolved."
                    } else {
                        result.exceptionOrNull()?.localizedMessage ?: "Could not resolve report"
                    }
                )
            }
        }
    }

    fun uploadStationPhoto(
        station: ChargingStation,
        caption: String,
        imageBase64: String
    ) {
        val repo = communityRepository
        val authorLabel = _uiState.value.riderProfile.displayName.ifBlank { "EV Rider" }
        if (repo == null || !_uiState.value.riderProfile.isSignedIn) {
            _uiState.update { it.copy(statusToastMessage = "Please sign in with Google to upload station photos.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isSubmittingCommunityAction = true) }
            val result = repo.uploadStationPhoto(station, caption, imageBase64, authorLabel)
            _uiState.update { current ->
                current.copy(
                    isSubmittingCommunityAction = false,
                    statusToastMessage = if (result.isSuccess) {
                        "Uploaded station photo!"
                    } else {
                        result.exceptionOrNull()?.localizedMessage ?: "Photo upload failed"
                    }
                )
            }
        }
    }

    fun deleteStationPhoto(photoId: String) {
        val repo = communityRepository ?: return
        viewModelScope.launch {
            val result = repo.deleteStationPhoto(photoId)
            _uiState.update { current ->
                current.copy(
                    statusToastMessage = if (result.isSuccess) {
                        "Station photo deleted."
                    } else {
                        result.exceptionOrNull()?.localizedMessage ?: "Failed to delete photo"
                    }
                )
            }
        }
    }

    fun openLogCycleDialog(
        stationName: String = "Home Charger",
        startPercent: Double = 20.0,
        endPercent: Double = 90.0
    ) {
        _uiState.update {
            it.copy(
                showLogCycleDialog = true,
                logCycleDefaultStation = stationName,
                logCycleDefaultStartPct = startPercent,
                logCycleDefaultEndPct = endPercent
            )
        }
    }

    fun closeLogCycleDialog() {
        _uiState.update { it.copy(showLogCycleDialog = false) }
    }

    fun logChargingCycle(
        stationName: String,
        startPercent: Double,
        endPercent: Double,
        durationMinutes: Int,
        chargerPowerKw: Double = 3.3
    ) {
        val cleanStart = startPercent.coerceIn(0.0, 99.0)
        val cleanEnd = endPercent.coerceIn(cleanStart + 1.0, 100.0)
        val cleanMinutes = durationMinutes.coerceAtLeast(1)
        val currentVehicle = _uiState.value.selectedVehicleName

        val cycle = ChargingCycle(
            vehicleName = currentVehicle,
            stationName = stationName.trim().ifBlank { "Home Charger" },
            startPercent = cleanStart,
            endPercent = cleanEnd,
            durationMinutes = cleanMinutes,
            chargerPowerKw = chargerPowerKw.coerceAtLeast(0.5)
        )

        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                repository.saveChargingCycle(cycle)
            }
            _uiState.update {
                it.copy(
                    showLogCycleDialog = false,
                    statusToastMessage = "Logged ${cleanStart.toInt()}%→${cleanEnd.toInt()}% in $cleanMinutes min. Future estimates updated!"
                )
            }
        }
    }

    fun deleteChargingCycle(cycleId: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                repository.deleteChargingCycle(cycleId)
            }
            _uiState.update { it.copy(statusToastMessage = "Charging cycle deleted") }
        }
    }

    fun clearStatusToast() {
        _uiState.update { it.copy(statusToastMessage = null) }
    }

    // --- Smart Battery Prediction (Transparent Physics Math -> Gated ML Calibration) ---

    fun updatePredictionBattery(percent: Double) {
        updatePredictionInput { it.copy(currentBatteryPercent = percent.coerceIn(1.0, 100.0)) }
    }

    fun updatePredictionDistance(distanceKm: Double) {
        updatePredictionInput { it.copy(distanceKm = distanceKm.coerceIn(0.0, 2000.0)) }
    }

    fun updatePredictionEfficiency(whPerKm: Double) {
        updatePredictionInput { it.copy(vehicleEfficiencyWhPerKm = whPerKm.coerceIn(10.0, 600.0)) }
    }

    fun updatePredictionSpeed(speedKmh: Double) {
        updatePredictionInput { it.copy(speedKmh = speedKmh.coerceIn(5.0, 200.0)) }
    }

    fun updatePredictionElevation(elevationGainMeters: Double) {
        updatePredictionInput { it.copy(elevationGainMeters = elevationGainMeters.coerceIn(-3000.0, 5000.0)) }
    }

    fun updatePredictionPayload(payloadKg: Double) {
        updatePredictionInput { it.copy(payloadKg = payloadKg.coerceIn(0.0, 1000.0)) }
    }

    fun updatePredictionWeather(weather: String) {
        updatePredictionInput { it.copy(weatherCondition = weather) }
    }

    fun updatePredictionVehicleCategory(category: String) {
        val isCar = category.equals("Electric Car", ignoreCase = true)
        updatePredictionInput(bumpSyncVersion = true) { current ->
            val updatedEfficiency = if (current.isCar != isCar) {
                if (isCar) 145.0 else 33.6
            } else {
                current.vehicleEfficiencyWhPerKm
            }
            val updatedCapacity = if (current.isCar != isCar) {
                if (isCar) 40.5 else 3.7
            } else {
                current.batteryCapacityKWh
            }
            val updatedSpeed = if (current.isCar != isCar) {
                if (isCar) 75.0 else 45.0
            } else {
                current.speedKmh
            }
            current.copy(
                vehicleCategory = category,
                vehicleEfficiencyWhPerKm = updatedEfficiency,
                batteryCapacityKWh = updatedCapacity,
                speedKmh = updatedSpeed,
                payloadKg = SmartBatteryPredictor.defaultPayloadKg(category),
                acUsageMode = if (isCar && current.acUsageMode == AcUsageMode.OFF) AcUsageMode.ECO else current.acUsageMode
            )
        }
    }

    fun updatePredictionAcMode(acMode: AcUsageMode) {
        updatePredictionInput { it.copy(acUsageMode = acMode) }
    }

    fun updatePredictionRidingMode(ridingMode: RidingMode) {
        updatePredictionInput { it.copy(ridingMode = ridingMode) }
    }

    fun setMlCalibrationEnabled(enabled: Boolean) {
        updatePredictionInput { it.copy(useMlCalibrationIfReady = enabled) }
    }

    fun syncPredictionFromActiveTrip() {
        val state = _uiState.value
        val activeDist = state.calculationSummary.totalDistanceKm
        val eff = SmartBatteryPredictor.defaultEfficiencyWhPerKm(state.batteryCapacityKWh, state.vehicleRange100)
        _uiState.update { current ->
            val syncedInput = current.smartPredictionInput.copy(
                currentBatteryPercent = state.startBattery,
                distanceKm = if (activeDist > 0.0) activeDist else current.smartPredictionInput.distanceKm,
                vehicleEfficiencyWhPerKm = eff,
                batteryCapacityKWh = state.batteryCapacityKWh,
                reserveMarginPercent = state.reserveMargin,
                speedKmh = state.averageSpeedKmh,
                weatherCondition = state.weatherCondition,
                vehicleCategory = state.selectedVehicleCategory,
                vehicleName = state.selectedVehicleName,
                compatibleConnectors = state.compatibleConnectors,
                payloadKg = SmartBatteryPredictor.defaultPayloadKg(state.selectedVehicleCategory),
                acUsageMode = if (state.selectedVehicleCategory.equals("Electric Car", ignoreCase = true)) {
                    AcUsageMode.ECO
                } else {
                    AcUsageMode.OFF
                }
            )
            current.copy(
                smartPredictionInput = syncedInput,
                predictionSyncVersion = current.predictionSyncVersion + 1,
                statusToastMessage = "Synced predictor with '${state.selectedVehicleName}'"
            )
        }
        recalculateSmartPrediction()
    }

    fun logActualTripOutcome(actualConsumedPercent: Double, notes: String = "") {
        val state = _uiState.value
        val input = state.smartPredictionInput
        // Evaluate pure transparent mathematical baseline so ML learns residuals vs physics math
        val pureMathResult = SmartBatteryPredictor.predict(
            input = input.copy(useMlCalibrationIfReady = false),
            stations = state.allStations,
            communitySummaries = state.communitySummaries,
            chargingCycles = chargingCycles.value,
            telemetryHistory = emptyList()
        )
        val cleanActual = actualConsumedPercent.coerceIn(0.1, 100.0)
        val isReliable = input.distanceKm >= 2.0 && cleanActual in 0.5..99.5

        val record = TripTelemetryRecord(
            vehicleName = input.vehicleName,
            vehicleCategory = input.vehicleCategory,
            distanceKm = input.distanceKm,
            speedKmh = input.speedKmh,
            elevationGainMeters = input.elevationGainMeters,
            payloadKg = input.payloadKg,
            weatherCondition = input.weatherCondition,
            acUsageMode = input.acUsageMode.name,
            ridingMode = input.ridingMode.name,
            efficiencyWhPerKm = input.vehicleEfficiencyWhPerKm,
            mathPredictedPercent = pureMathResult.energyConsumedPercent,
            actualConsumedPercent = cleanActual,
            notes = notes.trim(),
            isReliable = isReliable
        )

        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                repository.saveTelemetryRecord(record)
            }
            val nextReliableCount = telemetryRecords.value.count { it.isReliable } + if (isReliable) 1 else 0
            val toast = if (nextReliableCount >= SmartBatteryPredictor.MIN_RELIABLE_TRIPS_FOR_ML) {
                "Logged trip outcome! ML calibration unlocked ($nextReliableCount trips)."
            } else {
                "Logged reliable trip ($nextReliableCount/${SmartBatteryPredictor.MIN_RELIABLE_TRIPS_FOR_ML} for ML)."
            }
            _uiState.update { it.copy(statusToastMessage = toast) }
        }
    }

    fun deleteTelemetryRecord(recordId: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                repository.deleteTelemetryRecord(recordId)
            }
            _uiState.update { it.copy(statusToastMessage = "Removed trip telemetry log") }
        }
    }

    private fun updatePredictionInput(
        bumpSyncVersion: Boolean = false,
        transform: (SmartPredictionInput) -> SmartPredictionInput
    ) {
        _uiState.update { current ->
            current.copy(
                smartPredictionInput = transform(current.smartPredictionInput),
                predictionSyncVersion = if (bumpSyncVersion) current.predictionSyncVersion + 1 else current.predictionSyncVersion
            )
        }
        recalculateSmartPrediction()
    }

    private fun recalculateSmartPrediction() {
        val state = _uiState.value
        val result = SmartBatteryPredictor.predict(
            input = state.smartPredictionInput,
            stations = state.allStations,
            communitySummaries = state.communitySummaries,
            chargingCycles = chargingCycles.value,
            telemetryHistory = telemetryRecords.value
        )
        _uiState.update { it.copy(smartPredictionResult = result) }
    }

    private fun recalculateTrip() {
        val state = _uiState.value
        val cycles = chargingCycles.value
        val summary = BatteryCalculator.calculateTrip(
            vehicleRange100 = state.vehicleRange100,
            startingBatteryPercent = state.startBattery,
            reserveMarginPercent = state.reserveMargin,
            batteryCapacityKWh = state.batteryCapacityKWh,
            stops = state.stops,
            weatherCondition = state.weatherCondition,
            vehicleName = state.selectedVehicleName,
            chargingCycles = cycles,
            averageSpeedKmh = state.averageSpeedKmh
        )
        _uiState.update { it.copy(calculationSummary = summary) }
        recalculateSmartPrediction()
    }

    // --- EV Community Hub Actions ---

    fun selectCommunityTab(index: Int) {
        _uiState.update { it.copy(selectedCommunityTab = index.coerceIn(0, 5)) }
    }

    fun submitCommunityStation(
        name: String,
        provider: String,
        city: String,
        address: String,
        powerKw: Double,
        connectorTypes: String,
        costPerKwh: Double,
        bayCapacity: Int,
        latitude: Double,
        longitude: Double,
        openingHours: String,
        notes: String
    ) {
        val repo = evCommunityRepository
        val authorLabel = _uiState.value.riderProfile.displayName.ifBlank { "EV Rider" }
        if (repo == null || !_uiState.value.riderProfile.isSignedIn) {
            _uiState.update { it.copy(statusToastMessage = "Please sign in with Google to submit a charging station.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isSubmittingEvCommunity = true) }
            val result = repo.submitCommunityStation(
                name = name,
                provider = provider,
                city = city,
                address = address,
                powerKw = powerKw,
                connectorTypes = connectorTypes,
                costPerKwh = costPerKwh,
                bayCapacity = bayCapacity,
                latitude = latitude,
                longitude = longitude,
                openingHours = openingHours,
                notes = notes,
                authorLabel = authorLabel
            )
            _uiState.update {
                it.copy(
                    isSubmittingEvCommunity = false,
                    statusToastMessage = if (result.isSuccess) {
                        "Submitted '$name' to Community Chargers!"
                    } else {
                        result.exceptionOrNull()?.localizedMessage ?: "Failed to submit station"
                    }
                )
            }
        }
    }

    fun submitVerifiedRoute(
        title: String,
        originCity: String,
        destinationCity: String,
        totalDistanceKm: Double,
        elevationGainMeters: Double,
        vehicleName: String,
        vehicleCategory: String,
        chargingStopsCount: Int,
        arrivalBatteryPercent: Double,
        weatherCondition: String,
        stopsSummary: String,
        stopsJson: String,
        notes: String
    ) {
        val repo = evCommunityRepository
        val authorLabel = _uiState.value.riderProfile.displayName.ifBlank { "EV Rider" }
        if (repo == null || !_uiState.value.riderProfile.isSignedIn) {
            _uiState.update { it.copy(statusToastMessage = "Please sign in with Google to share a verified route.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isSubmittingEvCommunity = true) }
            val result = repo.submitVerifiedRoute(
                title = title,
                originCity = originCity,
                destinationCity = destinationCity,
                totalDistanceKm = totalDistanceKm,
                elevationGainMeters = elevationGainMeters,
                vehicleName = vehicleName,
                vehicleCategory = vehicleCategory,
                chargingStopsCount = chargingStopsCount,
                arrivalBatteryPercent = arrivalBatteryPercent,
                weatherCondition = weatherCondition,
                stopsSummary = stopsSummary,
                stopsJson = stopsJson,
                notes = notes,
                authorLabel = authorLabel
            )
            _uiState.update {
                it.copy(
                    isSubmittingEvCommunity = false,
                    statusToastMessage = if (result.isSuccess) {
                        "Shared verified route '$title'!"
                    } else {
                        result.exceptionOrNull()?.localizedMessage ?: "Failed to share route"
                    }
                )
            }
        }
    }

    fun activeRouteStopsJson(): String = converters.fromStopList(_uiState.value.stops)

    fun submitRangeReport(
        vehicleName: String,
        vehicleCategory: String,
        claimedRangeKm: Double,
        observedRealRangeKm: Double,
        distanceDrivenKm: Double,
        batteryUsedPercent: Double,
        avgEfficiencyWhPerKm: Double,
        avgSpeedKmh: Double,
        weatherCondition: String,
        ridingOrAcMode: String,
        notes: String
    ) {
        val repo = evCommunityRepository
        val authorLabel = _uiState.value.riderProfile.displayName.ifBlank { "EV Rider" }
        if (repo == null || !_uiState.value.riderProfile.isSignedIn) {
            _uiState.update { it.copy(statusToastMessage = "Please sign in with Google to post a range report.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isSubmittingEvCommunity = true) }
            val result = repo.submitRangeReport(
                vehicleName = vehicleName,
                vehicleCategory = vehicleCategory,
                claimedRangeKm = claimedRangeKm,
                observedRealRangeKm = observedRealRangeKm,
                distanceDrivenKm = distanceDrivenKm,
                batteryUsedPercent = batteryUsedPercent,
                avgEfficiencyWhPerKm = avgEfficiencyWhPerKm,
                avgSpeedKmh = avgSpeedKmh,
                weatherCondition = weatherCondition,
                ridingOrAcMode = ridingOrAcMode,
                notes = notes,
                authorLabel = authorLabel
            )
            _uiState.update {
                it.copy(
                    isSubmittingEvCommunity = false,
                    statusToastMessage = if (result.isSuccess) {
                        "Published real-world range report!"
                    } else {
                        result.exceptionOrNull()?.localizedMessage ?: "Failed to publish range report"
                    }
                )
            }
        }
    }

    fun submitEvOwnerReview(
        vehicleName: String,
        vehicleCategory: String,
        rating: Int,
        ownershipMonths: Int,
        odometerKm: Int,
        headline: String,
        pros: String,
        cons: String,
        reviewText: String
    ) {
        val repo = evCommunityRepository
        val authorLabel = _uiState.value.riderProfile.displayName.ifBlank { "EV Owner" }
        if (repo == null || !_uiState.value.riderProfile.isSignedIn) {
            _uiState.update { it.copy(statusToastMessage = "Please sign in with Google to post an EV review.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isSubmittingEvCommunity = true) }
            val result = repo.submitOwnerReview(
                vehicleName = vehicleName,
                vehicleCategory = vehicleCategory,
                rating = rating,
                ownershipMonths = ownershipMonths,
                odometerKm = odometerKm,
                headline = headline,
                pros = pros,
                cons = cons,
                reviewText = reviewText,
                authorLabel = authorLabel
            )
            _uiState.update {
                it.copy(
                    isSubmittingEvCommunity = false,
                    statusToastMessage = if (result.isSuccess) {
                        "Posted EV owner review!"
                    } else {
                        result.exceptionOrNull()?.localizedMessage ?: "Failed to post review"
                    }
                )
            }
        }
    }

    fun submitChargingExperience(
        stationName: String,
        provider: String,
        vehicleName: String,
        connectorUsed: String,
        peakPowerKw: Double,
        startPercent: Double,
        endPercent: Double,
        durationMinutes: Int,
        waitTimeMinutes: Int,
        rating: Int,
        experienceNotes: String
    ) {
        val repo = evCommunityRepository
        val authorLabel = _uiState.value.riderProfile.displayName.ifBlank { "EV Rider" }
        if (repo == null || !_uiState.value.riderProfile.isSignedIn) {
            _uiState.update { it.copy(statusToastMessage = "Please sign in with Google to share a charging experience.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isSubmittingEvCommunity = true) }
            val result = repo.submitChargingExperience(
                stationName = stationName,
                provider = provider,
                vehicleName = vehicleName,
                connectorUsed = connectorUsed,
                peakPowerKw = peakPowerKw,
                startPercent = startPercent,
                endPercent = endPercent,
                durationMinutes = durationMinutes,
                waitTimeMinutes = waitTimeMinutes,
                rating = rating,
                experienceNotes = experienceNotes,
                authorLabel = authorLabel
            )
            _uiState.update {
                it.copy(
                    isSubmittingEvCommunity = false,
                    statusToastMessage = if (result.isSuccess) {
                        "Shared charging experience!"
                    } else {
                        result.exceptionOrNull()?.localizedMessage ?: "Failed to share experience"
                    }
                )
            }
        }
    }

    fun submitTripRecommendation(
        title: String,
        corridor: String,
        totalDistanceKm: Double,
        recommendedCategory: String,
        difficulty: String,
        bestSeason: String,
        chargingTip: String,
        highlights: String
    ) {
        val repo = evCommunityRepository
        val authorLabel = _uiState.value.riderProfile.displayName.ifBlank { "EV Rider" }
        if (repo == null || !_uiState.value.riderProfile.isSignedIn) {
            _uiState.update { it.copy(statusToastMessage = "Please sign in with Google to recommend a trip.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isSubmittingEvCommunity = true) }
            val result = repo.submitTripRecommendation(
                title = title,
                corridor = corridor,
                totalDistanceKm = totalDistanceKm,
                recommendedCategory = recommendedCategory,
                difficulty = difficulty,
                bestSeason = bestSeason,
                chargingTip = chargingTip,
                highlights = highlights,
                authorLabel = authorLabel
            )
            _uiState.update {
                it.copy(
                    isSubmittingEvCommunity = false,
                    statusToastMessage = if (result.isSuccess) {
                        "Published community trip recommendation!"
                    } else {
                        result.exceptionOrNull()?.localizedMessage ?: "Failed to post recommendation"
                    }
                )
            }
        }
    }

    fun toggleCommunityEndorsement(targetType: String, targetId: String) {
        val repo = evCommunityRepository
        val uid = _uiState.value.riderProfile.uid.orEmpty()
        if (repo == null || !_uiState.value.riderProfile.isSignedIn || uid.isBlank()) {
            _uiState.update { it.copy(statusToastMessage = "Please sign in with Google to verify or upvote.") }
            return
        }
        val cleanTargetId = StationCommunityRepository.sanitizeId(targetId)
        val already = _uiState.value.communityEndorsements.any {
            it.userId == uid && it.targetType == targetType && it.targetId == cleanTargetId
        }
        viewModelScope.launch {
            val result = repo.toggleEndorsement(targetType, targetId, already)
            if (result.isFailure) {
                _uiState.update {
                    it.copy(statusToastMessage = result.exceptionOrNull()?.localizedMessage ?: "Action failed")
                }
            }
        }
    }

    fun deleteCommunityEntry(collection: String, docId: String) {
        val repo = evCommunityRepository ?: return
        viewModelScope.launch {
            val result = repo.deleteCommunityItem(collection, docId)
            _uiState.update {
                it.copy(
                    statusToastMessage = if (result.isSuccess) {
                        "Removed community entry."
                    } else {
                        result.exceptionOrNull()?.localizedMessage ?: "Could not delete entry"
                    }
                )
            }
        }
    }

    fun loadVerifiedRouteIntoPlanner(route: VerifiedRoute) {
        val parsed = converters.toStopList(route.stopsJson)
        val stopsToLoad = if (parsed.size >= 2) {
            parsed
        } else {
            listOf(
                Stop(
                    name = route.originCity.ifBlank { "Home" },
                    type = StopType.HOME,
                    distanceToNextKm = route.totalDistanceKm.coerceAtLeast(1.0),
                    targetBatteryAfterChargePercent = 100.0
                ),
                Stop(
                    name = route.destinationCity.ifBlank { "Destination" },
                    type = StopType.DESTINATION,
                    distanceToNextKm = 0.0
                )
            )
        }
        _uiState.update {
            it.copy(
                currentTripId = null,
                title = route.title.ifBlank { "${route.originCity} to ${route.destinationCity}" },
                weatherCondition = route.weatherCondition.ifBlank { it.weatherCondition },
                stops = stopsToLoad,
                tripVersion = it.tripVersion + 1,
                statusToastMessage = "Loaded verified route '${route.title}' into Planner!"
            )
        }
        recalculateTrip()
    }

    fun applyTripRecommendationToPredictor(rec: TripRecommendation) {
        val effCategory = if (rec.recommendedCategory == "All EVs") {
            _uiState.value.smartPredictionInput.vehicleCategory
        } else {
            rec.recommendedCategory
        }
        updatePredictionInput(bumpSyncVersion = true) { current ->
            current.copy(
                distanceKm = rec.totalDistanceKm.coerceAtLeast(1.0),
                vehicleCategory = effCategory,
                payloadKg = SmartBatteryPredictor.defaultPayloadKg(effCategory)
            )
        }
        _uiState.update {
            it.copy(statusToastMessage = "Loaded '${rec.title}' (${rec.totalDistanceKm.toInt()} km) into Smart Predictor!")
        }
    }
}
