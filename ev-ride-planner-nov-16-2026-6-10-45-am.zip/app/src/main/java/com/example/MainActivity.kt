package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Route
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.auth.GoogleAuthHelper
import com.example.data.remote.StationCommunityRepository
import com.example.ui.components.BatteryBar
import com.example.ui.components.GoogleSignInDialog
import com.example.ui.components.LogChargingCycleDialog
import com.example.ui.components.SafetyStatusBanner
import com.example.ui.components.StatCard
import com.example.ui.components.StationCommunitySheet
import com.example.ui.navigation.Screen
import com.example.ui.screens.community.EvCommunityScreen
import com.example.ui.screens.dashboard.DashboardScreen
import com.example.ui.screens.garage.GarageScreen
import com.example.ui.screens.history.HistoryScreen
import com.example.ui.screens.planner.TripPlannerScreen
import com.example.ui.screens.prediction.SmartPredictionScreen
import com.example.ui.screens.stations.StationsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.TripViewModel

class MainActivity : ComponentActivity() {

    private val tripViewModel: TripViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppShell(viewModel = tripViewModel)
            }
        }
    }
}

@Composable
fun MainAppShell(viewModel: TripViewModel) {
    val navController = rememberNavController()
    val state by viewModel.uiState.collectAsState()
    val cycles by viewModel.chargingCycles.collectAsState()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    val navItems = listOf(
        Screen.Dashboard,
        Screen.Planner,
        Screen.Garage,
        Screen.Stations,
        Screen.History
    )

    // Attempt silent Credential Manager sign-in once at startup
    LaunchedEffect(Unit) {
        val credentialManager = CredentialManager.create(context)
        GoogleAuthHelper.attemptAutoSignIn(
            context = context,
            credentialManager = credentialManager,
            scope = this,
            onAuthSuccess = { user ->
                viewModel.onAuthSessionConfirmed(
                    uid = user.uid,
                    displayName = user.displayName ?: "EV Rider",
                    email = user.email ?: "",
                    photoUrl = user.photoUrl?.toString()
                )
            },
            onUnauthenticated = { /* Remains in guest offline planning mode until signed in */ }
        )
    }

    // Handle toast messages
    LaunchedEffect(state.statusToastMessage) {
        state.statusToastMessage?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            viewModel.clearStatusToast()
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
            NavigationBar {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route

                navItems.forEach { screen ->
                    val isSelected = currentRoute == screen.route ||
                        ((currentRoute == Screen.SmartPredictor.route || currentRoute == Screen.Community.route) &&
                            screen == Screen.Dashboard)
                    NavigationBarItem(
                        icon = { Icon(screen.icon, contentDescription = screen.title) },
                        label = {
                            Text(
                                text = screen.title,
                                fontSize = 11.sp,
                                maxLines = 1,
                                softWrap = false
                            )
                        },
                        selected = isSelected,
                        modifier = Modifier.testTag("nav_tab_${screen.route}"),
                        onClick = {
                            if (currentRoute != screen.route) {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Dashboard.route,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            composable(Screen.Dashboard.route) {
                DashboardScreen(
                    viewModel = viewModel,
                    onNavigateToPlanner = {
                        navController.navigate(Screen.Planner.route) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    onNavigateToGarage = {
                        navController.navigate(Screen.Garage.route) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    onNavigateToSmartPredictor = {
                        navController.navigate(Screen.SmartPredictor.route) {
                            launchSingleTop = true
                        }
                    },
                    onNavigateToCommunity = { tabIndex ->
                        viewModel.selectCommunityTab(tabIndex)
                        navController.navigate(Screen.Community.route) {
                            launchSingleTop = true
                        }
                    }
                )
            }
            composable(Screen.Community.route) {
                EvCommunityScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                    onRouteLoadedToPlanner = {
                        navController.navigate(Screen.Planner.route) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    onOpenPredictor = {
                        navController.navigate(Screen.SmartPredictor.route) {
                            launchSingleTop = true
                        }
                    }
                )
            }
            composable(Screen.SmartPredictor.route) {
                SmartPredictionScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                    onOpenStations = {
                        navController.navigate(Screen.Stations.route) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }
            composable(Screen.Planner.route) {
                TripPlannerScreen(viewModel = viewModel)
            }
            composable(Screen.Garage.route) {
                GarageScreen(
                    viewModel = viewModel,
                    onVehicleActivated = {
                        navController.navigate(Screen.Dashboard.route) {
                            popUpTo(navController.graph.findStartDestination().id)
                            launchSingleTop = true
                        }
                    }
                )
            }
            composable(Screen.Stations.route) {
                StationsScreen(
                    viewModel = viewModel,
                    onOpenCommunityStations = {
                        viewModel.selectCommunityTab(0)
                        navController.navigate(Screen.Community.route) {
                            launchSingleTop = true
                        }
                    }
                )
            }
            composable(Screen.History.route) {
                HistoryScreen(
                    viewModel = viewModel,
                    onTripLoaded = {
                        navController.navigate(Screen.Dashboard.route) {
                            popUpTo(navController.graph.findStartDestination().id)
                            launchSingleTop = true
                        }
                    }
                )
            }
        }

        // Google Sign-In & Profile Interface Modal
        if (state.showGoogleSignInDialog) {
            GoogleSignInDialog(
                profile = state.riderProfile,
                onDismiss = { viewModel.setGoogleSignInDialogVisible(false) },
                onAuthSuccess = { uid, name, email, photoUrl ->
                    viewModel.onAuthSessionConfirmed(uid, name, email, photoUrl)
                },
                onSignOutComplete = {
                    viewModel.onAuthSessionSignedOut()
                }
            )
        }

        // Previous Charging Cycle & Charge Time Estimator Dialog
        if (state.showLogCycleDialog) {
            LogChargingCycleDialog(
                vehicleName = state.selectedVehicleName,
                defaultStationName = state.logCycleDefaultStation,
                defaultStartPercent = state.logCycleDefaultStartPct,
                defaultEndPercent = state.logCycleDefaultEndPct,
                existingCycles = cycles,
                onDismiss = { viewModel.closeLogCycleDialog() },
                onSaveCycle = { station, startPct, endPct, mins, kw ->
                    viewModel.logChargingCycle(station, startPct, endPct, mins, kw)
                },
                onDeleteCycle = { id ->
                    viewModel.deleteChargingCycle(id)
                }
            )
        }

        // Station Operator Integration, Community Availability, Reporting & Photo Sheet
        state.selectedStationForSheet?.let { selectedStation ->
            val sanitizedId = StationCommunityRepository.sanitizeId(selectedStation.id)
            StationCommunitySheet(
                station = selectedStation,
                summary = state.communitySummaries[sanitizedId],
                reports = state.communityReports.filter { it.stationId == sanitizedId },
                confirmations = state.communityConfirmations.filter { it.stationId == sanitizedId },
                photos = state.communityPhotos.filter { it.stationId == sanitizedId },
                riderProfile = state.riderProfile,
                userLatitude = state.userLatitude,
                userLongitude = state.userLongitude,
                isSubmittingCommunityAction = state.isSubmittingCommunityAction,
                initialTab = state.selectedStationSheetInitialTab,
                onDismiss = { viewModel.closeStationSheet() },
                onAddStationToTrip = {
                    viewModel.addStationToTrip(selectedStation)
                    viewModel.closeStationSheet()
                },
                onAuthSuccess = { uid, name, email, photoUrl ->
                    viewModel.onAuthSessionConfirmed(uid, name, email, photoUrl)
                },
                onSubmitAvailability = { status, connector, comment ->
                    viewModel.submitStationAvailability(selectedStation, status, connector, comment)
                },
                onSubmitChargerDownReport = { reason, notes ->
                    viewModel.submitChargerDownReport(selectedStation, reason, notes)
                },
                onSubmitWrongLocationReport = { reason, notes, lat, lon ->
                    viewModel.submitWrongLocationReport(selectedStation, reason, notes, lat, lon)
                },
                onResolveReport = { report ->
                    viewModel.resolveStationReport(report)
                },
                onUploadPhotoBase64 = { caption, base64 ->
                    viewModel.uploadStationPhoto(selectedStation, caption, base64)
                },
                onDeletePhoto = { photoId ->
                    viewModel.deleteStationPhoto(photoId)
                }
            )
        }
    }
}

@Preview(showBackground = true, name = "EV Ride Planner Preview")
@Composable
fun EvRidePlannerDashboardPreview() {
    MyApplicationTheme {
        Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SafetyStatusBanner(isSafe = true, failureReasons = emptyList())
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatCard(
                        title = "Total Distance",
                        value = "0.0 km",
                        subtitle = "Home (100%)",
                        icon = Icons.Default.Route,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "Final Battery",
                        value = "100.0%",
                        subtitle = "Min reserve: 15%",
                        icon = Icons.Default.ElectricBolt,
                        modifier = Modifier.weight(1f)
                    )
                }
                BatteryBar(percentage = 100.0, reserveMargin = 15.0)
            }
        }
    }
}
