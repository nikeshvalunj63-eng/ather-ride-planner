package com.example.location

import android.annotation.SuppressLint
import android.content.Context
import android.location.Geocoder
import android.location.Location
import android.os.Build
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.coroutines.resume

data class LiveLocationResult(
    val latitude: Double,
    val longitude: Double,
    val areaLabel: String
)

object LocationHelper {

    @SuppressLint("MissingPermission")
    suspend fun getCurrentLocation(context: Context): LiveLocationResult? {
        val fusedClient = LocationServices.getFusedLocationProviderClient(context)

        val current: Location? = suspendCancellableCoroutine { cont ->
            val cts = CancellationTokenSource()
            cont.invokeOnCancellation { cts.cancel() }

            fusedClient.getCurrentLocation(Priority.PRIORITY_BALANCED_POWER_ACCURACY, cts.token)
                .addOnSuccessListener { location ->
                    if (cont.isActive) cont.resume(location)
                }
                .addOnFailureListener {
                    if (cont.isActive) cont.resume(null)
                }
                .addOnCanceledListener {
                    if (cont.isActive) cont.resume(null)
                }
        }

        val resolved = current ?: suspendCancellableCoroutine { cont ->
            fusedClient.lastLocation
                .addOnSuccessListener { location ->
                    if (cont.isActive) cont.resume(location)
                }
                .addOnFailureListener {
                    if (cont.isActive) cont.resume(null)
                }
        } ?: return null

        val areaLabel = resolveAreaName(context, resolved.latitude, resolved.longitude)
        return LiveLocationResult(
            latitude = resolved.latitude,
            longitude = resolved.longitude,
            areaLabel = areaLabel
        )
    }

    private suspend fun resolveAreaName(
        context: Context,
        latitude: Double,
        longitude: Double
    ): String = withContext(Dispatchers.IO) {
        try {
            val geocoder = Geocoder(context, Locale.getDefault())
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                suspendCancellableCoroutine { cont ->
                    geocoder.getFromLocation(latitude, longitude, 1) { addresses ->
                        val addr = addresses.firstOrNull()
                        val label = listOfNotNull(
                            addr?.subLocality ?: addr?.locality,
                            addr?.adminArea
                        ).filter { it.isNotBlank() }.joinToString(", ")
                            .ifBlank { "${String.format("%.4f", latitude)}, ${String.format("%.4f", longitude)}" }
                        if (cont.isActive) cont.resume(label)
                    }
                }
            } else {
                @Suppress("DEPRECATION")
                val addr = geocoder.getFromLocation(latitude, longitude, 1)?.firstOrNull()
                listOfNotNull(
                    addr?.subLocality ?: addr?.locality,
                    addr?.adminArea
                ).filter { it.isNotBlank() }.joinToString(", ")
                    .ifBlank { "${String.format("%.4f", latitude)}, ${String.format("%.4f", longitude)}" }
            }
        } catch (_: Exception) {
            "${String.format("%.4f", latitude)}, ${String.format("%.4f", longitude)}"
        }
    }
}
