package com.example.data.remote

import com.example.base.FirestoreEmulatorTestBase
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.UUID

class EvCommunityRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun submitAndObserveAllSixCommunityFeatures_authenticatedUser_succeeds() = runBlocking {
        signInTestUser(ALICE_EMAIL)
        val repo = EvCommunityRepository(firestore, auth)
        val suffix = UUID.randomUUID().toString().replace("-", "").take(10)

        // 1. User-submitted charging station
        val stId = "cst_$suffix"
        val stRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.submitCommunityStation(
                name = "Highway Express EV Hub",
                provider = "Zeon Charging",
                city = "Lonavala",
                address = "Mumbai-Pune Expressway Km 54",
                powerKw = 60.0,
                connectorTypes = "CCS2, Type 2",
                costPerKwh = 21.0,
                bayCapacity = 4,
                latitude = 18.7557,
                longitude = 73.4091,
                openingHours = "24/7",
                notes = "Beside food court",
                authorLabel = "Alice EV",
                explicitId = stId
            )
        }
        assertTrue("Station create should succeed: ${stRes.exceptionOrNull()}", stRes.isSuccess)
        val stations = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeCommunityStations().first { list -> list.any { it.id == stId } }
        }
        assertEquals("Lonavala", stations.first { it.id == stId }.city)

        // 2. Verified travel route
        val rtId = "crt_$suffix"
        val rtRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.submitVerifiedRoute(
                title = "Pune to Mahabaleshwar Verified",
                originCity = "Pune",
                destinationCity = "Mahabaleshwar",
                totalDistanceKm = 122.0,
                elevationGainMeters = 920.0,
                vehicleName = "Ather 450X Gen 3",
                vehicleCategory = "Electric Scooter",
                chargingStopsCount = 1,
                arrivalBatteryPercent = 28.0,
                weatherCondition = "Clear",
                stopsSummary = "Home -> Wai Charger (52 km) -> Mahabaleshwar (70 km)",
                stopsJson = "[]",
                notes = "Completed in Ride mode",
                authorLabel = "Alice EV",
                explicitId = rtId
            )
        }
        assertTrue("Route create should succeed: ${rtRes.exceptionOrNull()}", rtRes.isSuccess)
        val routes = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeVerifiedRoutes().first { list -> list.any { it.id == rtId } }
        }
        assertEquals(122.0, routes.first { it.id == rtId }.totalDistanceKm, 0.01)

        // 3. Real-world range report
        val rrId = "rrp_$suffix"
        val rrRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.submitRangeReport(
                vehicleName = "Nexon EV LR",
                vehicleCategory = "Electric Car",
                claimedRangeKm = 465.0,
                observedRealRangeKm = 360.0,
                distanceDrivenKm = 180.0,
                batteryUsedPercent = 50.0,
                avgEfficiencyWhPerKm = 135.0,
                avgSpeedKmh = 76.0,
                weatherCondition = "Hot (>35°C)",
                ridingOrAcMode = "Eco AC",
                notes = "Steady cruise on NH-48",
                authorLabel = "Alice EV",
                explicitId = rrId
            )
        }
        assertTrue("Range report should succeed: ${rrRes.exceptionOrNull()}", rrRes.isSuccess)
        val reports = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeRangeReports().first { list -> list.any { it.id == rrId } }
        }
        assertEquals(360.0, reports.first { it.id == rrId }.observedRealRangeKm, 0.01)

        // 4. EV owner review
        val rvId = "rev_$suffix"
        val rvRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.submitOwnerReview(
                vehicleName = "Ather 450X Gen 3",
                vehicleCategory = "Electric Scooter",
                rating = 5,
                ownershipMonths = 12,
                odometerKm = 7500,
                headline = "Bulletproof city & weekend hill rider",
                pros = "Fast Grid charging, sharp chassis",
                cons = "Firm suspension on potholes",
                reviewText = "Zero degradation after 1 year of daily use.",
                authorLabel = "Alice EV",
                explicitId = rvId
            )
        }
        assertTrue("Owner review should succeed: ${rvRes.exceptionOrNull()}", rvRes.isSuccess)

        // 5. Charging experience sharing
        val ceId = "exp_$suffix"
        val ceRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.submitChargingExperience(
                stationName = "Tata Power EZ Charge",
                provider = "Tata Power EZ Charge",
                vehicleName = "Nexon EV LR",
                connectorUsed = "CCS2",
                peakPowerKw = 44.0,
                startPercent = 20.0,
                endPercent = 82.0,
                durationMinutes = 42,
                waitTimeMinutes = 0,
                rating = 5,
                experienceNotes = "Plugged in via EZ Charge app with zero wait.",
                authorLabel = "Alice EV",
                explicitId = ceId
            )
        }
        assertTrue("Charging experience should succeed: ${ceRes.exceptionOrNull()}", ceRes.isSuccess)

        // 6. Community trip recommendation + endorsement
        val trId = "rec_$suffix"
        val trRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.submitTripRecommendation(
                title = "Sahyadri Monsoon Loop",
                corridor = "Pune -> Mulshi -> Tamhini",
                totalDistanceKm = 135.0,
                recommendedCategory = "All EVs",
                difficulty = "Moderate",
                bestSeason = "July - September",
                chargingTip = "Charge at Pirangut before entering Tamhini",
                highlights = "Misty waterfalls, smooth tarmac, great cafes",
                authorLabel = "Alice EV",
                explicitId = trId
            )
        }
        assertTrue("Trip recommendation should succeed: ${trRes.exceptionOrNull()}", trRes.isSuccess)

        // Cross-user endorsement works & cross-user deletion is blocked
        signInTestUser(BOB_EMAIL)
        val bobRepo = EvCommunityRepository(firestore, auth)
        val endRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            bobRepo.toggleEndorsement("ROUTE", rtId, currentlyEndorsed = false)
        }
        assertTrue("Cross-user endorsement should succeed: ${endRes.exceptionOrNull()}", endRes.isSuccess)

        val delRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            bobRepo.deleteCommunityItem(EvCommunityRepository.COLLECTION_STATIONS, stId)
        }
        assertTrue("Bob must not delete Alice's community station", delRes.isFailure)
        val fsEx = delRes.exceptionOrNull()?.unwrapFirestoreException()
        assertNotNull(fsEx)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
    }

    @Test
    fun observeCommunityRoutes_unauthenticatedCaller_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repo = EvCommunityRepository(firestore, auth)

        var caught: Throwable? = null
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repo.observeVerifiedRoutes().first()
            }
        } catch (t: Throwable) {
            caught = t
        }
        assertNotNull("Expected failure when unauthenticated", caught)
    }

    private companion object {
        const val ALICE_EMAIL = "alice_ev_comm@test.com"
        const val BOB_EMAIL = "bob_ev_comm@test.com"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 4000L
    }
}
