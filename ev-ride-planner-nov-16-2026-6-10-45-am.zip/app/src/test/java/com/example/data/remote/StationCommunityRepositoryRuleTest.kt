package com.example.data.remote

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.AvailabilityStatus
import com.example.data.model.ChargingStation
import com.example.data.model.ReportCategory
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.UUID

class StationCommunityRepositoryRuleTest : FirestoreEmulatorTestBase() {

    private val sampleStation = ChargingStation(
        id = "cs_1",
        name = "Ather Grid - Indiranagar",
        provider = "Ather Grid",
        city = "Bengaluru",
        address = "100 Ft Road, Indiranagar",
        powerKw = 22.0,
        connectorTypes = "Ather Fast Dot, Type 2",
        latitude = 12.9716,
        longitude = 77.6412
    )

    @Test
    fun submitAndObserveReports_authenticatedRider_succeeds() = runBlocking {
        signInTestUser(ALICE_EMAIL)
        val repository = StationCommunityRepository(firestore, auth)
        val reportId = "rep_${UUID.randomUUID().toString().replace("-", "").take(12)}"

        val result = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.submitStationReport(
                station = sampleStation,
                category = ReportCategory.CHARGER_DOWN,
                issueReason = "Offline / No Power",
                notes = "Display unresponsive",
                authorLabel = "Alice EV",
                explicitReportId = reportId
            )
        }
        assertTrue("Report create should succeed: ${result.exceptionOrNull()}", result.isSuccess)

        val reports = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeCommunityReports().first { list -> list.any { it.id == reportId } }
        }
        val created = reports.first { it.id == reportId }
        assertEquals(ReportCategory.CHARGER_DOWN.value, created.reportCategory)
        assertEquals("open", created.status)

        val resolveResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.resolveStationReport(created)
        }
        assertTrue("Owner resolve should succeed: ${resolveResult.exceptionOrNull()}", resolveResult.isSuccess)
    }

    @Test
    fun submitWrongLocationAndConfirmAvailability_andCrossUserIsolation() = runBlocking {
        signInTestUser(ALICE_EMAIL)
        val aliceRepo = StationCommunityRepository(firestore, auth)

        val confirmRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.confirmStationAvailability(
                station = sampleStation,
                availabilityStatus = AvailabilityStatus.WORKING,
                connectorUsed = "Ather Fast Dot",
                comment = "22 kW working smoothly",
                authorLabel = "Alice EV"
            )
        }
        assertTrue("Confirmation should succeed: ${confirmRes.exceptionOrNull()}", confirmRes.isSuccess)

        val photoId = "photo_${UUID.randomUUID().toString().replace("-", "").take(12)}"
        val photoRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.uploadStationPhoto(
                station = sampleStation,
                caption = "2 free bays",
                imageBase64 = "dGVzdF9qcGVnX2Jhc2U2NF9wYXlsb2Fk",
                authorLabel = "Alice EV",
                explicitPhotoId = photoId
            )
        }
        assertTrue("Photo upload should succeed: ${photoRes.exceptionOrNull()}", photoRes.isSuccess)

        // Bob can observe community photos, but cannot delete Alice's photo
        signInTestUser(BOB_EMAIL)
        val bobRepo = StationCommunityRepository(firestore, auth)
        val deleteRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            bobRepo.deleteStationPhoto(photoId)
        }
        assertTrue("Bob deleting Alice's photo must fail", deleteRes.isFailure)
        val fsEx = deleteRes.exceptionOrNull()?.unwrapFirestoreException()
        assertNotNull(fsEx)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
    }

    @Test
    fun observeCommunityReports_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repository = StationCommunityRepository(firestore, auth)

        var caught: Throwable? = null
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repository.observeCommunityReports().first()
            }
        } catch (t: Throwable) {
            caught = t
        }
        assertNotNull("Expected failure when unauthenticated", caught)
    }

    private companion object {
        const val ALICE_EMAIL = "alice_ev@test.com"
        const val BOB_EMAIL = "bob_ev@test.com"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 4000L
    }
}
