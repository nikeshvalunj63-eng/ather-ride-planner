package com.example

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToIndex
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextReplacement
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class MainActivityUiTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun `all navigation tabs garage connectors travel time and dialogs respond to touch on MainActivity`() {
        // 1. Dashboard loads with Total Travel Time card & Google Sign-In works
        composeRule.onNodeWithText("EV Ride Planner").assertIsDisplayed()
        composeRule.onNodeWithTag("dashboard_lazy_column")
            .performScrollToNode(hasTestTag("dashboard_travel_time_card"))
        composeRule.onNodeWithText("Total Travel Time").assertIsDisplayed()

        composeRule.onNodeWithTag("dashboard_lazy_column").performScrollToIndex(0)
        composeRule.onNodeWithTag("google_signin_button").performClick()
        composeRule.onNodeWithTag("credential_google_signin_button").assertIsDisplayed()
        composeRule.onNodeWithText("Close").performClick()

        // 2. Scroll Dashboard LazyColumn to Log Cycle button and verify dialog interaction
        composeRule.onNodeWithTag("dashboard_lazy_column")
            .performScrollToNode(hasTestTag("dashboard_log_cycle_button"))
        composeRule.onNodeWithTag("dashboard_log_cycle_button").performClick()
        composeRule.onNodeWithText("Charging Cycle & Time").assertIsDisplayed()
        composeRule.onNodeWithText("Save Cycle").performClick()

        // 3. Garage tab: Add EV with custom name & multiple compatible connectors
        composeRule.onNodeWithTag("nav_tab_garage").performClick()
        composeRule.onNodeWithText("Vehicle Garage").assertIsDisplayed()
        composeRule.onNodeWithTag("garage_add_vehicle_button").performClick()
        composeRule.onNodeWithText("Add Vehicle to Garage").assertIsDisplayed()
        composeRule.onNodeWithTag("garage_vehicle_name_input").performTextReplacement("Nexon EV Touring")
        composeRule.onNodeWithText("CCS2").performClick()
        composeRule.onNodeWithTag("garage_confirm_save_button").performClick()

        composeRule.waitUntil(timeoutMillis = 5_000) {
            composeRule.onAllNodesWithText("Nexon EV Touring").fetchSemanticsNodes().size >= 2
        }
        composeRule.onNodeWithText("Saved Vehicles (1)").assertIsDisplayed()
        composeRule.onAllNodesWithText("Nexon EV Touring")[0].assertIsDisplayed()

        // 4. Planner tab: title edit, add stop FAB, and save trip dialog
        composeRule.onNodeWithTag("nav_tab_planner").performClick()
        composeRule.onNodeWithText("Route & Vehicle Planner").assertIsDisplayed()
        composeRule.onNodeWithTag("planner_lazy_column")
            .performScrollToNode(hasTestTag("trip_title_input"))
        composeRule.onNodeWithTag("trip_title_input").performTextReplacement("Weekend Pune Ride")

        composeRule.onNodeWithTag("add_stop_fab").performClick()
        composeRule.onNodeWithText("Add Route Stop").assertIsDisplayed()
        composeRule.onNodeWithTag("confirm_add_stop_button").performClick()

        composeRule.onNodeWithTag("planner_lazy_column")
            .performScrollToNode(hasTestTag("save_trip_top_button"))
        composeRule.onNodeWithTag("save_trip_top_button").performClick()
        composeRule.onNodeWithText("Save Trip Plan").assertIsDisplayed()
        composeRule.onNodeWithText("Save Trip").performClick()

        // 5. Stations tab: Compatible Plug filter, quick region chip, Operator & Community Sheet tabs
        composeRule.onNodeWithTag("nav_tab_stations").performClick()
        composeRule.onNodeWithText("Nearby EV Chargers").assertIsDisplayed()
        composeRule.onNodeWithTag("stations_lazy_column")
            .performScrollToNode(hasTestTag("stations_compatible_chip"))
        composeRule.onNodeWithTag("stations_compatible_chip").performClick()
        composeRule.onNodeWithText("Near Pune").performClick()
        composeRule.waitUntil(timeoutMillis = 5_000) {
            composeRule.onAllNodesWithText("Status/Report").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("stations_lazy_column")
            .performScrollToNode(hasTestTag("station_community_button_cs_6"))
        composeRule.onNodeWithTag("station_community_button_cs_6").performClick()
        composeRule.onNodeWithTag("station_community_sheet").assertIsDisplayed()

        // Verify Operator integration tab
        composeRule.onNodeWithTag("station_sheet_tab_0").performClick()
        composeRule.onNodeWithText("Operator Portal").performScrollTo().assertIsDisplayed()

        // Verify Report Issue tab (Charger Not Working & Incorrect Location)
        composeRule.onNodeWithTag("station_sheet_tab_2").performClick()
        composeRule.onNodeWithTag("report_category_down").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("report_category_location").performScrollTo().performClick()
        composeRule.onNodeWithText("Submit Location Fix").performScrollTo().assertIsDisplayed()

        // Verify Photos tab
        composeRule.onNodeWithTag("station_sheet_tab_3").performClick()
        composeRule.onNodeWithText("Pick Photo & Upload").performScrollTo().assertIsDisplayed()

        // Dismiss sheet cleanly
        composeRule.onNode(androidx.compose.ui.test.hasContentDescription("Close Station Details")).performClick()

        // 6. Saved tab: verify saved trip exists and Load Trip returns to Dashboard
        composeRule.onNodeWithTag("nav_tab_history").performClick()
        composeRule.onNodeWithText("Saved Trip Plans").assertIsDisplayed()
        composeRule.waitUntil(timeoutMillis = 5_000) {
            composeRule.onAllNodesWithText("Weekend Pune Ride").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithText("Weekend Pune Ride").assertIsDisplayed()
        composeRule.onNodeWithText("Load Trip").performClick()

        composeRule.onNodeWithText("EV Ride Planner").assertIsDisplayed()
        composeRule.onNodeWithText("Weekend Pune Ride").assertIsDisplayed()
    }

    @Test
    fun `smart battery prediction screen supports all inputs AC vs riding mode math trace and telemetry logging`() {
        // Navigate from Dashboard to Smart Battery Prediction
        composeRule.onNodeWithTag("dashboard_lazy_column")
            .performScrollToNode(hasTestTag("dashboard_smart_prediction_card"))
        composeRule.onNodeWithTag("open_smart_predictor_button").performClick()

        composeRule.onNodeWithText("Smart Battery Prediction").assertIsDisplayed()
        composeRule.onNodeWithTag("prediction_output_card").assertIsDisplayed()

        // Recommended charging point card
        composeRule.onNodeWithTag("smart_predictor_lazy_column")
            .performScrollToNode(hasTestTag("recommended_charging_card"))
        composeRule.onNodeWithText("Recommended Charging Point").assertIsDisplayed()

        // Inputs: Two-Wheeler shows Riding Mode (Eco / Ride / Sport / Warp)
        composeRule.onNodeWithTag("smart_predictor_lazy_column")
            .performScrollToNode(hasTestTag("prediction_inputs_card"))
        composeRule.onNodeWithTag("predictor_mode_sport").performScrollTo().performClick()

        // Switch to Electric Car and verify Cabin AC Usage options (Off / Eco AC / Max AC)
        composeRule.onNodeWithTag("predictor_category_car").performScrollTo().performClick()
        composeRule.onNodeWithTag("predictor_ac_full").performScrollTo().performClick()

        // Scroll to Transparent Mathematical Model Breakdown
        composeRule.onNodeWithTag("smart_predictor_lazy_column")
            .performScrollToNode(hasTestTag("math_breakdown_card"))
        composeRule.onNodeWithText("Transparent Mathematical Model").assertIsDisplayed()
        composeRule.onNodeWithText("Cabin AC auxiliary (Max AC)").performScrollTo().assertIsDisplayed()

        // Scroll to ML Calibration card and log an actual ride outcome
        composeRule.onNodeWithTag("smart_predictor_lazy_column")
            .performScrollToNode(hasTestTag("ml_calibration_card"))
        composeRule.onNodeWithTag("log_actual_trip_button").performScrollTo().performClick()
        composeRule.onNodeWithText("Log Actual Ride Outcome").assertIsDisplayed()
        composeRule.onNodeWithTag("confirm_log_actual_trip_button").performClick()

        composeRule.waitUntil(timeoutMillis = 5_000) {
            composeRule.onAllNodesWithText("Recent Logged Rides (1)").fetchSemanticsNodes().isNotEmpty()
        }

        // Return to Dashboard via Back button
        composeRule.onNodeWithTag("smart_predictor_lazy_column").performScrollToIndex(0)
        composeRule.onNodeWithTag("smart_predictor_back_button").performClick()
        composeRule.onNodeWithText("EV Ride Planner").assertIsDisplayed()
    }

    @Test
    fun `ev community hub displays all 6 community tabs auth prompt and back navigation`() {
        // Scroll Dashboard to EV Community Hub card and open it
        composeRule.onNodeWithTag("dashboard_lazy_column")
            .performScrollToNode(hasTestTag("dashboard_ev_community_card"))
        composeRule.onNodeWithTag("open_ev_community_button").performClick()

        composeRule.onNodeWithText("EV Community").assertIsDisplayed()
        composeRule.onNodeWithTag("community_signin_prompt_card").assertIsDisplayed()

        // Verify all 6 community tabs are selectable and render their respective empty-state prompts
        val expectedEmptyHeadlines = listOf(
            "No user-submitted stations yet",
            "No verified travel routes yet",
            "No real-world range reports yet",
            "No EV owner reviews yet",
            "No charging experiences shared yet",
            "No community trip recommendations yet"
        )
        expectedEmptyHeadlines.forEachIndexed { index, headline ->
            composeRule.onNodeWithTag("ev_community_lazy_column")
                .performScrollToNode(hasTestTag("community_tabs_row"))
            composeRule.onNodeWithTag("community_tabs_row")
                .performScrollToNode(hasTestTag("community_tab_$index"))
            composeRule.onNodeWithTag("community_tab_$index").performClick()
            composeRule.onNodeWithTag("ev_community_lazy_column")
                .performScrollToNode(hasTestTag("community_empty_state_card"))
            composeRule.onNodeWithText(headline).assertIsDisplayed()
        }

        // Back button returns to Dashboard
        composeRule.onNodeWithTag("ev_community_lazy_column").performScrollToIndex(0)
        composeRule.onNodeWithTag("community_back_button").performClick()
        composeRule.onNodeWithText("EV Ride Planner").assertIsDisplayed()

        // Verify Stations screen "+ Submit" shortcut opens EV Community Stations tab
        composeRule.onNodeWithTag("nav_tab_stations").performClick()
        composeRule.onNodeWithTag("stations_submit_charger_button").performClick()
        composeRule.onNodeWithText("EV Community").assertIsDisplayed()
    }
}
