package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.TripConverters
import com.example.data.model.AcUsageMode
import com.example.data.model.AvailabilityStatus
import com.example.data.model.ChargingCycle
import com.example.data.model.ChargingExperience
import com.example.data.model.ChargingOperatorCatalog
import com.example.data.model.ChargingStation
import com.example.data.model.CommunityStation
import com.example.data.model.EvConnectorCatalog
import com.example.data.model.GarageVehicle
import com.example.data.model.PredictionSafetyStatus
import com.example.data.model.RangeReport
import com.example.data.model.ReportCategory
import com.example.data.model.RidingMode
import com.example.data.model.SmartPredictionInput
import com.example.data.model.StationCommunityAggregator
import com.example.data.model.StationCommunitySummary
import com.example.data.model.StationConfirmation
import com.example.data.model.StationPhoto
import com.example.data.model.StationReport
import com.example.data.model.Stop
import com.example.data.model.StopType
import com.example.data.model.TripPlan
import com.example.data.model.TripTelemetryRecord
import com.example.domain.BatteryCalculator
import com.example.domain.GeoUtils
import com.example.domain.SmartBatteryPredictor
import com.example.viewmodel.defaultHomeOnlyStops
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("EV Ride Planner", appName)
  }

  @Test
  fun `default stops contain only home with 100 percent charge`() {
    val stops = defaultHomeOnlyStops()
    assertEquals(1, stops.size)
    assertEquals("Home", stops[0].name)
    assertEquals(StopType.HOME, stops[0].type)
    assertEquals(100.0, stops[0].targetBatteryAfterChargePercent, 0.01)
  }

  @Test
  fun `save and load trip in Room database`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
      .allowMainThreadQueries()
      .build()
    try {
      val dao = db.tripDao()
      val converters = TripConverters()
      val stops = listOf(
        Stop(name = "Home", type = StopType.HOME, distanceToNextKm = 45.0, targetBatteryAfterChargePercent = 100.0),
        Stop(name = "Lonavala", type = StopType.DESTINATION, distanceToNextKm = 0.0)
      )
      val plan = TripPlan(
        id = "trip_1",
        title = "Pune to Lonavala",
        vehicleName = "Ather 450X Gen 3",
        vehicleRange100 = 110.0,
        startingBatteryPercent = 100.0,
        reserveMarginPercent = 15.0,
        batteryCapacityKWh = 3.7,
        stopsJson = converters.fromStopList(stops),
        weatherCondition = "Clear"
      )
      dao.insertOrUpdateTrip(plan)
      val saved = dao.getAllTrips().first()
      assertEquals(1, saved.size)
      assertEquals("Pune to Lonavala", saved[0].title)
      val loadedStops = converters.toStopList(saved[0].stopsJson)
      assertEquals(2, loadedStops.size)
      assertEquals(45.0, loadedStops[0].distanceToNextKm, 0.01)
    } finally {
      db.close()
    }
  }

  @Test
  fun `save multiple vehicles in garage and match compatible connectors`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
      .allowMainThreadQueries()
      .build()
    try {
      val garageDao = db.garageVehicleDao()
      val scooter = GarageVehicle(
        id = "v_scooter",
        name = "Daily Ather 450X",
        category = "Electric Scooter",
        range100Km = 110.0,
        batteryCapacityKWh = 3.7,
        averageSpeedKmh = 45.0,
        compatibleConnectorsCsv = EvConnectorCatalog.toCsv(setOf("Ather Fast Dot", "Type 2")),
        isActive = false
      )
      val car = GarageVehicle(
        id = "v_car",
        name = "Highway Nexon EV",
        category = "Electric Car",
        range100Km = 360.0,
        batteryCapacityKWh = 40.5,
        averageSpeedKmh = 70.0,
        compatibleConnectorsCsv = EvConnectorCatalog.toCsv(setOf("CCS2", "Type 2", "Bharat DC-001")),
        isActive = true
      )
      garageDao.insertOrUpdateVehicle(scooter)
      garageDao.insertOrUpdateVehicle(car)

      val vehicles = garageDao.getAllVehicles().first()
      assertEquals(2, vehicles.size)
      assertEquals("Highway Nexon EV", vehicles[0].name)
      assertTrue(vehicles[0].isActive)
      assertTrue(vehicles[0].compatibleConnectors.contains("CCS2"))
      assertTrue(EvConnectorCatalog.isStationCompatible(scooter.compatibleConnectors, "Ather Fast Dot, Type 2"))
      assertFalse(EvConnectorCatalog.isStationCompatible(setOf("CHAdeMO"), "Ather Fast Dot"))
    } finally {
      db.close()
    }
  }

  @Test
  fun `haversine distance sorts near to far within 100 km`() {
    val puneLat = 18.5204
    val puneLon = 73.8567
    val kpDist = GeoUtils.haversineDistanceKm(puneLat, puneLon, 18.5362, 73.8940) // ~4.3 km
    val mumbaiDist = GeoUtils.haversineDistanceKm(puneLat, puneLon, 19.0760, 72.8777) // ~118 km
    assertTrue("Koregaon Park should be within 10 km", kpDist < 10.0)
    assertTrue("Mumbai should be over 100 km from Pune", mumbaiDist > 100.0)
  }

  @Test
  fun `test battery calculator with safe trip and total travel time`() {
    val stops = listOf(
        Stop(name = "Home", type = StopType.HOME, distanceToNextKm = 50.0),
        Stop(name = "Station", type = StopType.CHARGING_STATION, distanceToNextKm = 50.0, targetBatteryAfterChargePercent = 90.0),
        Stop(name = "Destination", type = StopType.DESTINATION, distanceToNextKm = 0.0)
    )

    // 100 km @ 50 km/h = 120 min drive + 1 previous cycle at 1.0 %/min (50% -> 90% = +40% = 40 min charge) = 160 min total travel
    val cycle = ChargingCycle(
        vehicleName = "Test EV",
        stationName = "Fast Hub",
        startPercent = 20.0,
        endPercent = 80.0,
        durationMinutes = 60,
        chargerPowerKw = 22.0
    )

    val summary = BatteryCalculator.calculateTrip(
        vehicleRange100 = 100.0,
        startingBatteryPercent = 100.0,
        reserveMarginPercent = 15.0,
        batteryCapacityKWh = 3.7,
        stops = stops,
        weatherCondition = "Clear",
        vehicleName = "Test EV",
        chargingCycles = listOf(cycle),
        averageSpeedKmh = 50.0
    )

    assertTrue("Trip should be safe", summary.isTripSafe)
    assertEquals(100.0, summary.totalDistanceKm, 0.1)
    assertEquals(120, summary.totalDriveMinutes)
    assertEquals(40, summary.totalChargingMinutes)
    assertEquals(160, summary.totalTravelMinutes)
    assertEquals(40.0, summary.finalBatteryPercent, 0.1)
    assertEquals(1, summary.totalChargingStops)
  }

  @Test
  fun `test battery calculator fails on reserve breach`() {
    val stops = listOf(
        Stop(name = "Start", type = StopType.HOME, distanceToNextKm = 90.0),
        Stop(name = "End", type = StopType.DESTINATION, distanceToNextKm = 0.0)
    )

    val summary = BatteryCalculator.calculateTrip(
        vehicleRange100 = 100.0,
        startingBatteryPercent = 100.0,
        reserveMarginPercent = 15.0,
        batteryCapacityKWh = 3.7,
        stops = stops,
        weatherCondition = "Clear"
    )

    assertFalse("Trip should be marked unsafe due to reserve breach", summary.isTripSafe)
    assertTrue(summary.failureReasons.isNotEmpty())
  }

  @Test
  fun `charging time uses previous charging cycle speed`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
      .allowMainThreadQueries()
      .build()
    try {
      val cycleDao = db.chargingCycleDao()
      // Previous cycle: 20% -> 80% (+60%) took 60 minutes => 1.0 %/min
      val cycle = ChargingCycle(
        vehicleName = "Ather 450X Gen 3",
        stationName = "Home Charger",
        startPercent = 20.0,
        endPercent = 80.0,
        durationMinutes = 60,
        chargerPowerKw = 0.75
      )
      cycleDao.insertCycle(cycle)
      val loaded = cycleDao.getAllCycles().first()
      assertEquals(1, loaded.size)

      val stops = listOf(
        Stop(name = "Home", type = StopType.HOME, distanceToNextKm = 40.0),
        Stop(name = "Charger", type = StopType.CHARGING_STATION, distanceToNextKm = 30.0, targetBatteryAfterChargePercent = 90.0),
        Stop(name = "Dest", type = StopType.DESTINATION, distanceToNextKm = 0.0)
      )

      // 100 km range, 40 km leg consumes 40% (100% -> 60%), charging 60% -> 90% (+30%) at 1.0 %/min = 30 min
      val summary = BatteryCalculator.calculateTrip(
        vehicleRange100 = 100.0,
        startingBatteryPercent = 100.0,
        reserveMarginPercent = 15.0,
        batteryCapacityKWh = 3.7,
        stops = stops,
        weatherCondition = "Clear",
        vehicleName = "Ather 450X Gen 3",
        chargingCycles = loaded
      )

      assertTrue(summary.isChargingTimeFromHistory)
      assertEquals(1.0, summary.chargingSpeedPercentPerMin, 0.01)
      assertEquals(30, summary.totalChargingMinutes)
      assertEquals(100, summary.estimatedFullChargeMinutes)
    } finally {
      db.close()
    }
  }

  @Test
  fun `operator integration resolves EV charging networks and preserves OSM overrides`() {
    val ather = ChargingOperatorCatalog.resolveOperator("Ather Grid", "Ather Grid Indiranagar")
    assertEquals("ather", ather.id)
    assertEquals("18002662843", ather.supportPhone)
    assertTrue(ather.ocpiNetworkId.contains("ATH"))

    val custom = ChargingOperatorCatalog.resolveOperator(
      provider = "Local Express Charger",
      customPhone = "0201234567",
      customWebsite = "https://evhub.example.com"
    )
    assertEquals("0201234567", custom.supportPhone)
    assertEquals("https://evhub.example.com", custom.portalUrl)
  }

  @Test
  fun `community summary aggregates availability confirmations fault reports location flags and photos`() {
    val reports = listOf(
      StationReport(
        id = "r1",
        userId = "u1",
        stationId = "cs_6",
        reportCategory = ReportCategory.WRONG_LOCATION.value,
        status = "open"
      ),
      StationReport(
        id = "r2",
        userId = "u2",
        stationId = "cs_2",
        reportCategory = ReportCategory.CHARGER_DOWN.value,
        status = "open"
      )
    )
    val confirmations = listOf(
      StationConfirmation(
        id = "c1",
        userId = "u1",
        authorLabel = "Nikesh",
        stationId = "cs_6",
        availabilityStatus = AvailabilityStatus.WORKING.value
      ),
      StationConfirmation(
        id = "c2",
        userId = "u3",
        authorLabel = "Rohan",
        stationId = "cs_6",
        availabilityStatus = AvailabilityStatus.WORKING.value
      )
    )
    val photos = listOf(
      StationPhoto(id = "p1", userId = "u1", stationId = "cs_6", caption = "Working bay", imageBase64 = "abc123")
    )

    val summaryMap = StationCommunityAggregator.buildSummaryMap(
      reports = reports,
      confirmations = confirmations,
      photos = photos,
      currentUserId = "u1"
    )

    val cs6 = summaryMap["cs_6"]!!
    assertEquals(2, cs6.workingCount)
    assertEquals(1, cs6.wrongLocationReports)
    assertEquals(1, cs6.photoCount)
    assertEquals(AvailabilityStatus.WORKING, cs6.userVote)
    assertTrue(cs6.headlineStatus.contains("Community Verified (2)"))

    val cs2 = summaryMap["cs_2"]!!
    assertEquals(1, cs2.openDownReports)
    assertEquals("Reported Not Working", cs2.headlineStatus)
  }

  @Test
  fun `smart battery predictor applies physics for riding mode car AC elevation payload and weather`() {
    val twoWheelerEco = SmartPredictionInput(
      currentBatteryPercent = 90.0,
      distanceKm = 40.0,
      vehicleEfficiencyWhPerKm = 33.6,
      batteryCapacityKWh = 3.7,
      speedKmh = 45.0,
      elevationGainMeters = 0.0,
      payloadKg = 75.0,
      weatherCondition = "Clear",
      vehicleCategory = "Electric Scooter",
      ridingMode = RidingMode.ECO
    )
    val twoWheelerSportClimb = twoWheelerEco.copy(
      speedKmh = 70.0,
      elevationGainMeters = 500.0,
      payloadKg = 140.0,
      weatherCondition = "Rain / Headwind",
      ridingMode = RidingMode.SPORT
    )

    val ecoResult = SmartBatteryPredictor.predict(twoWheelerEco)
    val sportClimbResult = SmartBatteryPredictor.predict(twoWheelerSportClimb)

    assertTrue("Sport uphill ride should consume significantly more kWh", sportClimbResult.energyConsumedKwh > ecoResult.energyConsumedKwh * 1.4)
    assertTrue("Downhill elevation should recover regen energy (<0 Wh)",
      SmartBatteryPredictor.predict(twoWheelerEco.copy(elevationGainMeters = -400.0)).breakdown.elevationDeltaWh < 0.0
    )

    // Car AC auxiliary load test
    val carNoAc = SmartPredictionInput(
      currentBatteryPercent = 80.0,
      distanceKm = 80.0,
      vehicleEfficiencyWhPerKm = 145.0,
      batteryCapacityKWh = 40.5,
      speedKmh = 80.0,
      payloadKg = 150.0,
      weatherCondition = "Clear",
      vehicleCategory = "Electric Car",
      acUsageMode = AcUsageMode.OFF
    )
    val carMaxAc = carNoAc.copy(acUsageMode = AcUsageMode.FULL)
    val resNoAc = SmartBatteryPredictor.predict(carNoAc)
    val resMaxAc = SmartBatteryPredictor.predict(carMaxAc)
    // At 80 km / 80 km/h = 1 hour, 2.2 kW Max AC adds ~2200 Wh
    assertEquals(2200.0, resMaxAc.breakdown.acAuxiliaryWh, 10.0)
    assertTrue("Max AC must increase car energy usage", resMaxAc.energyConsumedKwh > resNoAc.energyConsumedKwh + 2.0)
  }

  @Test
  fun `smart predictor stays in transparent math mode until 10 reliable trips are logged in Room`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
      .allowMainThreadQueries()
      .build()
    try {
      val telemetryDao = db.tripTelemetryDao()
      val baseInput = SmartPredictionInput(
        currentBatteryPercent = 100.0,
        distanceKm = 50.0,
        vehicleEfficiencyWhPerKm = 34.0,
        batteryCapacityKWh = 3.7,
        vehicleCategory = "Electric Scooter",
        useMlCalibrationIfReady = true
      )

      // Insert 9 reliable trips (< 10 threshold)
      repeat(9) { idx ->
        telemetryDao.insertRecord(
          TripTelemetryRecord(
            id = "rec_$idx",
            vehicleName = "Ather 450X Gen 3",
            vehicleCategory = "Electric Scooter",
            distanceKm = 40.0,
            speedKmh = 45.0,
            elevationGainMeters = 100.0,
            payloadKg = 80.0,
            weatherCondition = "Clear",
            efficiencyWhPerKm = 34.0,
            mathPredictedPercent = 40.0,
            actualConsumedPercent = 48.0, // +20% real-world overhead
            isReliable = true
          )
        )
      }

      val recordsBefore = telemetryDao.getAllRecords().first()
      val beforeResult = SmartBatteryPredictor.predict(baseInput, telemetryHistory = recordsBefore)
      assertFalse("ML must stay locked with only 9 reliable trips", beforeResult.mlCalibrationStatus.isMlReady)
      assertFalse(beforeResult.mlCalibrationStatus.isMlActive)
      assertEquals(1.0, beforeResult.mlCalibrationStatus.learnedScaleFactor, 0.001)
      assertEquals(0.0, beforeResult.breakdown.mlResidualAdjustmentWh, 0.001)

      // Add 10th reliable trip -> unlocks ML ridge regression calibration!
      telemetryDao.insertRecord(
        TripTelemetryRecord(
          id = "rec_9",
          vehicleName = "Ather 450X Gen 3",
          vehicleCategory = "Electric Scooter",
          distanceKm = 40.0,
          speedKmh = 45.0,
          elevationGainMeters = 100.0,
          payloadKg = 80.0,
          weatherCondition = "Clear",
          efficiencyWhPerKm = 34.0,
          mathPredictedPercent = 40.0,
          actualConsumedPercent = 48.0,
          isReliable = true
        )
      )

      val recordsAfter = telemetryDao.getAllRecords().first()
      val afterResult = SmartBatteryPredictor.predict(baseInput, telemetryHistory = recordsAfter)
      assertTrue("ML should unlock after 10 reliable trips", afterResult.mlCalibrationStatus.isMlReady)
      assertTrue(afterResult.mlCalibrationStatus.isMlActive)
      assertTrue("Learned scale factor should adapt above 1.15 toward 1.20x", afterResult.mlCalibrationStatus.learnedScaleFactor > 1.15)
      assertTrue("Calibrated consumption should exceed pure math prediction", afterResult.energyConsumedKwh > beforeResult.energyConsumedKwh)
    } finally {
      db.close()
    }
  }

  @Test
  fun `recommended charging point skips broken stations and picks reachable healthy compatible charger`() {
    val brokenStation = ChargingStation(
      id = "cs_broken",
      name = "Broken Charger Hub",
      provider = "Zeon",
      city = "Highway",
      address = "NH-48 Km 45",
      powerKw = 50.0,
      connectorTypes = "CCS2, Type 2",
      latitude = 12.80,
      longitude = 77.45,
      distanceFromUserKm = 45.0
    )
    val healthyStation = ChargingStation(
      id = "cs_healthy",
      name = "Working Green Hub",
      provider = "Ather Grid",
      city = "Highway",
      address = "NH-48 Km 50",
      powerKw = 22.0,
      connectorTypes = "Type 2, Ather Fast Dot",
      latitude = 12.85,
      longitude = 77.50,
      distanceFromUserKm = 50.0
    )
    val summaries = mapOf(
      "cs_broken" to StationCommunitySummary(stationId = "cs_broken", openDownReports = 2, notWorkingCount = 2),
      "cs_healthy" to StationCommunitySummary(stationId = "cs_healthy", workingCount = 3)
    )

    val longTripInput = SmartPredictionInput(
      currentBatteryPercent = 65.0,
      distanceKm = 95.0,
      vehicleEfficiencyWhPerKm = 33.6,
      batteryCapacityKWh = 3.7,
      reserveMarginPercent = 15.0,
      speedKmh = 55.0,
      compatibleConnectors = setOf("Ather Fast Dot", "Type 2")
    )

    val result = SmartBatteryPredictor.predict(
      input = longTripInput,
      stations = listOf(brokenStation, healthyStation),
      communitySummaries = summaries
    )

    assertTrue(result.safetyStatus == PredictionSafetyStatus.LOW_RESERVE || result.safetyStatus == PredictionSafetyStatus.CRITICAL)
    assertTrue(result.recommendedChargingPoint.actionRequired)
    assertEquals("cs_healthy", result.recommendedChargingPoint.station?.id)
  }

  @Test
  fun `ev community station conversion range ratio and charging speed calculations work accurately`() {
    val commStation = CommunityStation(
      id = "cst_test1",
      userId = "u1",
      authorLabel = "Rohan EV",
      name = "Highway Cafe Fast DC",
      provider = "Zeon Charging",
      city = "Lonavala",
      address = "NH-48 Food Mall",
      powerKw = 50.0,
      connectorTypes = "CCS2, Type 2",
      costPerKwh = 20.0,
      bayCapacity = 3,
      latitude = 18.7557,
      longitude = 73.4091
    )
    // From Pune (18.5204, 73.8567) to Lonavala (18.7557, 73.4091) is ~53-55 km
    val mapped = commStation.toChargingStation(userLatitude = 18.5204, userLongitude = 73.8567)
    assertEquals("cst_test1", mapped.id)
    assertTrue((mapped.distanceFromUserKm ?: 0.0) in 45.0..65.0)
    assertEquals(3, mapped.bayCapacity)

    val rangeReport = RangeReport(
      vehicleName = "Nexon EV LR",
      claimedRangeKm = 400.0,
      observedRealRangeKm = 320.0
    )
    assertEquals(80.0, rangeReport.realWorldRatioPercent, 0.01)

    val exp = ChargingExperience(
      startPercent = 20.0,
      endPercent = 80.0,
      durationMinutes = 30
    )
    assertEquals(2.0, exp.chargeSpeedPercentPerMin, 0.01)
  }
}
