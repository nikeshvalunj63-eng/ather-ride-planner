const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_rider_123";
const BOB_UID = "bob_rider_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function validReport(userId) {
  return {
    userId,
    authorLabel: "Nikesh V.",
    stationId: "cs_1",
    stationName: "Ather Grid - Indiranagar",
    operatorName: "Ather Grid",
    reportCategory: "CHARGER_DOWN",
    issueReason: "Offline / No Power",
    notes: "Screen is completely black",
    suggestedLat: 0.0,
    suggestedLon: 0.0,
    status: "open",
    visibility: "community",
    createdAt: new Date(),
    updatedAt: new Date(),
  };
}

function validConfirmation(userId) {
  return {
    userId,
    authorLabel: "Nikesh V.",
    stationId: "cs_1",
    stationName: "Ather Grid - Indiranagar",
    availabilityStatus: "WORKING",
    connectorUsed: "Ather Fast Dot",
    comment: "Charging at 22 kW cleanly",
    visibility: "community",
    createdAt: new Date(),
    updatedAt: new Date(),
  };
}

function validPhoto(userId) {
  return {
    userId,
    authorLabel: "Nikesh V.",
    stationId: "cs_1",
    stationName: "Ather Grid - Indiranagar",
    caption: "Two bays free near entrance",
    imageBase64: "dGVzdF9qcGVnX2Jhc2U2NF9wYXlsb2Fk",
    visibility: "community",
    createdAt: new Date(),
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: cannot read or write any community collection", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("station_reports").where("visibility", "==", "community").get());
  await assertFails(unauthDb.collection("station_confirmations").where("visibility", "==", "community").get());
  await assertFails(unauthDb.collection("station_photos").where("visibility", "==", "community").get());
  await assertFails(unauthDb.collection("station_reports").doc("rep_1").set(validReport(ALICE_UID)));
});

test("Unfiltered query without visibility/userId fails even when signed in", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(aliceDb.collection("station_reports").get());
  await assertFails(aliceDb.collection("station_confirmations").get());
  await assertFails(aliceDb.collection("station_photos").get());
});

test("Authenticated user: can create and query community report, cross-user update/delete fails", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(aliceDb.collection("station_reports").doc("rep_1").set(validReport(ALICE_UID)));

  // Both Alice and Bob can query community reports
  await assertSucceeds(
    bobDb.collection("station_reports").where("visibility", "==", "community").get()
  );

  // Bob cannot modify or delete Alice's report
  await assertFails(
    bobDb.collection("station_reports").doc("rep_1").update({
      notes: "Tampered",
      updatedAt: new Date(),
    })
  );
  await assertFails(bobDb.collection("station_reports").doc("rep_1").delete());

  // Ghost field rejected (Shadow Update test)
  await assertFails(
    aliceDb.collection("station_reports").doc("rep_ghost").set({
      ...validReport(ALICE_UID),
      isAdminVerified: true,
    })
  );

  // Terminal state lock: resolve report then block subsequent edits
  await assertSucceeds(
    aliceDb.collection("station_reports").doc("rep_1").update({
      status: "resolved",
      updatedAt: new Date(),
    })
  );
  await assertFails(
    aliceDb.collection("station_reports").doc("rep_1").update({
      notes: "Reopen",
      status: "open",
      updatedAt: new Date(),
    })
  );
});

test("Authenticated user: can create/update confirmation; identity spoofing fails", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  // Alice cannot spoof Bob's userId
  await assertFails(aliceDb.collection("station_confirmations").doc("cs_1_bob").set(validConfirmation(BOB_UID)));

  // Alice creates her confirmation
  await assertSucceeds(aliceDb.collection("station_confirmations").doc("cs_1_alice").set(validConfirmation(ALICE_UID)));

  // Alice updates her availability status
  await assertSucceeds(
    aliceDb.collection("station_confirmations").doc("cs_1_alice").update({
      availabilityStatus: "BUSY",
      updatedAt: new Date(),
    })
  );

  // Bob cannot delete Alice's confirmation
  await assertFails(bobDb.collection("station_confirmations").doc("cs_1_alice").delete());
});

test("Authenticated user: station photo create/read/delete works and updates are blocked", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(aliceDb.collection("station_photos").doc("photo_1").set(validPhoto(ALICE_UID)));
  await assertSucceeds(bobDb.collection("station_photos").where("visibility", "==", "community").get());
  await assertFails(aliceDb.collection("station_photos").doc("photo_1").update({ caption: "Changed" }));
  await assertFails(bobDb.collection("station_photos").doc("photo_1").delete());
  await assertSucceeds(aliceDb.collection("station_photos").doc("photo_1").delete());
});

function validCommunityStation(userId) {
  return {
    userId,
    authorLabel: "Nikesh V.",
    name: "Lonavala Highway Fast Hub",
    provider: "Zeon Charging",
    city: "Lonavala",
    address: "Old Mumbai-Pune Hwy, Varsoli",
    powerKw: 60.0,
    connectorTypes: "CCS2, Type 2",
    costPerKwh: 21.0,
    bayCapacity: 4,
    latitude: 18.7557,
    longitude: 73.4091,
    openingHours: "24/7",
    notes: "Right beside food court",
    visibility: "community",
    createdAt: new Date(),
  };
}

function validVerifiedRoute(userId) {
  return {
    userId,
    authorLabel: "Nikesh V.",
    title: "Pune to Mahabaleshwar Scenic",
    originCity: "Pune",
    destinationCity: "Mahabaleshwar",
    totalDistanceKm: 120.0,
    elevationGainMeters: 950.0,
    vehicleName: "Ather 450X Gen 3",
    vehicleCategory: "Electric Scooter",
    chargingStopsCount: 1,
    arrivalBatteryPercent: 24.5,
    weatherCondition: "Clear",
    stopsSummary: "Pune -> Wai Charger (45 km) -> Mahabaleshwar (75 km)",
    stopsJson: "[]",
    notes: "Smooth ghat climb in Ride mode",
    visibility: "community",
    createdAt: new Date(),
  };
}

function validRangeReport(userId) {
  return {
    userId,
    authorLabel: "Nikesh V.",
    vehicleName: "Nexon EV LR",
    vehicleCategory: "Electric Car",
    claimedRangeKm: 465.0,
    observedRealRangeKm: 355.0,
    distanceDrivenKm: 210.0,
    batteryUsedPercent: 59.0,
    avgEfficiencyWhPerKm: 138.0,
    avgSpeedKmh: 78.0,
    weatherCondition: "Hot (>35°C)",
    ridingOrAcMode: "Eco AC",
    notes: "Highway cruise with AC on 24C",
    visibility: "community",
    createdAt: new Date(),
  };
}

function validOwnerReview(userId) {
  return {
    userId,
    authorLabel: "Nikesh V.",
    vehicleName: "Ather 450X Gen 3",
    vehicleCategory: "Electric Scooter",
    rating: 5,
    ownershipMonths: 14,
    odometerKm: 8400,
    headline: "Zero battery drop after 8,400 km",
    pros: "Crisp handling, Ather Grid coverage",
    cons: "Underseat boot fits half-face helmet",
    reviewText: "Reliable daily commuter and weekend hill climbs.",
    visibility: "community",
    createdAt: new Date(),
  };
}

function validChargingExperience(userId) {
  return {
    userId,
    authorLabel: "Nikesh V.",
    stationName: "Tata Power EZ Charge - MG Road",
    provider: "Tata Power EZ Charge",
    vehicleName: "Nexon EV LR",
    connectorUsed: "CCS2",
    peakPowerKw: 42.5,
    startPercent: 22.0,
    endPercent: 85.0,
    durationMinutes: 46,
    waitTimeMinutes: 5,
    rating: 4,
    experienceNotes: "Auto-auth worked on first try, clean bay.",
    visibility: "community",
    createdAt: new Date(),
  };
}

function validTripRecommendation(userId) {
  return {
    userId,
    authorLabel: "Nikesh V.",
    title: "Konkan Coastal EV Trail",
    corridor: "Pune -> Tamhini -> Alibag",
    totalDistanceKm: 165.0,
    recommendedCategory: "All EVs",
    difficulty: "Moderate",
    bestSeason: "Oct - Feb (Post Monsoon)",
    chargingTip: "Top up to 90% at Mulshi Fast Hub before descend",
    highlights: "Lush valleys, waterfall viewpoints, calm beaches",
    visibility: "community",
    createdAt: new Date(),
  };
}

test("Unauthenticated user: cannot read or write new EV community collections", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  const cols = [
    "community_stations",
    "community_routes",
    "range_reports",
    "ev_owner_reviews",
    "charging_experiences",
    "trip_recommendations",
    "community_endorsements",
  ];
  for (const col of cols) {
    await assertFails(unauthDb.collection(col).where("visibility", "==", "community").get());
  }
  await assertFails(unauthDb.collection("community_stations").doc("st_unauth").set(validCommunityStation(ALICE_UID)));
});

test("Authenticated user: EV community CRUD, query enforcement, and security bounds", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  // Create valid documents across all 6 community collections + endorsement
  await assertSucceeds(aliceDb.collection("community_stations").doc("c_st_1").set(validCommunityStation(ALICE_UID)));
  await assertSucceeds(aliceDb.collection("community_routes").doc("c_rt_1").set(validVerifiedRoute(ALICE_UID)));
  await assertSucceeds(aliceDb.collection("range_reports").doc("c_rr_1").set(validRangeReport(ALICE_UID)));
  await assertSucceeds(aliceDb.collection("ev_owner_reviews").doc("c_rv_1").set(validOwnerReview(ALICE_UID)));
  await assertSucceeds(aliceDb.collection("charging_experiences").doc("c_ce_1").set(validChargingExperience(ALICE_UID)));
  await assertSucceeds(aliceDb.collection("trip_recommendations").doc("c_tr_1").set(validTripRecommendation(ALICE_UID)));
  await assertSucceeds(
    bobDb.collection("community_endorsements").doc("ROUTE_c_rt_1_bob").set({
      userId: BOB_UID,
      targetType: "ROUTE",
      targetId: "c_rt_1",
      visibility: "community",
      createdAt: new Date(),
    })
  );

  // Filtered community list succeeds for another signed-in rider
  await assertSucceeds(bobDb.collection("community_stations").where("visibility", "==", "community").get());
  await assertSucceeds(bobDb.collection("community_routes").where("visibility", "==", "community").get());
  await assertSucceeds(bobDb.collection("range_reports").where("visibility", "==", "community").get());
  await assertSucceeds(bobDb.collection("ev_owner_reviews").where("visibility", "==", "community").get());
  await assertSucceeds(bobDb.collection("charging_experiences").where("visibility", "==", "community").get());
  await assertSucceeds(bobDb.collection("trip_recommendations").where("visibility", "==", "community").get());

  // Unfiltered query without visibility/userId fails
  await assertFails(bobDb.collection("community_stations").get());
  await assertFails(bobDb.collection("community_routes").get());

  // Identity spoofing fails
  await assertFails(aliceDb.collection("community_stations").doc("c_st_spoof").set(validCommunityStation(BOB_UID)));
  await assertFails(aliceDb.collection("ev_owner_reviews").doc("c_rv_spoof").set(validOwnerReview(BOB_UID)));

  // Ghost field & invalid rating rejected
  await assertFails(
    aliceDb.collection("ev_owner_reviews").doc("c_rv_ghost").set({
      ...validOwnerReview(ALICE_UID),
      isFeaturedAdmin: true,
    })
  );
  await assertFails(
    aliceDb.collection("ev_owner_reviews").doc("c_rv_bad_rating").set({
      ...validOwnerReview(ALICE_UID),
      rating: 6,
    })
  );

  // Cross-user delete fails; owner delete succeeds
  await assertFails(bobDb.collection("community_stations").doc("c_st_1").delete());
  await assertFails(bobDb.collection("community_routes").doc("c_rt_1").delete());
  await assertSucceeds(aliceDb.collection("community_stations").doc("c_st_1").delete());
  await assertSucceeds(bobDb.collection("community_endorsements").doc("ROUTE_c_rt_1_bob").delete());
});
