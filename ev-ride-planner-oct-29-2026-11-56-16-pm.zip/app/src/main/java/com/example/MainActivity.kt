package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.ElectricScooter
import androidx.compose.material.icons.filled.EvStation
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import com.example.ui.MainViewModel
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.SavedTripsScreen
import com.example.ui.screens.StationsScreen
import com.example.ui.screens.attemptAutoSignIn
import com.example.ui.screens.signOutUser
import com.example.ui.theme.EvCyanSecondary
import com.example.ui.theme.EvGreenPrimary
import com.example.ui.theme.MyApplicationTheme
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val isDarkMode by viewModel.isDarkMode.collectAsState()

            MyApplicationTheme(darkTheme = isDarkMode) {
                val context = LocalContext.current
                val coroutineScope = rememberCoroutineScope()
                val credentialManager = remember { CredentialManager.create(context) }
                var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }

                // Listen to Firebase Auth state
                DisposableEffect(Unit) {
                    val authListener = FirebaseAuth.AuthStateListener { auth ->
                        currentUser = auth.currentUser
                    }
                    Firebase.auth.addAuthStateListener(authListener)

                    // Attempt background silent sign-in if unauthenticated
                    if (Firebase.auth.currentUser == null) {
                        attemptAutoSignIn(
                            context = context,
                            credentialManager = credentialManager,
                            onAuthSuccess = { currentUser = Firebase.auth.currentUser },
                            onUnauthenticated = {},
                            scope = coroutineScope
                        )
                    }

                    onDispose {
                        Firebase.auth.removeAuthStateListener(authListener)
                    }
                }

                // Auth Gate: If unauthenticated, show AuthScreen with Google Sign-In
                if (currentUser == null) {
                    AuthScreen(
                        onAuthSuccess = { currentUser = Firebase.auth.currentUser }
                    )
                } else {
                    // Authenticated App Shell
                    var selectedTab by remember { mutableIntStateOf(0) }

                    // System back handler: return to Dashboard if on other tabs
                    BackHandler(enabled = selectedTab != 0) {
                        selectedTab = 0
                    }

                    Scaffold(
                        modifier = Modifier
                            .fillMaxSize()
                            .windowInsetsPadding(WindowInsets.statusBars),
                        topBar = {
                            CenterAlignedTopAppBar(
                                title = {
                                    Text(
                                        text = "EV Ride Planner",
                                        style = MaterialTheme.typography.titleLarge.copy(
                                            fontWeight = FontWeight.Bold
                                        ),
                                        color = MaterialTheme.colorScheme.onBackground
                                    )
                                },
                                navigationIcon = {
                                    Icon(
                                        imageVector = Icons.Default.ElectricScooter,
                                        contentDescription = "EV Ride Planner",
                                        tint = EvGreenPrimary,
                                        modifier = Modifier
                                            .padding(start = 16.dp)
                                            .size(28.dp)
                                    )
                                },
                                actions = {
                                    IconButton(
                                        onClick = { viewModel.toggleDarkMode() },
                                        modifier = Modifier.testTag("theme_toggle_btn")
                                    ) {
                                        Icon(
                                            imageVector = if (isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                                            contentDescription = "Toggle Theme",
                                            tint = if (isDarkMode) EvCyanSecondary else MaterialTheme.colorScheme.onSurface
                                        )
                                    }

                                    IconButton(
                                        onClick = {
                                            signOutUser(
                                                context = context,
                                                credentialManager = credentialManager,
                                                onSignOutComplete = { currentUser = null },
                                                scope = coroutineScope
                                            )
                                        },
                                        modifier = Modifier
                                            .padding(end = 8.dp)
                                            .testTag("sign_out_btn")
                                    ) {
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                                            contentDescription = "Sign Out",
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                },
                                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                                    containerColor = MaterialTheme.colorScheme.background
                                )
                            )
                        },
                        bottomBar = {
                            NavigationBar(
                                modifier = Modifier
                                    .windowInsetsPadding(WindowInsets.navigationBars)
                                    .testTag("main_bottom_nav"),
                                containerColor = MaterialTheme.colorScheme.surface,
                                tonalElevation = 6.dp
                            ) {
                                val items = listOf(
                                    NavItem("Planner", Icons.Default.ElectricScooter, "tab_planner"),
                                    NavItem("Stations", Icons.Default.EvStation, "tab_stations"),
                                    NavItem("Saved", Icons.Default.Bookmark, "tab_saved"),
                                    NavItem("History", Icons.Default.History, "tab_history")
                                )

                                items.forEachIndexed { index, item ->
                                    NavigationBarItem(
                                        selected = selectedTab == index,
                                        onClick = { selectedTab = index },
                                        icon = {
                                            Icon(
                                                imageVector = item.icon,
                                                contentDescription = item.label,
                                                modifier = Modifier.size(22.dp)
                                            )
                                        },
                                        label = { Text(item.label) },
                                        modifier = Modifier.testTag(item.tag),
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = EvGreenPrimary,
                                            selectedTextColor = EvGreenPrimary,
                                            indicatorColor = EvGreenPrimary.copy(alpha = 0.18f),
                                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    )
                                }
                            }
                        }
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            when (selectedTab) {
                                0 -> DashboardScreen(viewModel = viewModel)
                                1 -> StationsScreen(viewModel = viewModel)
                                2 -> SavedTripsScreen(
                                    viewModel = viewModel,
                                    onNavigateToPlanner = { selectedTab = 0 }
                                )
                                3 -> HistoryScreen(
                                    viewModel = viewModel,
                                    onNavigateToPlanner = { selectedTab = 0 }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private data class NavItem(
    val label: String,
    val icon: ImageVector,
    val tag: String
)
