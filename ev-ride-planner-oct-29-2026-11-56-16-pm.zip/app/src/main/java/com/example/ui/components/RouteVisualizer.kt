package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.StopItem
import com.example.data.model.StopType
import com.example.ui.theme.EvAmberTertiary
import com.example.ui.theme.EvCyanSecondary
import com.example.ui.theme.EvDangerRed
import com.example.ui.theme.EvGreenPrimary

@Composable
fun RouteVisualizer(
    stops: List<StopItem>,
    minReservePercent: Double = 15.0,
    modifier: Modifier = Modifier
) {
    if (stops.isEmpty()) return

    var isSoCView by remember { mutableStateOf(false) }

    // Pulsing animation for active GPS / EV waypoint beacon
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_beacon")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f), RoundedCornerShape(18.dp))
            .padding(14.dp)
            .testTag("route_visualizer")
    ) {
        // Toggle Header (Map Path vs Battery SoC Curve)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (isSoCView) Icons.Default.ShowChart else Icons.Default.Map,
                    contentDescription = null,
                    tint = EvGreenPrimary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isSoCView) "Battery SoC Trajectory" else "Interactive Route Track",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            // View Mode Switcher
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(3.dp)
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (!isSoCView) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                        .clickable { isSoCView = false }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "Map",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (!isSoCView) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSoCView) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                        .clickable { isSoCView = true }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "SoC Graph",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isSoCView) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Custom Canvas drawing
        val gridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)
        val outlineColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
        ) {
            Canvas(modifier = Modifier.matchParentSize()) {
                val w = size.width
                val h = size.height
                val padX = 36f
                val padY = 24f

                if (isSoCView) {
                    // Draw Battery State of Charge (SoC) % over sequence of stops
                    // Horizontal reserve guide line
                    val reserveY = padY + (h - 2 * padY) * (1f - (minReservePercent.toFloat() / 100f))
                    drawLine(
                        color = EvDangerRed.copy(alpha = 0.5f),
                        start = Offset(padX, reserveY),
                        end = Offset(w - padX, reserveY),
                        strokeWidth = 2f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                    )

                    // Compute points (both arrival and departure for charging stations)
                    val points = mutableListOf<Pair<Offset, Double>>()
                    val n = stops.size
                    val stepX = if (n > 1) (w - 2 * padX) / (n - 1) else 0f

                    for (i in stops.indices) {
                        val s = stops[i]
                        val x = padX + i * stepX
                        val arrivalY = padY + (h - 2 * padY) * (1f - (s.arrivalBatteryPercent.toFloat().coerceIn(0f, 100f) / 100f))
                        points.add(Offset(x, arrivalY) to s.arrivalBatteryPercent)

                        if (s.type == StopType.CHARGING_STATION && s.departureBatteryPercent > s.arrivalBatteryPercent) {
                            val depY = padY + (h - 2 * padY) * (1f - (s.departureBatteryPercent.toFloat().coerceIn(0f, 100f) / 100f))
                            // Charge step up vertical jump
                            points.add(Offset(x + 8f, depY) to s.departureBatteryPercent)
                        }
                    }

                    // Draw curve line
                    val path = Path()
                    points.forEachIndexed { idx, (pt, _) ->
                        if (idx == 0) path.moveTo(pt.x, pt.y) else path.lineTo(pt.x, pt.y)
                    }

                    drawPath(
                        path = path,
                        brush = Brush.horizontalGradient(
                            listOf(EvGreenPrimary, EvCyanSecondary, EvAmberTertiary)
                        ),
                        style = Stroke(width = 4f)
                    )

                    // Draw node dots
                    points.forEach { (pt, soc) ->
                        val dotColor = if (soc < minReservePercent) EvDangerRed else EvGreenPrimary
                        drawCircle(
                            color = Color.Black.copy(alpha = 0.4f),
                            radius = 9f,
                            center = pt
                        )
                        drawCircle(
                            color = dotColor,
                            radius = 6f,
                            center = pt
                        )
                    }
                } else {
                    // Geographic / Schematic Path Track view
                    val n = stops.size
                    val stepX = if (n > 1) (w - 2 * padX) / (n - 1) else 0f
                    val centerY = h / 2f

                    // Draw subtle grid lines
                    for (i in 0 until 4) {
                        val gy = padY + i * ((h - 2 * padY) / 3f)
                        drawLine(
                            color = gridColor,
                            start = Offset(0f, gy),
                            end = Offset(w, gy),
                            strokeWidth = 1f
                        )
                    }

                    // Draw path segments between stops
                    for (i in 0 until n - 1) {
                        val currX = padX + i * stepX
                        val nextX = padX + (i + 1) * stepX
                        val isLegSafe = stops[i].isLegSafe
                        val segColor = if (isLegSafe) EvGreenPrimary else EvDangerRed

                        // Curved bezier route connecting waypoints
                        val midX = (currX + nextX) / 2f
                        val curveOffset = if (i % 2 == 0) -24f else 24f

                        val segmentPath = Path().apply {
                            moveTo(currX, centerY)
                            quadraticTo(midX, centerY + curveOffset, nextX, centerY)
                        }

                        drawPath(
                            path = segmentPath,
                            color = segColor.copy(alpha = 0.8f),
                            style = Stroke(width = 5f)
                        )
                    }

                    // Draw Station & Stop Nodes
                    for (i in stops.indices) {
                        val stop = stops[i]
                        val x = padX + i * stepX
                        val nodeColor = when (stop.type) {
                            StopType.HOME -> EvGreenPrimary
                            StopType.CHARGING_STATION -> EvCyanSecondary
                            StopType.DESTINATION -> EvAmberTertiary
                        }

                        // Pulsing outer beacon for the first node (current location / vehicle)
                        if (i == 0) {
                            drawCircle(
                                color = nodeColor.copy(alpha = pulseAlpha * 0.4f),
                                radius = 18f,
                                center = Offset(x, centerY)
                            )
                        }

                        // Outer rim
                        drawCircle(
                            color = Color(0xFF131D17),
                            radius = 12f,
                            center = Offset(x, centerY)
                        )
                        // Inner fill
                        drawCircle(
                            color = nodeColor,
                            radius = 8f,
                            center = Offset(x, centerY)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Legend row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            LegendItem(color = EvGreenPrimary, label = "Home / Safe")
            LegendItem(color = EvCyanSecondary, label = "Charging Stop")
            LegendItem(color = EvAmberTertiary, label = "Destination")
            LegendItem(color = EvDangerRed, label = "Low / Deficit")
        }
    }
}

@Composable
fun LegendItem(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
