package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddRoad
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.EvStation
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ChargingStation
import com.example.ui.MainViewModel
import com.example.ui.theme.EvAmberTertiary
import com.example.ui.theme.EvCyanSecondary
import com.example.ui.theme.EvDangerRed
import com.example.ui.theme.EvGreenPrimary

@Composable
fun StationsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val stations by viewModel.allStations.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedCity by remember { mutableStateOf("All Cities") }
    var selectedNetwork by remember { mutableStateOf("All Networks") }
    var onlyFavorites by remember { mutableStateOf(false) }
    var showAddStationDialog by remember { mutableStateOf(false) }
    var isGpsNearMeActive by remember { mutableStateOf(false) }

    val cities = remember(stations) {
        listOf("All Cities") + stations.map { it.city }.distinct().sorted()
    }

    val networks = listOf("All Networks", "Ather Grid", "Bolt.earth", "Tata Power EZ Charge", "Jio-bp pulse", "Kazam")

    val filteredStations = remember(stations, searchQuery, selectedCity, selectedNetwork, onlyFavorites, isGpsNearMeActive) {
        stations.filter { st ->
            val matchesQuery = searchQuery.isBlank() ||
                st.name.contains(searchQuery, ignoreCase = true) ||
                st.address.contains(searchQuery, ignoreCase = true) ||
                st.network.contains(searchQuery, ignoreCase = true)
            val matchesCity = selectedCity == "All Cities" || st.city.equals(selectedCity, ignoreCase = true)
            val matchesNetwork = selectedNetwork == "All Networks" || st.network.contains(selectedNetwork, ignoreCase = true)
            val matchesFav = !onlyFavorites || st.isFavorite
            val matchesGps = !isGpsNearMeActive || st.city == "Bengaluru" // Simulated GPS radius filter

            matchesQuery && matchesCity && matchesNetwork && matchesFav && matchesGps
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddStationDialog = true },
                icon = { Icon(Icons.Default.Add, contentDescription = "Add Station") },
                text = { Text("Add Station") },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("fab_add_station")
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // Title & GPS indicator
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Charging Stations",
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Ather Grid, Bolt, Tata Power & community chargers",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                IconButton(
                    onClick = {
                        isGpsNearMeActive = !isGpsNearMeActive
                        val msg = if (isGpsNearMeActive) "GPS active: Showing stations nearby" else "Showing all stations"
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(if (isGpsNearMeActive) EvGreenPrimary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant)
                        .testTag("gps_toggle_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.MyLocation,
                        contentDescription = "GPS Near Me",
                        tint = if (isGpsNearMeActive) EvGreenPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search station name, city, street...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("station_search_input")
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Filter Chips Row: City, Network, Favorites
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    FilterChip(
                        selected = onlyFavorites,
                        onClick = { onlyFavorites = !onlyFavorites },
                        label = { Text("Favorites ★") },
                        leadingIcon = {
                            Icon(
                                imageVector = if (onlyFavorites) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                contentDescription = null,
                                tint = if (onlyFavorites) EvDangerRed else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    )
                }

                items(cities) { city ->
                    FilterChip(
                        selected = selectedCity == city,
                        onClick = { selectedCity = city },
                        label = { Text(city) }
                    )
                }

                items(networks.drop(1)) { net ->
                    FilterChip(
                        selected = selectedNetwork == net,
                        onClick = { selectedNetwork = if (selectedNetwork == net) "All Networks" else net },
                        label = { Text(net) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Results count
            Text(
                text = "Found ${filteredStations.size} stations",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Stations List
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 80.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredStations, key = { it.id }) { station ->
                    StationCard(
                        station = station,
                        onToggleFavorite = { viewModel.toggleStationFavorite(station) },
                        onAddToRoute = {
                            viewModel.addStationToRoute(station)
                            Toast.makeText(context, "Added ${station.name} to Route!", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
    }

    if (showAddStationDialog) {
        AddCustomStationDialog(
            onDismiss = { showAddStationDialog = false },
            onSave = { name, network, city, address, power, connector, cost ->
                viewModel.addCustomStation(name, network, city, address, power, connector, cost)
                showAddStationDialog = false
                Toast.makeText(context, "Custom station registered!", Toast.LENGTH_SHORT).show()
            }
        )
    }
}

@Composable
fun StationCard(
    station: ChargingStation,
    onToggleFavorite: () -> Unit,
    onAddToRoute: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("station_card_${station.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Header: Name, City & Favorite
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = station.name,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(top = 2.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = EvGreenPrimary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${station.city} • ${station.address}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1
                        )
                    }
                }

                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = if (station.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (station.isFavorite) EvDangerRed else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Tech Specs: Network, Power, Connector, Tariff
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                SpecBadge(label = station.network, color = EvCyanSecondary)
                SpecBadge(label = "${station.powerKw.toInt()} kW", color = EvGreenPrimary, icon = Icons.Default.Bolt)
                SpecBadge(label = station.connectorType, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Footer: Rate & Add to Route action
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Tariff: ₹%.1f / kWh • %s".format(station.costPerKwh, station.openHours),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedButton(
                    onClick = onAddToRoute,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .height(32.dp)
                        .testTag("add_to_route_${station.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.AddRoad,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Add to Route", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun SpecBadge(
    label: String,
    color: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(color.copy(alpha = 0.12f))
            .border(1.dp, color.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
            .padding(horizontal = 6.dp, vertical = 3.dp)
    ) {
        if (icon != null) {
            Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(12.dp))
            Spacer(modifier = Modifier.width(2.dp))
        }
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp, fontWeight = FontWeight.SemiBold),
            color = color
        )
    }
}

@Composable
fun AddCustomStationDialog(
    onDismiss: () -> Unit,
    onSave: (name: String, network: String, city: String, address: String, power: Double, connector: String, cost: Double) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var network by remember { mutableStateOf("Community EV Plug") }
    var city by remember { mutableStateOf("Bengaluru") }
    var address by remember { mutableStateOf("") }
    var powerStr by remember { mutableStateOf("3.3") }
    var connector by remember { mutableStateOf("16A 3-pin AC") }
    var costStr by remember { mutableStateOf("12.0") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Add Custom Station",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Station Name") },
                    placeholder = { Text("e.g. Highway Dhaba EV Point") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = city,
                    onValueChange = { city = it },
                    label = { Text("City / Region") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Address / Location") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = powerStr,
                        onValueChange = { powerStr = it },
                        label = { Text("Power (kW)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = costStr,
                        onValueChange = { costStr = it },
                        label = { Text("Cost (₹/kWh)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        val power = powerStr.toDoubleOrNull() ?: 3.3
                        val cost = costStr.toDoubleOrNull() ?: 12.0
                        onSave(name, network, city, address, power, connector, cost)
                    }
                }
            ) {
                Text("Register Station")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
