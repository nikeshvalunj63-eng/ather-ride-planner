package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ChargingStation
import com.example.data.model.RideDashboardStats
import com.example.data.model.RidePlan
import com.example.data.model.StopItem
import com.example.data.model.StopType
import com.example.data.model.WeatherCondition
import com.example.data.repository.RidePlanRepository
import com.example.domain.BatteryCalculator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Collections

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = RidePlanRepository(application)

    // Current active ride plan
    private val _currentPlan = MutableStateFlow(createDefaultPlan())
    val currentPlan: StateFlow<RidePlan> = _currentPlan.asStateFlow()

    // Calculated Dashboard Stats for active plan
    private val _dashboardStats = MutableStateFlow(RideDashboardStats())
    val dashboardStats: StateFlow<RideDashboardStats> = _dashboardStats.asStateFlow()

    // Database flows
    val savedPlans: StateFlow<List<RidePlan>> = repository.savedPlans.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val completedTrips: StateFlow<List<RidePlan>> = repository.completedTrips.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val allStations: StateFlow<List<ChargingStation>> = repository.allStations.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    // Dark Mode user preference
    private val _isDarkMode = MutableStateFlow(true)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    init {
        viewModelScope.launch {
            repository.initDefaultStationsIfNeeded()
            recalculateActivePlan()
        }
    }

    fun toggleDarkMode() {
        _isDarkMode.value = !_isDarkMode.value
    }

    private fun createDefaultPlan(): RidePlan {
        val initialStops = listOf(
            StopItem(
                name = "Home (Indiranagar)",
                type = StopType.HOME,
                distanceToNextKm = 32.0
            ),
            StopItem(
                name = "Ather Grid Fast Charger",
                type = StopType.CHARGING_STATION,
                distanceToNextKm = 45.0,
                targetChargePercent = 90.0,
                chargerSpeedKw = 25.0
            ),
            StopItem(
                name = "Nandi Hills Viewpoint",
                type = StopType.DESTINATION,
                distanceToNextKm = 42.0
            ),
            StopItem(
                name = "Home Return",
                type = StopType.HOME,
                distanceToNextKm = 0.0
            )
        )

        return RidePlan(
            title = "Weekend Ride to Nandi Hills",
            vehicleName = "Ather 450X (Gen 3)",
            batteryCapacityKwh = 3.7,
            nominalRangeKm = 110.0,
            startBatteryPercent = 100.0,
            minReservePercent = 15.0,
            weatherCondition = WeatherCondition.CLEAR,
            tariffPerKwh = 15.0,
            stops = initialStops
        )
    }

    fun recalculateActivePlan() {
        val plan = _currentPlan.value
        val (updatedStops, stats) = BatteryCalculator.recalculatePlan(plan)
        _currentPlan.value = plan.copy(stops = updatedStops)
        _dashboardStats.value = stats
    }

    fun updatePlanTitle(newTitle: String) {
        _currentPlan.value = _currentPlan.value.copy(title = newTitle)
    }

    fun updateVehicleSettings(
        vehicleName: String,
        nominalRangeKm: Double,
        batteryCapacityKwh: Double,
        startBatteryPercent: Double,
        minReservePercent: Double,
        weather: WeatherCondition,
        tariff: Double
    ) {
        _currentPlan.value = _currentPlan.value.copy(
            vehicleName = vehicleName,
            nominalRangeKm = nominalRangeKm,
            batteryCapacityKwh = batteryCapacityKwh,
            startBatteryPercent = startBatteryPercent,
            minReservePercent = minReservePercent,
            weatherCondition = weather,
            tariffPerKwh = tariff
        )
        recalculateActivePlan()
    }

    fun addStop(
        name: String,
        type: StopType,
        distanceToNext: Double,
        targetCharge: Double = 90.0,
        chargerSpeedKw: Double = 3.3
    ) {
        val currentStops = _currentPlan.value.stops.toMutableList()
        val newStop = StopItem(
            name = name,
            type = type,
            distanceToNextKm = distanceToNext,
            targetChargePercent = targetCharge,
            chargerSpeedKw = chargerSpeedKw
        )
        currentStops.add(newStop)
        _currentPlan.value = _currentPlan.value.copy(stops = currentStops)
        recalculateActivePlan()
    }

    fun updateStop(
        index: Int,
        name: String,
        type: StopType,
        distanceToNext: Double,
        targetCharge: Double,
        chargerSpeedKw: Double
    ) {
        val currentStops = _currentPlan.value.stops.toMutableList()
        if (index in currentStops.indices) {
            val existing = currentStops[index]
            currentStops[index] = existing.copy(
                name = name,
                type = type,
                distanceToNextKm = distanceToNext,
                targetChargePercent = targetCharge,
                chargerSpeedKw = chargerSpeedKw
            )
            _currentPlan.value = _currentPlan.value.copy(stops = currentStops)
            recalculateActivePlan()
        }
    }

    fun logActualBatteryAtStop(index: Int, actualBattery: Double?) {
        val currentStops = _currentPlan.value.stops.toMutableList()
        if (index in currentStops.indices) {
            val existing = currentStops[index]
            currentStops[index] = existing.copy(actualBatteryAfterCharge = actualBattery)
            _currentPlan.value = _currentPlan.value.copy(stops = currentStops)
            recalculateActivePlan()
        }
    }

    fun deleteStop(index: Int) {
        val currentStops = _currentPlan.value.stops.toMutableList()
        if (index in currentStops.indices) {
            currentStops.removeAt(index)
            _currentPlan.value = _currentPlan.value.copy(stops = currentStops)
            recalculateActivePlan()
        }
    }

    fun moveStop(fromIndex: Int, toIndex: Int) {
        val currentStops = _currentPlan.value.stops.toMutableList()
        if (fromIndex in currentStops.indices && toIndex in currentStops.indices) {
            Collections.swap(currentStops, fromIndex, toIndex)
            _currentPlan.value = _currentPlan.value.copy(stops = currentStops)
            recalculateActivePlan()
        }
    }

    fun addStationToRoute(station: ChargingStation) {
        val currentStops = _currentPlan.value.stops.toMutableList()
        val insertIndex = if (currentStops.size > 1) currentStops.size - 1 else currentStops.size
        val newStop = StopItem(
            name = "${station.name} (${station.network})",
            type = StopType.CHARGING_STATION,
            distanceToNextKm = 25.0,
            targetChargePercent = 90.0,
            chargerSpeedKw = station.powerKw
        )
        currentStops.add(insertIndex, newStop)
        _currentPlan.value = _currentPlan.value.copy(stops = currentStops)
        recalculateActivePlan()
    }

    fun clearAllStops() {
        _currentPlan.value = _currentPlan.value.copy(
            stops = listOf(
                StopItem(name = "Home", type = StopType.HOME, distanceToNextKm = 0.0)
            )
        )
        recalculateActivePlan()
    }

    fun saveCurrentPlan() {
        viewModelScope.launch {
            repository.savePlan(_currentPlan.value)
        }
    }

    fun markCurrentPlanCompleted() {
        viewModelScope.launch {
            repository.markPlanCompleted(_currentPlan.value)
        }
    }

    fun loadPlan(plan: RidePlan) {
        _currentPlan.value = plan
        recalculateActivePlan()
    }

    fun deleteSavedPlan(id: String) {
        viewModelScope.launch {
            repository.deletePlan(id)
        }
    }

    fun toggleStationFavorite(station: ChargingStation) {
        viewModelScope.launch {
            repository.toggleStationFavorite(station.id, station.isFavorite)
        }
    }

    fun addCustomStation(
        name: String,
        network: String,
        city: String,
        address: String,
        powerKw: Double,
        connectorType: String,
        costPerKwh: Double
    ) {
        viewModelScope.launch {
            val station = ChargingStation(
                name = name,
                network = network,
                city = city,
                address = address,
                latitude = 12.9716,
                longitude = 77.5946,
                powerKw = powerKw,
                connectorType = connectorType,
                costPerKwh = costPerKwh
            )
            repository.addCustomStation(station)
        }
    }
}
