package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ElectricScooter
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.RidePlan
import com.example.data.model.VehiclePreset
import com.example.data.model.WeatherCondition
import com.example.ui.theme.EvAmberTertiary
import com.example.ui.theme.EvCyanSecondary
import com.example.ui.theme.EvGreenPrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VehicleSettingsDialog(
    plan: RidePlan,
    onDismiss: () -> Unit,
    onSave: (
        vehicleName: String,
        nominalRangeKm: Double,
        batteryCapacityKwh: Double,
        startBatteryPercent: Double,
        minReservePercent: Double,
        weather: WeatherCondition,
        tariff: Double
    ) -> Unit
) {
    var vehicleName by remember { mutableStateOf(plan.vehicleName) }
    var nominalRangeStr by remember { mutableStateOf(plan.nominalRangeKm.toString()) }
    var capacityStr by remember { mutableStateOf(plan.batteryCapacityKwh.toString()) }
    var startBattery by remember { mutableDoubleStateOf(plan.startBatteryPercent) }
    var minReserve by remember { mutableDoubleStateOf(plan.minReservePercent) }
    var weather by remember { mutableStateOf(plan.weatherCondition) }
    var tariffStr by remember { mutableStateOf(plan.tariffPerKwh.toString()) }

    var isPresetMenuExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.ElectricScooter,
                    contentDescription = null,
                    tint = EvGreenPrimary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Vehicle & Ride Settings",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .testTag("vehicle_settings_dialog")
            ) {
                // Vehicle Preset Picker
                Text(
                    text = "Select Vehicle Preset",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))

                ExposedDropdownMenuBox(
                    expanded = isPresetMenuExpanded,
                    onExpandedChange = { isPresetMenuExpanded = it }
                ) {
                    OutlinedTextField(
                        value = vehicleName,
                        onValueChange = { vehicleName = it },
                        readOnly = false,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isPresetMenuExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor()
                            .testTag("vehicle_preset_dropdown")
                    )

                    ExposedDropdownMenu(
                        expanded = isPresetMenuExpanded,
                        onDismissRequest = { isPresetMenuExpanded = false }
                    ) {
                        VehiclePreset.ALL.forEach { preset ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(preset.name, fontWeight = FontWeight.Bold)
                                        Text(
                                            "${preset.nominalRangeKm.toInt()} km range | ${preset.batteryCapacityKwh} kWh",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                },
                                onClick = {
                                    vehicleName = preset.name
                                    nominalRangeStr = preset.nominalRangeKm.toString()
                                    capacityStr = preset.batteryCapacityKwh.toString()
                                    isPresetMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Vehicle Range at 100% Battery
                OutlinedTextField(
                    value = nominalRangeStr,
                    onValueChange = { nominalRangeStr = it },
                    label = { Text("100% Battery Range (km)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("nominal_range_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Battery Capacity in kWh
                OutlinedTextField(
                    value = capacityStr,
                    onValueChange = { capacityStr = it },
                    label = { Text("Battery Capacity (kWh)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("battery_capacity_input")
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Starting Battery Percentage
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Starting Battery %",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "${startBattery.toInt()}%",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = EvGreenPrimary
                    )
                }
                Slider(
                    value = startBattery.toFloat(),
                    onValueChange = { startBattery = it.toDouble() },
                    valueRange = 10f..100f,
                    steps = 17,
                    modifier = Modifier.testTag("start_battery_slider")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Minimum Safety Reserve %
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Safety Reserve Threshold %",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "${minReserve.toInt()}%",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = EvAmberTertiary
                    )
                }
                Slider(
                    value = minReserve.toFloat(),
                    onValueChange = { minReserve = it.toDouble() },
                    valueRange = 5f..30f,
                    steps = 24,
                    modifier = Modifier.testTag("min_reserve_slider")
                )
                Text(
                    text = "A warning triggers if arriving at any stop with less than ${minReserve.toInt()}% battery.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Weather Condition Impact Selector
                Text(
                    text = "Weather & Riding Conditions",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))

                WeatherCondition.entries.forEach { cond ->
                    val isSelected = weather == cond
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            .border(1.dp, if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent, RoundedCornerShape(8.dp))
                            .clickable { weather = cond }
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = cond.title,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = cond.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = "${(cond.rangeMultiplier * 100).toInt()}% eff.",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Electricity Tariff (₹ / kWh)
                OutlinedTextField(
                    value = tariffStr,
                    onValueChange = { tariffStr = it },
                    label = { Text("Electricity Cost (₹/kWh)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val nominal = nominalRangeStr.toDoubleOrNull() ?: 100.0
                    val cap = capacityStr.toDoubleOrNull() ?: 3.5
                    val tariff = tariffStr.toDoubleOrNull() ?: 15.0
                    onSave(vehicleName, nominal, cap, startBattery, minReserve, weather, tariff)
                },
                modifier = Modifier.testTag("save_vehicle_settings_btn")
            ) {
                Text("Apply Settings")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_vehicle_settings_btn")
            ) {
                Text("Cancel")
            }
        }
    )
}
