package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CheckCircleOutline
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EvStation
import androidx.compose.material.icons.filled.IosShare
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.StopItem
import com.example.data.model.StopType
import com.example.ui.MainViewModel
import com.example.ui.components.ActualBatteryDialog
import com.example.ui.components.AddEditStopDialog
import com.example.ui.components.DashboardSummaryCard
import com.example.ui.components.ExportImportDialog
import com.example.ui.components.RouteVisualizer
import com.example.ui.components.TimelineCard
import com.example.ui.components.VehicleSettingsDialog
import com.example.ui.theme.EvCyanSecondary
import com.example.ui.theme.EvGreenPrimary

@Composable
fun DashboardScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val plan by viewModel.currentPlan.collectAsState()
    val stats by viewModel.dashboardStats.collectAsState()

    var showVehicleSettings by remember { mutableStateOf(false) }
    var showExportImport by remember { mutableStateOf(false) }
    var stopToEditIndex by remember { mutableStateOf<Int?>(null) }
    var showAddStopDialog by remember { mutableStateOf(false) }
    var addStopDefaultType by remember { mutableStateOf(StopType.DESTINATION) }
    var stopToLogBatteryIndex by remember { mutableStateOf<Int?>(null) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    addStopDefaultType = StopType.DESTINATION
                    showAddStopDialog = true
                },
                icon = { Icon(Icons.Default.Add, contentDescription = "Add Stop") },
                text = { Text("Add Stop") },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("fab_add_stop")
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Plan Title & Action Bar
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = plan.title,
                            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onBackground,
                            maxLines = 1
                        )
                        Text(
                            text = "Electric Two-Wheeler Route Optimizer",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = {
                                viewModel.saveCurrentPlan()
                                Toast.makeText(context, "Ride Plan saved locally!", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.testTag("save_plan_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.BookmarkBorder,
                                contentDescription = "Save Plan",
                                tint = EvGreenPrimary
                            )
                        }

                        IconButton(
                            onClick = { showExportImport = true },
                            modifier = Modifier.testTag("export_import_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.IosShare,
                                contentDescription = "Export / Share",
                                tint = EvCyanSecondary
                            )
                        }

                        IconButton(
                            onClick = {
                                viewModel.markCurrentPlanCompleted()
                                Toast.makeText(context, "Ride logged to History!", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.testTag("complete_ride_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircleOutline,
                                contentDescription = "Mark Complete",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Dashboard Telemetry Card
            item {
                DashboardSummaryCard(
                    plan = plan,
                    stats = stats,
                    onOpenVehicleSettings = { showVehicleSettings = true }
                )
            }

            // Route Map / SoC Visualizer
            item {
                RouteVisualizer(
                    stops = plan.stops,
                    minReservePercent = plan.minReservePercent
                )
            }

            // Stops Section Header & Quick Add buttons
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Route Stops (${plan.stops.size})",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(
                            onClick = {
                                addStopDefaultType = StopType.CHARGING_STATION
                                showAddStopDialog = true
                            },
                            modifier = Modifier
                                .height(32.dp)
                                .testTag("quick_add_charger_btn"),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.EvStation, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("+ Charger", fontSize = 11.sp)
                        }

                        IconButton(
                            onClick = { viewModel.clearAllStops() },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteSweep,
                                contentDescription = "Clear Stops",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Timeline List of Stops
            itemsIndexed(plan.stops, key = { _, stop -> stop.id }) { index, stop ->
                TimelineCard(
                    stop = stop,
                    index = index,
                    totalStops = plan.stops.size,
                    minReservePercent = plan.minReservePercent,
                    onMoveUp = { viewModel.moveStop(index, index - 1) },
                    onMoveDown = { viewModel.moveStop(index, index + 1) },
                    onEdit = { stopToEditIndex = index },
                    onDelete = { viewModel.deleteStop(index) },
                    onLogActualBattery = { stopToLogBatteryIndex = index }
                )
            }

            // Extra bottom spacing for FAB
            item {
                Spacer(modifier = Modifier.height(72.dp))
            }
        }
    }

    // Dialogs
    if (showVehicleSettings) {
        VehicleSettingsDialog(
            plan = plan,
            onDismiss = { showVehicleSettings = false },
            onSave = { name, nominal, cap, start, minReserve, weather, tariff ->
                viewModel.updateVehicleSettings(name, nominal, cap, start, minReserve, weather, tariff)
                showVehicleSettings = false
            }
        )
    }

    if (showExportImport) {
        ExportImportDialog(
            currentPlan = plan,
            onDismiss = { showExportImport = false },
            onImportSuccess = { importedPlan ->
                viewModel.loadPlan(importedPlan)
                showExportImport = false
                Toast.makeText(context, "Plan imported successfully!", Toast.LENGTH_SHORT).show()
            }
        )
    }

    if (showAddStopDialog) {
        AddEditStopDialog(
            initialStop = StopItem(name = "", type = addStopDefaultType),
            isLastStop = false,
            onDismiss = { showAddStopDialog = false },
            onSave = { name, type, distance, targetCharge, chargerSpeed ->
                viewModel.addStop(name, type, distance, targetCharge, chargerSpeed)
                showAddStopDialog = false
            }
        )
    }

    stopToEditIndex?.let { idx ->
        if (idx in plan.stops.indices) {
            val stop = plan.stops[idx]
            AddEditStopDialog(
                initialStop = stop,
                isLastStop = idx == plan.stops.size - 1,
                onDismiss = { stopToEditIndex = null },
                onSave = { name, type, distance, targetCharge, chargerSpeed ->
                    viewModel.updateStop(idx, name, type, distance, targetCharge, chargerSpeed)
                    stopToEditIndex = null
                }
            )
        }
    }

    stopToLogBatteryIndex?.let { idx ->
        if (idx in plan.stops.indices) {
            val stop = plan.stops[idx]
            ActualBatteryDialog(
                stop = stop,
                onDismiss = { stopToLogBatteryIndex = null },
                onConfirm = { actualBattery ->
                    viewModel.logActualBatteryAtStop(idx, actualBattery)
                    stopToLogBatteryIndex = null
                }
            )
        }
    }
}
