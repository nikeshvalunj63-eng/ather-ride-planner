package com.example.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.StopItem
import com.example.ui.theme.EvCyanSecondary

@Composable
fun ActualBatteryDialog(
    stop: StopItem,
    onDismiss: () -> Unit,
    onConfirm: (actualBattery: Double?) -> Unit
) {
    var batteryVal by remember {
        mutableDoubleStateOf(stop.actualBatteryAfterCharge ?: stop.departureBatteryPercent)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Log Actual Battery at ${stop.name}",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("actual_battery_dialog")
            ) {
                Text(
                    text = "Did your scooter charge differently than projected? Enter the real battery % shown on your dashboard display to recalculate the rest of your trip instantly.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Actual Battery: ${batteryVal.toInt()}%",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = EvCyanSecondary
                )

                Slider(
                    value = batteryVal.toFloat(),
                    onValueChange = { batteryVal = it.toDouble() },
                    valueRange = 0f..100f,
                    steps = 99,
                    modifier = Modifier.testTag("actual_battery_slider")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = "%.0f".format(batteryVal),
                    onValueChange = { str ->
                        val parsed = str.toDoubleOrNull()
                        if (parsed != null) {
                            batteryVal = parsed.coerceIn(0.0, 100.0)
                        }
                    },
                    label = { Text("Exact Battery %") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(batteryVal) },
                modifier = Modifier.testTag("save_actual_battery_btn")
            ) {
                Text("Update & Recalculate")
            }
        },
        dismissButton = {
            TextButton(
                onClick = { onConfirm(null) }, // Clears manual override
                modifier = Modifier.testTag("clear_override_btn")
            ) {
                Text("Reset to Auto")
            }
        }
    )
}
