package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EvStation
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.StopItem
import com.example.data.model.StopType
import com.example.ui.theme.EvAmberTertiary
import com.example.ui.theme.EvCyanSecondary
import com.example.ui.theme.EvGreenPrimary

@Composable
fun AddEditStopDialog(
    initialStop: StopItem? = null,
    isLastStop: Boolean = false,
    onDismiss: () -> Unit,
    onSave: (name: String, type: StopType, distanceToNext: Double, targetCharge: Double, chargerSpeedKw: Double) -> Unit
) {
    var name by remember { mutableStateOf(initialStop?.name ?: "") }
    var type by remember { mutableStateOf(initialStop?.type ?: StopType.DESTINATION) }
    var distanceStr by remember { mutableStateOf(initialStop?.distanceToNextKm?.takeIf { it > 0 }?.toString() ?: "15.0") }
    var targetCharge by remember { mutableDoubleStateOf(initialStop?.targetChargePercent ?: 90.0) }
    var chargerSpeedKw by remember { mutableDoubleStateOf(initialStop?.chargerSpeedKw ?: 3.3) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialStop == null) "Add Route Stop" else "Edit Stop",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("add_edit_stop_dialog")
            ) {
                // Stop Name
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Stop Name") },
                    placeholder = { Text("e.g. Home, Ather Grid, Office, Cafe") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("stop_name_input")
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Stop Type Selector
                Text(
                    text = "Stop Type",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    TypeSelectorChip(
                        title = "Home",
                        icon = Icons.Default.Home,
                        isSelected = type == StopType.HOME,
                        onClick = { type = StopType.HOME },
                        modifier = Modifier.weight(1f)
                    )
                    TypeSelectorChip(
                        title = "Charging",
                        icon = Icons.Default.EvStation,
                        isSelected = type == StopType.CHARGING_STATION,
                        onClick = { type = StopType.CHARGING_STATION },
                        modifier = Modifier.weight(1f)
                    )
                    TypeSelectorChip(
                        title = "Waypoint",
                        icon = Icons.Default.LocationOn,
                        isSelected = type == StopType.DESTINATION,
                        onClick = { type = StopType.DESTINATION },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Distance to Next Stop (km)
                OutlinedTextField(
                    value = distanceStr,
                    onValueChange = { distanceStr = it },
                    label = { Text("Distance to Next Stop (km)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("distance_input")
                )

                // Extra controls if Charging Station
                if (type == StopType.CHARGING_STATION) {
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Target Charge: ${targetCharge.toInt()}%",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = EvCyanSecondary
                    )
                    Slider(
                        value = targetCharge.toFloat(),
                        onValueChange = { targetCharge = it.toDouble() },
                        valueRange = 50f..100f,
                        steps = 9,
                        modifier = Modifier.testTag("target_charge_slider")
                    )

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Charger Power Speed",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ChargerSpeedChip(
                            title = "3.3 kW (Slow AC)",
                            speedKw = 3.3,
                            selectedSpeed = chargerSpeedKw,
                            onSelect = { chargerSpeedKw = it },
                            modifier = Modifier.weight(1f)
                        )
                        ChargerSpeedChip(
                            title = "7.4 kW (Type 2)",
                            speedKw = 7.4,
                            selectedSpeed = chargerSpeedKw,
                            onSelect = { chargerSpeedKw = it },
                            modifier = Modifier.weight(1f)
                        )
                        ChargerSpeedChip(
                            title = "25 kW (DC Fast)",
                            speedKw = 25.0,
                            selectedSpeed = chargerSpeedKw,
                            onSelect = { chargerSpeedKw = it },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val finalName = name.ifBlank {
                        when (type) {
                            StopType.HOME -> "Home"
                            StopType.CHARGING_STATION -> "Charging Station"
                            StopType.DESTINATION -> "Destination"
                        }
                    }
                    val distance = distanceStr.toDoubleOrNull() ?: 0.0
                    onSave(finalName, type, distance, targetCharge, chargerSpeedKw)
                },
                modifier = Modifier.testTag("save_stop_button")
            ) {
                Text("Save Stop")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_stop_button")
            ) {
                Text("Cancel")
            }
        }
    )
}

@Composable
private fun TypeSelectorChip(
    title: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bg = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
    val borderCol = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(bg)
            .border(1.dp, borderCol, RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(vertical = 8.dp, horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ChargerSpeedChip(
    title: String,
    speedKw: Double,
    selectedSpeed: Double,
    onSelect: (Double) -> Unit,
    modifier: Modifier = Modifier
) {
    val isSelected = selectedSpeed == speedKw
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) EvCyanSecondary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant)
            .border(1.dp, if (isSelected) EvCyanSecondary else Color.Transparent, RoundedCornerShape(8.dp))
            .clickable { onSelect(speedKw) }
            .padding(vertical = 6.dp, horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            color = if (isSelected) EvCyanSecondary else MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1
        )
    }
}
