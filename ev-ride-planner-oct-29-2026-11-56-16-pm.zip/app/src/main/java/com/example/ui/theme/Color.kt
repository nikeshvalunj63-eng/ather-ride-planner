package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// High-tech EV Green & Neon Palette
val EvGreenPrimary = Color(0xFF00E676)       // Vibrant Electric Green
val EvGreenOnPrimary = Color(0xFF003919)
val EvGreenPrimaryContainer = Color(0xFF005327)
val EvGreenOnPrimaryContainer = Color(0xFF69FF9E)

val EvCyanSecondary = Color(0xFF00E5FF)      // Electric Cyan / Fast Charger
val EvCyanOnSecondary = Color(0xFF00363D)
val EvCyanSecondaryContainer = Color(0xFF004F58)
val EvCyanOnSecondaryContainer = Color(0xFF80F4FF)

val EvAmberTertiary = Color(0xFFFFB300)      // Low battery warning
val EvAmberOnTertiary = Color(0xFF432C00)
val EvAmberTertiaryContainer = Color(0xFF614000)
val EvAmberOnTertiaryContainer = Color(0xFFFFDF9E)

// Status colors
val EvSafeGreen = Color(0xFF00E676)
val EvWarningAmber = Color(0xFFFFAB00)
val EvDangerRed = Color(0xFFFF5252)
val EvChargeBlue = Color(0xFF40C4FF)

// Dark Theme Cockpit Colors
val DarkBackground = Color(0xFF0D1410)
val DarkSurface = Color(0xFF131D17)
val DarkSurfaceVariant = Color(0xFF1B2921)
val DarkSurfaceCard = Color(0xFF16231B)
val DarkOnBackground = Color(0xFFE1E9E2)
val DarkOnSurface = Color(0xFFE1E9E2)
val DarkOnSurfaceVariant = Color(0xFFA1B3A6)
val DarkOutline = Color(0xFF2E4437)

// Light Theme Colors
val LightBackground = Color(0xFFF3F8F4)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE4EFE7)
val LightSurfaceCard = Color(0xFFF7FAF8)
val LightOnBackground = Color(0xFF101B14)
val LightOnSurface = Color(0xFF101B14)
val LightOnSurfaceVariant = Color(0xFF425147)
val LightOutline = Color(0xFFC3D5C8)
