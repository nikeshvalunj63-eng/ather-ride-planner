package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = EvGreenPrimary,
    onPrimary = EvGreenOnPrimary,
    primaryContainer = EvGreenPrimaryContainer,
    onPrimaryContainer = EvGreenOnPrimaryContainer,
    secondary = EvCyanSecondary,
    onSecondary = EvCyanOnSecondary,
    secondaryContainer = EvCyanSecondaryContainer,
    onSecondaryContainer = EvCyanOnSecondaryContainer,
    tertiary = EvAmberTertiary,
    onTertiary = EvAmberOnTertiary,
    tertiaryContainer = EvAmberTertiaryContainer,
    onTertiaryContainer = EvAmberOnTertiaryContainer,
    background = DarkBackground,
    onBackground = DarkOnBackground,
    surface = DarkSurface,
    onSurface = DarkOnSurface,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkOnSurfaceVariant,
    outline = DarkOutline,
    error = EvDangerRed
)

private val LightColorScheme = lightColorScheme(
    primary = EvGreenPrimaryContainer,
    onPrimary = LightSurface,
    primaryContainer = EvGreenOnPrimaryContainer,
    onPrimaryContainer = EvGreenOnPrimary,
    secondary = EvCyanSecondaryContainer,
    onSecondary = LightSurface,
    secondaryContainer = EvCyanOnSecondaryContainer,
    onSecondaryContainer = EvCyanOnSecondary,
    tertiary = EvAmberTertiaryContainer,
    onTertiary = LightSurface,
    tertiaryContainer = EvAmberOnTertiaryContainer,
    onTertiaryContainer = EvAmberOnTertiary,
    background = LightBackground,
    onBackground = LightOnBackground,
    surface = LightSurface,
    onSurface = LightOnSurface,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightOnSurfaceVariant,
    outline = LightOutline,
    error = EvDangerRed
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = colorScheme.background.toArgb()
                window.navigationBarColor = colorScheme.background.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
