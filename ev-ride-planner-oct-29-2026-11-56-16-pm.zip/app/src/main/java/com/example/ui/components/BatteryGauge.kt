package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EvAmberTertiary
import com.example.ui.theme.EvCyanSecondary
import com.example.ui.theme.EvDangerRed
import com.example.ui.theme.EvGreenPrimary

@Composable
fun BatteryBar(
    batteryPercent: Double,
    minReservePercent: Double = 15.0,
    modifier: Modifier = Modifier,
    showLabel: Boolean = true
) {
    val clamped = batteryPercent.coerceIn(0.0, 100.0)
    val animatedProgress by animateFloatAsState(
        targetValue = (clamped / 100.0).toFloat(),
        label = "battery_progress"
    )

    val barColor = when {
        batteryPercent < 0.0 -> EvDangerRed
        batteryPercent < minReservePercent -> EvDangerRed
        batteryPercent < (minReservePercent + 15.0) -> EvAmberTertiary
        else -> EvGreenPrimary
    }

    Column(modifier = modifier) {
        if (showLabel) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (batteryPercent < minReservePercent) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Low Battery",
                            tint = EvDangerRed,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                    Text(
                        text = if (batteryPercent < 0) "Depleted" else "Battery",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(
                    text = "%.1f%%".format(batteryPercent),
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = barColor
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
        }

        // Horizontal Battery Bar with Battery Terminal Cap
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(14.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                    .testTag("battery_progress_bar")
            ) {
                // Fill
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(animatedProgress)
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(
                                    barColor.copy(alpha = 0.8f),
                                    barColor
                                )
                            )
                        )
                )

                // Reserve line indicator
                val reserveFraction = (minReservePercent / 100.0).toFloat().coerceIn(0f, 1f)
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(reserveFraction)
                ) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .width(2.dp)
                            .fillMaxHeight()
                            .background(Color.White.copy(alpha = 0.7f))
                    )
                }
            }
            Spacer(modifier = Modifier.width(3.dp))
            // Battery positive terminal nub
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height(7.dp)
                    .clip(RoundedCornerShape(topEnd = 2.dp, bottomEnd = 2.dp))
                    .background(MaterialTheme.colorScheme.outline)
            )
        }
    }
}

@Composable
fun BatteryBadge(
    batteryPercent: Double,
    isCharging: Boolean = false,
    minReservePercent: Double = 15.0,
    modifier: Modifier = Modifier
) {
    val bgColor = when {
        isCharging -> EvCyanSecondary.copy(alpha = 0.18f)
        batteryPercent < 0.0 -> EvDangerRed.copy(alpha = 0.2f)
        batteryPercent < minReservePercent -> EvDangerRed.copy(alpha = 0.18f)
        batteryPercent < (minReservePercent + 15.0) -> EvAmberTertiary.copy(alpha = 0.18f)
        else -> EvGreenPrimary.copy(alpha = 0.18f)
    }

    val contentColor = when {
        isCharging -> EvCyanSecondary
        batteryPercent < minReservePercent -> EvDangerRed
        batteryPercent < (minReservePercent + 15.0) -> EvAmberTertiary
        else -> EvGreenPrimary
    }

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .border(1.dp, contentColor.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (isCharging) {
            Icon(
                imageVector = Icons.Default.Bolt,
                contentDescription = "Charging",
                tint = contentColor,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(2.dp))
        }
        Text(
            text = "%.1f%%".format(batteryPercent),
            style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            ),
            color = contentColor
        )
    }
}
