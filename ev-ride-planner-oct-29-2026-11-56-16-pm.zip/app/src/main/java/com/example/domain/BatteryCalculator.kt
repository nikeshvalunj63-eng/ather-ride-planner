package com.example.domain

import com.example.data.model.RideDashboardStats
import com.example.data.model.RidePlan
import com.example.data.model.StopItem
import com.example.data.model.StopType
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

object BatteryCalculator {

    /**
     * Calculates battery levels, safety checks, and statistics for the entire ride.
     */
    fun recalculatePlan(plan: RidePlan): Pair<List<StopItem>, RideDashboardStats> {
        val stops = plan.stops
        val effectiveRange = max(1.0, plan.nominalRangeKm * plan.weatherCondition.rangeMultiplier)
        val minReserve = plan.minReservePercent
        val batteryCap = max(0.5, plan.batteryCapacityKwh)
        val tariff = plan.tariffPerKwh

        if (stops.isEmpty()) {
            return Pair(
                emptyList(),
                RideDashboardStats(
                    effectiveRangeKm = effectiveRange,
                    finalBatteryPercent = plan.startBatteryPercent
                )
            )
        }

        val updatedStops = mutableListOf<StopItem>()
        var currentBattery = plan.startBatteryPercent
        var totalDistance = 0.0
        var totalChargeMinutes = 0
        var totalChargeCost = 0.0
        var allLegsSafe = true
        var hasReserveBreached = false
        var lowestBattery = plan.startBatteryPercent

        for (i in stops.indices) {
            val stop = stops[i]
            val arrivalBattery = if (i == 0) plan.startBatteryPercent else currentBattery
            lowestBattery = min(lowestBattery, arrivalBattery)

            // Determine departure battery after charging if applicable
            val departureBattery: Double
            val chargeMinutes: Int
            val chargeCost: Double

            if (stop.actualBatteryAfterCharge != null) {
                // User explicitly manually logged actual post-charge battery
                departureBattery = stop.actualBatteryAfterCharge.coerceIn(0.0, 100.0)
                val percentGained = max(0.0, departureBattery - arrivalBattery)
                val energyKwh = (percentGained / 100.0) * batteryCap
                val hours = if (stop.chargerSpeedKw > 0) energyKwh / stop.chargerSpeedKw else 0.0
                chargeMinutes = (hours * 60).roundToInt()
                chargeCost = energyKwh * tariff
            } else if (stop.type == StopType.CHARGING_STATION) {
                // Automatically charge up to target percentage
                departureBattery = max(arrivalBattery, stop.targetChargePercent).coerceIn(0.0, 100.0)
                val percentGained = max(0.0, departureBattery - arrivalBattery)
                val energyKwh = (percentGained / 100.0) * batteryCap
                val hours = if (stop.chargerSpeedKw > 0) energyKwh / stop.chargerSpeedKw else 0.0
                chargeMinutes = (hours * 60).roundToInt()
                chargeCost = energyKwh * tariff
            } else {
                departureBattery = arrivalBattery
                chargeMinutes = 0
                chargeCost = 0.0
            }

            totalChargeMinutes += chargeMinutes
            totalChargeCost += chargeCost

            // Next leg consumption
            val isLastStop = (i == stops.size - 1)
            val distanceToNext = if (isLastStop) 0.0 else max(0.0, stop.distanceToNextKm)
            totalDistance += distanceToNext

            val legConsumptionPercent = (distanceToNext / effectiveRange) * 100.0
            val projectedArrivalAtNext = departureBattery - legConsumptionPercent

            // Safety evaluation for arrival at this stop
            val isArrivalPositive = arrivalBattery >= 0.0
            val isArrivalAboveReserve = arrivalBattery >= minReserve

            // Safety evaluation for taking off towards the next stop
            val isLegPossible = isLastStop || (projectedArrivalAtNext >= 0.0)
            val isLegAboveReserve = isLastStop || (projectedArrivalAtNext >= minReserve)

            var warningMessage: String? = null
            if (arrivalBattery < 0.0) {
                warningMessage = "Battery exhausted before reaching this stop! (${formatPercent(arrivalBattery)})"
                allLegsSafe = false
            } else if (arrivalBattery < minReserve) {
                warningMessage = "Arriving below ${minReserve.toInt()}% safety reserve (${formatPercent(arrivalBattery)})"
                hasReserveBreached = true
            } else if (!isLastStop && projectedArrivalAtNext < 0.0) {
                val needed = -projectedArrivalAtNext
                warningMessage = "Cannot reach next stop! Deficit: -${formatPercent(needed)} (${formatKm(needed / 100.0 * effectiveRange)} km)"
                allLegsSafe = false
            } else if (!isLastStop && projectedArrivalAtNext < minReserve) {
                warningMessage = "Next arrival (${formatPercent(projectedArrivalAtNext)}) will breach ${minReserve.toInt()}% reserve"
                hasReserveBreached = true
            }

            val updatedStop = stop.copy(
                arrivalBatteryPercent = arrivalBattery,
                departureBatteryPercent = departureBattery,
                consumptionPercentNextLeg = legConsumptionPercent,
                isArrivalSafe = isArrivalPositive && isArrivalAboveReserve,
                isLegSafe = isLegPossible && isLegAboveReserve,
                safetyWarning = warningMessage,
                chargeDurationMinutes = chargeMinutes,
                chargeCost = chargeCost
            )
            updatedStops.add(updatedStop)

            // Setup battery for next stop
            currentBattery = projectedArrivalAtNext
        }

        val finalArrivalBattery = updatedStops.last().arrivalBatteryPercent
        val extraDistancePossible = if (finalArrivalBattery > 0) {
            (finalArrivalBattery / 100.0) * effectiveRange
        } else {
            0.0
        }

        val isTripSafe = allLegsSafe && !hasReserveBreached && finalArrivalBattery >= minReserve
        val statusSummary = when {
            !allLegsSafe || finalArrivalBattery < 0 -> "UNSAFE: Will run out of battery"
            hasReserveBreached || finalArrivalBattery < minReserve -> "WARNING: Safety reserve breached"
            else -> "PASS: Safe Route with comfortable buffer"
        }

        val chargingStopsCount = stops.count { it.type == StopType.CHARGING_STATION }

        val stats = RideDashboardStats(
            totalDistanceKm = totalDistance,
            finalBatteryPercent = finalArrivalBattery,
            extraDistancePossibleKm = extraDistancePossible,
            chargingStopsCount = chargingStopsCount,
            isTripSafe = isTripSafe,
            statusSummary = statusSummary,
            totalChargingMinutes = totalChargeMinutes,
            totalEstimatedCost = totalChargeCost,
            effectiveRangeKm = effectiveRange,
            lowestBatteryPercent = lowestBattery
        )

        return Pair(updatedStops, stats)
    }

    private fun formatPercent(value: Double): String = "%.1f%%".format(value)
    private fun formatKm(value: Double): String = "%.1f".format(value)
}
