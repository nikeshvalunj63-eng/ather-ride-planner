package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface RidePlanDao {
    @Query("SELECT * FROM ride_plans WHERE isSaved = 1 ORDER BY createdAt DESC")
    fun getSavedPlans(): Flow<List<RidePlanEntity>>

    @Query("SELECT * FROM ride_plans WHERE isCompleted = 1 ORDER BY createdAt DESC")
    fun getCompletedTrips(): Flow<List<RidePlanEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlan(plan: RidePlanEntity)

    @Delete
    suspend fun deletePlan(plan: RidePlanEntity)

    @Query("DELETE FROM ride_plans WHERE id = :id")
    suspend fun deletePlanById(id: String)

    @Query("SELECT * FROM ride_plans WHERE id = :id LIMIT 1")
    suspend fun getPlanById(id: String): RidePlanEntity?
}
