package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "charging_stations")
data class ChargingStationEntity(
    @PrimaryKey val id: String,
    val name: String,
    val network: String,
    val city: String,
    val address: String,
    val latitude: Double,
    val longitude: Double,
    val powerKw: Double,
    val connectorType: String,
    val costPerKwh: Double,
    val isFavorite: Boolean,
    val openHours: String
)
