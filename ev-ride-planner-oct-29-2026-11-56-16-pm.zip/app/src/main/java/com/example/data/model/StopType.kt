package com.example.data.model

enum class StopType {
    HOME,
    CHARGING_STATION,
    DESTINATION
}
