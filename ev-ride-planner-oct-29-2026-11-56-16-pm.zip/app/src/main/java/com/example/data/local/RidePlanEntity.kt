package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "ride_plans")
data class RidePlanEntity(
    @PrimaryKey val id: String,
    val title: String,
    val vehicleName: String,
    val batteryCapacityKwh: Double,
    val nominalRangeKm: Double,
    val startBatteryPercent: Double,
    val minReservePercent: Double,
    val weatherCondition: String,
    val tariffPerKwh: Double,
    val stopsJson: String,
    val isSaved: Boolean,
    val isCompleted: Boolean,
    val createdAt: Long
)
