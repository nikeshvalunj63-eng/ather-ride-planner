package com.example.data.model

data class VehiclePreset(
    val name: String,
    val nominalRangeKm: Double,
    val batteryCapacityKwh: Double,
    val brand: String
) {
    companion object {
        val ALL = listOf(
            VehiclePreset("Ather 450X (Gen 3)", 110.0, 3.7, "Ather"),
            VehiclePreset("Ola S1 Pro (Gen 2)", 145.0, 4.0, "Ola Electric"),
            VehiclePreset("TVS iQube ST", 120.0, 4.56, "TVS"),
            VehiclePreset("Bajaj Chetak Premium", 95.0, 3.2, "Bajaj"),
            VehiclePreset("Ultraviolette F77 Recon", 220.0, 10.3, "Ultraviolette"),
            VehiclePreset("Vida V1 Pro", 115.0, 3.94, "Hero Vida"),
            VehiclePreset("Revolt RV400", 110.0, 3.24, "Revolt"),
            VehiclePreset("Custom Two-Wheeler", 100.0, 3.5, "Custom")
        )
    }
}
