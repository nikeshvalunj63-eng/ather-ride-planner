package com.example.data.model

enum class WeatherCondition(
    val title: String,
    val rangeMultiplier: Double,
    val description: String
) {
    CLEAR(
        title = "Optimal (25°C)",
        rangeMultiplier = 1.0,
        description = "Ideal ambient temperature, dry flat road"
    ),
    HOT(
        title = "High Heat (38°C+)",
        rangeMultiplier = 0.92,
        description = "Battery thermal cooling load (-8% range)"
    ),
    RAIN(
        title = "Rain & Wet Roads",
        rangeMultiplier = 0.88,
        description = "Hydrodynamic drag & slick rolling resistance (-12% range)"
    ),
    HEADWIND(
        title = "Strong Headwind",
        rangeMultiplier = 0.84,
        description = "High aerodynamic resistance at highway speed (-16% range)"
    ),
    HILLY(
        title = "Hill Climb / Ghats",
        rangeMultiplier = 0.78,
        description = "Continuous incline & elevation gain (-22% range)"
    )
}
