package com.example.data.repository

import android.content.Context
import com.example.data.local.AppDatabase
import com.example.data.local.ChargingStationEntity
import com.example.data.local.JsonHelper
import com.example.data.local.RidePlanEntity
import com.example.data.model.ChargingStation
import com.example.data.model.RidePlan
import com.example.data.model.StopItem
import com.example.data.model.StopType
import com.example.data.model.WeatherCondition
import com.example.data.remote.FirestoreRidePlanRepository
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

class RidePlanRepository(context: Context) {
    private val db = AppDatabase.getDatabase(context)
    private val planDao = db.ridePlanDao()
    private val stationDao = db.chargingStationDao()
    private val firestoreRepo = FirestoreRidePlanRepository(context)

    val savedPlans: Flow<List<RidePlan>> = planDao.getSavedPlans().map { entities ->
        entities.map { it.toDomain() }
    }

    val completedTrips: Flow<List<RidePlan>> = planDao.getCompletedTrips().map { entities ->
        entities.map { it.toDomain() }
    }

    val allStations: Flow<List<ChargingStation>> = stationDao.getAllStations().map { entities ->
        entities.map { it.toDomain() }
    }

    val favoriteStations: Flow<List<ChargingStation>> = stationDao.getFavoriteStations().map { entities ->
        entities.map { it.toDomain() }
    }

    suspend fun initDefaultStationsIfNeeded() {
        if (stationDao.getStationCount() == 0) {
            val defaults = listOf(
                ChargingStationEntity(
                    id = "ath_blr_1",
                    name = "Ather Grid - Indiranagar",
                    network = "Ather Grid",
                    city = "Bengaluru",
                    address = "100 Feet Rd, HAL 2nd Stage, Indiranagar",
                    latitude = 12.9784,
                    longitude = 77.6408,
                    powerKw = 25.0,
                    connectorType = "Ather Fast Dot",
                    costPerKwh = 18.0,
                    isFavorite = true,
                    openHours = "24/7 Available"
                ),
                ChargingStationEntity(
                    id = "ath_blr_2",
                    name = "Ather Grid - Koramangala Cafe",
                    network = "Ather Grid",
                    city = "Bengaluru",
                    address = "80 Feet Rd, 4th Block, Koramangala",
                    latitude = 12.9352,
                    longitude = 77.6245,
                    powerKw = 25.0,
                    connectorType = "Ather Fast Dot",
                    costPerKwh = 18.0,
                    isFavorite = false,
                    openHours = "24/7 Available"
                ),
                ChargingStationEntity(
                    id = "bolt_blr_1",
                    name = "Bolt.Earth - Whitefield Hub",
                    network = "Bolt.earth",
                    city = "Bengaluru",
                    address = "ITPB Main Rd, Whitefield",
                    latitude = 12.9863,
                    longitude = 77.7314,
                    powerKw = 3.3,
                    connectorType = "16A 3-pin AC",
                    costPerKwh = 12.0,
                    isFavorite = false,
                    openHours = "6:00 AM - 11:00 PM"
                ),
                ChargingStationEntity(
                    id = "tata_blr_1",
                    name = "Tata Power EZ - Electronic City",
                    network = "Tata Power EZ Charge",
                    city = "Bengaluru",
                    address = "Phase 1, Hosur Road, Electronic City",
                    latitude = 12.8452,
                    longitude = 77.6602,
                    powerKw = 7.4,
                    connectorType = "Type 2",
                    costPerKwh = 16.5,
                    isFavorite = false,
                    openHours = "24/7 Available"
                ),
                ChargingStationEntity(
                    id = "ath_mum_1",
                    name = "Ather Grid - Bandra West",
                    network = "Ather Grid",
                    city = "Mumbai",
                    address = "Hill Road, Bandra West",
                    latitude = 19.0596,
                    longitude = 72.8295,
                    powerKw = 25.0,
                    connectorType = "Ather Fast Dot",
                    costPerKwh = 19.0,
                    isFavorite = true,
                    openHours = "24/7 Available"
                ),
                ChargingStationEntity(
                    id = "jio_mum_1",
                    name = "Jio-bp pulse - BKC Station",
                    network = "Jio-bp pulse",
                    city = "Mumbai",
                    address = "G Block, Bandra Kurla Complex",
                    latitude = 19.0657,
                    longitude = 72.8687,
                    powerKw = 30.0,
                    connectorType = "CCS2 & Type 2",
                    costPerKwh = 17.5,
                    isFavorite = false,
                    openHours = "24/7 Available"
                ),
                ChargingStationEntity(
                    id = "kaz_del_1",
                    name = "Kazam Charging - Connaught Place",
                    network = "Kazam",
                    city = "Delhi",
                    address = "Outer Circle, CP, New Delhi",
                    latitude = 28.6315,
                    longitude = 77.2167,
                    powerKw = 7.4,
                    connectorType = "Type 2 & 16A",
                    costPerKwh = 14.0,
                    isFavorite = false,
                    openHours = "24/7 Available"
                ),
                ChargingStationEntity(
                    id = "ath_pune_1",
                    name = "Ather Grid - FC Road",
                    network = "Ather Grid",
                    city = "Pune",
                    address = "Fergusson College Road, Shivajinagar",
                    latitude = 18.5204,
                    longitude = 73.8415,
                    powerKw = 25.0,
                    connectorType = "Ather Fast Dot",
                    costPerKwh = 18.0,
                    isFavorite = false,
                    openHours = "24/7 Available"
                ),
                ChargingStationEntity(
                    id = "bolt_hyd_1",
                    name = "Bolt.Earth - Hitec City",
                    network = "Bolt.earth",
                    city = "Hyderabad",
                    address = "Madhapur, Hitec City",
                    latitude = 17.4474,
                    longitude = 78.3762,
                    powerKw = 3.3,
                    connectorType = "16A 3-pin AC",
                    costPerKwh = 13.0,
                    isFavorite = false,
                    openHours = "24/7 Available"
                ),
                ChargingStationEntity(
                    id = "ath_goa_1",
                    name = "Ather Grid - Panjim Promenade",
                    network = "Ather Grid",
                    city = "Goa",
                    address = "Dayanand Bandodkar Marg, Panaji",
                    latitude = 15.4989,
                    longitude = 73.8278,
                    powerKw = 25.0,
                    connectorType = "Ather Fast Dot",
                    costPerKwh = 18.5,
                    isFavorite = true,
                    openHours = "24/7 Available"
                )
            )
            stationDao.insertAll(defaults)
        }
    }

    suspend fun savePlan(plan: RidePlan) {
        val entity = plan.toEntity(isSaved = true)
        planDao.insertPlan(entity)
        if (Firebase.auth.currentUser != null) {
            try {
                firestoreRepo.saveRidePlan(plan.copy(isSaved = true))
            } catch (e: Exception) {
                // Logged via handleFirestoreError in firestoreRepo
            }
        }
    }

    suspend fun markPlanCompleted(plan: RidePlan) {
        val completed = plan.copy(isSaved = true, isCompleted = true)
        val entity = completed.toEntity(isSaved = true)
        planDao.insertPlan(entity)
        if (Firebase.auth.currentUser != null) {
            try {
                firestoreRepo.saveRidePlan(completed)
            } catch (e: Exception) {
                // Logged
            }
        }
    }

    suspend fun deletePlan(id: String) {
        planDao.deletePlanById(id)
        if (Firebase.auth.currentUser != null) {
            try {
                firestoreRepo.deleteRidePlan(id)
            } catch (e: Exception) {
                // Logged
            }
        }
    }

    suspend fun toggleStationFavorite(station: ChargingStation) {
        val newFav = !station.isFavorite
        stationDao.setFavorite(station.id, newFav)
        if (Firebase.auth.currentUser != null) {
            try {
                if (newFav) {
                    firestoreRepo.saveFavoriteStation(station.copy(isFavorite = true))
                } else {
                    firestoreRepo.removeFavoriteStation(station.id)
                }
            } catch (e: Exception) {
                // Logged
            }
        }
    }

    suspend fun toggleStationFavorite(id: String, currentFavorite: Boolean) {
        stationDao.setFavorite(id, !currentFavorite)
    }

    suspend fun addCustomStation(station: ChargingStation) {
        stationDao.insertStation(station.toEntity())
    }

    suspend fun deleteStation(station: ChargingStation) {
        stationDao.deleteStation(station.toEntity())
    }

    private fun RidePlanEntity.toDomain(): RidePlan {
        val weather = try {
            WeatherCondition.valueOf(weatherCondition)
        } catch (e: Exception) {
            WeatherCondition.CLEAR
        }
        return RidePlan(
            id = id,
            title = title,
            vehicleName = vehicleName,
            batteryCapacityKwh = batteryCapacityKwh,
            nominalRangeKm = nominalRangeKm,
            startBatteryPercent = startBatteryPercent,
            minReservePercent = minReservePercent,
            weatherCondition = weather,
            tariffPerKwh = tariffPerKwh,
            stops = JsonHelper.stopsFromJson(stopsJson),
            isSaved = isSaved,
            isCompleted = isCompleted,
            createdAt = createdAt
        )
    }

    private fun RidePlan.toEntity(isSaved: Boolean): RidePlanEntity {
        return RidePlanEntity(
            id = id,
            title = title,
            vehicleName = vehicleName,
            batteryCapacityKwh = batteryCapacityKwh,
            nominalRangeKm = nominalRangeKm,
            startBatteryPercent = startBatteryPercent,
            minReservePercent = minReservePercent,
            weatherCondition = weatherCondition.name,
            tariffPerKwh = tariffPerKwh,
            stopsJson = JsonHelper.stopsToJson(stops),
            isSaved = isSaved,
            isCompleted = isCompleted,
            createdAt = createdAt
        )
    }

    private fun ChargingStationEntity.toDomain(): ChargingStation {
        return ChargingStation(
            id = id,
            name = name,
            network = network,
            city = city,
            address = address,
            latitude = latitude,
            longitude = longitude,
            powerKw = powerKw,
            connectorType = connectorType,
            costPerKwh = costPerKwh,
            isFavorite = isFavorite,
            openHours = openHours
        )
    }

    private fun ChargingStation.toEntity(): ChargingStationEntity {
        return ChargingStationEntity(
            id = id,
            name = name,
            network = network,
            city = city,
            address = address,
            latitude = latitude,
            longitude = longitude,
            powerKw = powerKw,
            connectorType = connectorType,
            costPerKwh = costPerKwh,
            isFavorite = isFavorite,
            openHours = openHours
        )
    }
}
