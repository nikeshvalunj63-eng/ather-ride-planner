package com.example.data.local

import com.example.data.model.RidePlan
import com.example.data.model.StopItem
import com.example.data.model.StopType
import com.example.data.model.WeatherCondition
import org.json.JSONArray
import org.json.JSONObject

object JsonHelper {

    fun stopsToJson(stops: List<StopItem>): String {
        val array = JSONArray()
        stops.forEach { stop ->
            val obj = JSONObject().apply {
                put("id", stop.id)
                put("name", stop.name)
                put("type", stop.type.name)
                put("distanceToNextKm", stop.distanceToNextKm)
                if (stop.actualBatteryAfterCharge != null) {
                    put("actualBatteryAfterCharge", stop.actualBatteryAfterCharge)
                }
                put("targetChargePercent", stop.targetChargePercent)
                put("chargerSpeedKw", stop.chargerSpeedKw)
            }
            array.put(obj)
        }
        return array.toString()
    }

    fun stopsFromJson(jsonStr: String): List<StopItem> {
        if (jsonStr.isBlank()) return emptyList()
        val list = mutableListOf<StopItem>()
        try {
            val array = JSONArray(jsonStr)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val type = try {
                    StopType.valueOf(obj.optString("type", StopType.DESTINATION.name))
                } catch (e: Exception) {
                    StopType.DESTINATION
                }
                val actual = if (obj.has("actualBatteryAfterCharge") && !obj.isNull("actualBatteryAfterCharge")) {
                    obj.getDouble("actualBatteryAfterCharge")
                } else null

                list.add(
                    StopItem(
                        id = obj.optString("id"),
                        name = obj.optString("name", "Stop ${i + 1}"),
                        type = type,
                        distanceToNextKm = obj.optDouble("distanceToNextKm", 0.0),
                        actualBatteryAfterCharge = actual,
                        targetChargePercent = obj.optDouble("targetChargePercent", 90.0),
                        chargerSpeedKw = obj.optDouble("chargerSpeedKw", 3.3)
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    fun exportPlanToJson(plan: RidePlan): String {
        val obj = JSONObject().apply {
            put("app", "EV_RIDE_PLANNER")
            put("version", 1)
            put("id", plan.id)
            put("title", plan.title)
            put("vehicleName", plan.vehicleName)
            put("batteryCapacityKwh", plan.batteryCapacityKwh)
            put("nominalRangeKm", plan.nominalRangeKm)
            put("startBatteryPercent", plan.startBatteryPercent)
            put("minReservePercent", plan.minReservePercent)
            put("weatherCondition", plan.weatherCondition.name)
            put("tariffPerKwh", plan.tariffPerKwh)
            put("createdAt", plan.createdAt)
            put("stops", JSONArray(stopsToJson(plan.stops)))
        }
        return obj.toString(2)
    }

    fun importPlanFromJson(jsonStr: String): RidePlan? {
        return try {
            val obj = JSONObject(jsonStr)
            val stopsArray = obj.getJSONArray("stops")
            val stops = stopsFromJson(stopsArray.toString())
            val weather = try {
                WeatherCondition.valueOf(obj.optString("weatherCondition", WeatherCondition.CLEAR.name))
            } catch (e: Exception) {
                WeatherCondition.CLEAR
            }

            RidePlan(
                title = obj.optString("title", "Imported Ride"),
                vehicleName = obj.optString("vehicleName", "EV Scooter"),
                batteryCapacityKwh = obj.optDouble("batteryCapacityKwh", 3.7),
                nominalRangeKm = obj.optDouble("nominalRangeKm", 110.0),
                startBatteryPercent = obj.optDouble("startBatteryPercent", 100.0),
                minReservePercent = obj.optDouble("minReservePercent", 15.0),
                weatherCondition = weather,
                tariffPerKwh = obj.optDouble("tariffPerKwh", 15.0),
                stops = stops,
                isSaved = true
            )
        } catch (e: Exception) {
            null
        }
    }
}
