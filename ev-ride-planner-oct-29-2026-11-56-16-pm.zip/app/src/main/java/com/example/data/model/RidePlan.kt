package com.example.data.model

import java.util.UUID

data class RidePlan(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "My EV Ride",
    val vehicleName: String = "Ather 450X (Gen 3)",
    val batteryCapacityKwh: Double = 3.7,
    val nominalRangeKm: Double = 110.0,
    val startBatteryPercent: Double = 100.0,
    val minReservePercent: Double = 15.0, // Safety threshold
    val weatherCondition: WeatherCondition = WeatherCondition.CLEAR,
    val tariffPerKwh: Double = 15.0,
    val stops: List<StopItem> = emptyList(),
    val isSaved: Boolean = false,
    val isCompleted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

data class RideDashboardStats(
    val totalDistanceKm: Double = 0.0,
    val finalBatteryPercent: Double = 0.0,
    val extraDistancePossibleKm: Double = 0.0,
    val chargingStopsCount: Int = 0,
    val isTripSafe: Boolean = true,
    val statusSummary: String = "Safe Route",
    val totalChargingMinutes: Int = 0,
    val totalEstimatedCost: Double = 0.0,
    val effectiveRangeKm: Double = 110.0,
    val lowestBatteryPercent: Double = 100.0
)
