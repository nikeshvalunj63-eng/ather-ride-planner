package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ChargingStationDao {
    @Query("SELECT * FROM charging_stations ORDER BY name ASC")
    fun getAllStations(): Flow<List<ChargingStationEntity>>

    @Query("SELECT * FROM charging_stations WHERE isFavorite = 1 ORDER BY name ASC")
    fun getFavoriteStations(): Flow<List<ChargingStationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStation(station: ChargingStationEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(stations: List<ChargingStationEntity>)

    @Query("UPDATE charging_stations SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun setFavorite(id: String, isFavorite: Boolean)

    @Delete
    suspend fun deleteStation(station: ChargingStationEntity)

    @Query("SELECT COUNT(*) FROM charging_stations")
    suspend fun getStationCount(): Int
}
