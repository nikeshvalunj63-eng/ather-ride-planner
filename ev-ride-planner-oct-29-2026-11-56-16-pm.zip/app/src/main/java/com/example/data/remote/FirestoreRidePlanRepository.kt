package com.example.data.remote

import android.content.Context
import com.example.R
import com.example.data.local.JsonHelper
import com.example.data.model.ChargingStation
import com.example.data.model.RidePlan
import com.example.data.model.WeatherCondition
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class FirestoreRidePlanRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth = Firebase.auth

    fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing cloud Firestore.")
    }

    fun observeRidePlans(): Flow<List<RidePlan>> = flow {
        val uid = requireUserId()
        val path = "users/$uid/ridePlans"
        val collection = db.collection("users").document(uid).collection("ridePlans")

        emitAll(
            collection.snapshots()
                .map { snapshot ->
                    snapshot.documents.mapNotNull { doc ->
                        try {
                            val id = doc.getString("id") ?: doc.id
                            val title = doc.getString("title") ?: "Ride Plan"
                            val vehicleName = doc.getString("vehicleName") ?: "EV Two-Wheeler"
                            val nominalRangeKm = doc.getDouble("nominalRangeKm") ?: 100.0
                            val batteryCapacityKwh = doc.getDouble("batteryCapacityKwh") ?: 3.5
                            val startBatteryPercent = doc.getDouble("startBatteryPercent") ?: 100.0
                            val minReservePercent = doc.getDouble("minReservePercent") ?: 15.0
                            val weatherStr = doc.getString("weatherCondition") ?: WeatherCondition.CLEAR.name
                            val weather = try {
                                WeatherCondition.valueOf(weatherStr)
                            } catch (e: Exception) {
                                WeatherCondition.CLEAR
                            }
                            val tariff = doc.getDouble("tariffPerKwh") ?: 15.0
                            val stopsJson = doc.getString("stopsJson") ?: "[]"
                            val isSaved = doc.getBoolean("isSaved") ?: true
                            val isCompleted = doc.getBoolean("isCompleted") ?: false
                            val createdAt = doc.getTimestamp("createdAt")?.toDate()?.time ?: System.currentTimeMillis()

                            RidePlan(
                                id = id,
                                title = title,
                                vehicleName = vehicleName,
                                batteryCapacityKwh = batteryCapacityKwh,
                                nominalRangeKm = nominalRangeKm,
                                startBatteryPercent = startBatteryPercent,
                                minReservePercent = minReservePercent,
                                weatherCondition = weather,
                                tariffPerKwh = tariff,
                                stops = JsonHelper.stopsFromJson(stopsJson),
                                isSaved = isSaved,
                                isCompleted = isCompleted,
                                createdAt = createdAt
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                }
                .catch { error ->
                    if (error is Exception) {
                        handleFirestoreError(error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    private suspend fun <T> kotlinx.coroutines.flow.FlowCollector<T>.emitAll(flow: Flow<T>) {
        flow.collect { value -> emit(value) }
    }

    suspend fun saveRidePlan(plan: RidePlan) {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("ridePlans").document(plan.id)

        val payload = hashMapOf<String, Any>(
            "id" to plan.id,
            "userId" to uid,
            "title" to plan.title,
            "vehicleName" to plan.vehicleName,
            "nominalRangeKm" to plan.nominalRangeKm,
            "batteryCapacityKwh" to plan.batteryCapacityKwh,
            "startBatteryPercent" to plan.startBatteryPercent,
            "minReservePercent" to plan.minReservePercent,
            "weatherCondition" to plan.weatherCondition.name,
            "tariffPerKwh" to plan.tariffPerKwh,
            "stopsJson" to JsonHelper.stopsToJson(plan.stops),
            "isSaved" to plan.isSaved,
            "isCompleted" to plan.isCompleted,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )

        try {
            docRef.set(payload).await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            throw e
        }
    }

    suspend fun deleteRidePlan(planId: String) {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("ridePlans").document(planId)
        try {
            docRef.delete().await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    suspend fun saveFavoriteStation(station: ChargingStation) {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("favoriteStations").document(station.id)
        val payload = hashMapOf<String, Any>(
            "id" to station.id,
            "userId" to uid,
            "name" to station.name,
            "network" to station.network,
            "city" to station.city,
            "address" to station.address,
            "powerKw" to station.powerKw,
            "connectorType" to station.connectorType,
            "costPerKwh" to station.costPerKwh,
            "createdAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.set(payload).await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            throw e
        }
    }

    suspend fun removeFavoriteStation(stationId: String) {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("favoriteStations").document(stationId)
        try {
            docRef.delete().await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }
}
