package com.example.data.model

import java.util.UUID

data class StopItem(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: StopType,
    val distanceToNextKm: Double = 0.0,
    val actualBatteryAfterCharge: Double? = null,
    val targetChargePercent: Double = 90.0,
    val chargerSpeedKw: Double = 3.3, // e.g. 3.3kW AC or 25kW DC Ather Grid
    // Calculated values
    val arrivalBatteryPercent: Double = 100.0,
    val departureBatteryPercent: Double = 100.0,
    val consumptionPercentNextLeg: Double = 0.0,
    val isArrivalSafe: Boolean = true,
    val isLegSafe: Boolean = true,
    val safetyWarning: String? = null,
    val chargeDurationMinutes: Int = 0,
    val chargeCost: Double = 0.0
)
