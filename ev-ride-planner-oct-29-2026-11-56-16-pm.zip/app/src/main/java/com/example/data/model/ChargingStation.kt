package com.example.data.model

import java.util.UUID

data class ChargingStation(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val network: String, // "Ather Grid", "Bolt.earth", "Tata Power EZ Charge", "Jio-bp pulse", "Kazam", "Other"
    val city: String,
    val address: String,
    val latitude: Double,
    val longitude: Double,
    val powerKw: Double,
    val connectorType: String, // "Ather Fast Dot", "Type 2", "16A 3-pin AC", "CCS2"
    val costPerKwh: Double = 15.0, // in local currency (e.g. ₹15 / kWh)
    val isFavorite: Boolean = false,
    val openHours: String = "24/7 Available"
)
