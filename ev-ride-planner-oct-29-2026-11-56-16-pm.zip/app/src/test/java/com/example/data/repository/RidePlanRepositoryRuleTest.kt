package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.RidePlan
import com.example.data.model.StopItem
import com.example.data.model.StopType
import com.example.data.remote.FirestoreRidePlanRepository
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.UUID

class RidePlanRepositoryRuleTest : FirestoreEmulatorTestBase() {

  @Test
  fun saveAndObservePlan_authenticatedOwner_succeeds() = runBlocking {
    signInTestUser(ALICE_EMAIL)
    val repository = FirestoreRidePlanRepository(firestore)

    val planId = "test_plan_" + UUID.randomUUID().toString().take(8)
    val plan = RidePlan(
      id = planId,
      title = "Bangalore to Mysore Ride",
      nominalRangeKm = 120.0,
      stops = listOf(
        StopItem(name = "Indiranagar", type = StopType.HOME, distanceToNextKm = 30.0),
        StopItem(name = "Kengeri Charger", type = StopType.CHARGING_STATION, distanceToNextKm = 0.0)
      ),
      isSaved = true
    )

    withTimeout(DEFAULT_TIMEOUT_MS) {
      repository.saveRidePlan(plan)
    }

    val plans = withTimeout(FLOW_TIMEOUT_MS) {
      repository.observeRidePlans().first { list -> list.any { it.id == planId } }
    }

    assertNotNull(plans)
    val fetched = plans.find { it.id == planId }
    assertNotNull(fetched)
    assertEquals("Bangalore to Mysore Ride", fetched!!.title)
  }

  @Test
  fun deletePlan_authenticatedOwner_removesDocument() = runBlocking {
    signInTestUser(ALICE_EMAIL)
    val repository = FirestoreRidePlanRepository(firestore)

    val planId = "del_plan_" + UUID.randomUUID().toString().take(8)
    val plan = RidePlan(
      id = planId,
      title = "Temporary Ride",
      stops = emptyList()
    )

    withTimeout(DEFAULT_TIMEOUT_MS) {
      repository.saveRidePlan(plan)
    }

    withTimeout(DEFAULT_TIMEOUT_MS) {
      repository.deleteRidePlan(planId)
    }

    val plans = withTimeout(FLOW_TIMEOUT_MS) {
      repository.observeRidePlans().first()
    }
    assertTrue(plans.none { it.id == planId })
  }

  @Test
  fun crossUserAccess_bobCannotAccessAlicesPlansDirectly() = runBlocking {
    val aliceUid = signInTestUser(ALICE_EMAIL)
    val aliceRepo = FirestoreRidePlanRepository(firestore)
    val planId = "alice_plan_" + UUID.randomUUID().toString().take(8)
    val plan = RidePlan(id = planId, title = "Alice's Secret Route", stops = emptyList())

    withTimeout(DEFAULT_TIMEOUT_MS) {
      aliceRepo.saveRidePlan(plan)
    }

    // Now sign in as Bob
    signInTestUser(BOB_EMAIL)
    val bobRepo = FirestoreRidePlanRepository(firestore)

    // Bob observing his own plans will not see Alice's plan
    val bobPlans = withTimeout(FLOW_TIMEOUT_MS) {
      bobRepo.observeRidePlans().first()
    }
    assertTrue(bobPlans.none { it.id == planId })
  }

  @Test(expected = IllegalStateException::class)
  fun unauthenticatedAccess_failsFast() = runBlocking {
    auth.signOut()
    val repository = FirestoreRidePlanRepository(firestore)
    // requireUserId should throw immediately before contacting network
    repository.observeRidePlans().first()
    Unit
  }

  companion object {
    private const val ALICE_EMAIL = "alice_rule@test.com"
    private const val BOB_EMAIL = "bob_rule@test.com"
    private const val DEFAULT_TIMEOUT_MS = 6000L
    private const val FLOW_TIMEOUT_MS = 6000L
  }
}
