package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("EV Ride Planner", appName)
  }

  @Test
  fun testJsonExportAndImportWithAndroidContext() {
    val plan = com.example.data.model.RidePlan(
      title = "Test Trip",
      vehicleName = "Ola S1 Pro",
      nominalRangeKm = 140.0,
      stops = listOf(
        com.example.data.model.StopItem(name = "Stop A", type = com.example.data.model.StopType.HOME, distanceToNextKm = 20.0),
        com.example.data.model.StopItem(name = "Stop B", type = com.example.data.model.StopType.DESTINATION, distanceToNextKm = 0.0)
      )
    )

    val json = com.example.data.local.JsonHelper.exportPlanToJson(plan)
    org.junit.Assert.assertTrue(json.contains("Test Trip"))
    org.junit.Assert.assertTrue(json.contains("Ola S1 Pro"))

    val imported = com.example.data.local.JsonHelper.importPlanFromJson(json)
    org.junit.Assert.assertNotNull(imported)
    assertEquals("Test Trip", imported!!.title)
    assertEquals(2, imported.stops.size)
    assertEquals(20.0, imported.stops[0].distanceToNextKm, 0.01)
  }
}
