package com.example

import com.example.data.local.JsonHelper
import com.example.data.model.RidePlan
import com.example.data.model.StopItem
import com.example.data.model.StopType
import com.example.data.model.WeatherCondition
import com.example.domain.BatteryCalculator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testBatteryCalculation_SafeRoute() {
        val plan = RidePlan(
            nominalRangeKm = 100.0,
            startBatteryPercent = 100.0,
            minReservePercent = 15.0,
            weatherCondition = WeatherCondition.CLEAR,
            stops = listOf(
                StopItem(name = "Start", type = StopType.HOME, distanceToNextKm = 40.0),
                StopItem(name = "Destination", type = StopType.DESTINATION, distanceToNextKm = 0.0)
            )
        )

        val (updatedStops, stats) = BatteryCalculator.recalculatePlan(plan)

        assertEquals(2, updatedStops.size)
        // 40 km on 100 km range consumes 40%
        assertEquals(60.0, updatedStops[1].arrivalBatteryPercent, 0.1)
        assertTrue("Trip should be safe", stats.isTripSafe)
        assertEquals(60.0, stats.finalBatteryPercent, 0.1)
        assertEquals(60.0, stats.extraDistancePossibleKm, 0.1)
    }

    @Test
    fun testBatteryCalculation_WithChargingStop() {
        val plan = RidePlan(
            nominalRangeKm = 100.0,
            startBatteryPercent = 80.0,
            minReservePercent = 15.0,
            weatherCondition = WeatherCondition.CLEAR,
            stops = listOf(
                StopItem(name = "Home", type = StopType.HOME, distanceToNextKm = 60.0),
                StopItem(
                    name = "Ather Grid",
                    type = StopType.CHARGING_STATION,
                    distanceToNextKm = 50.0,
                    targetChargePercent = 90.0,
                    chargerSpeedKw = 25.0
                ),
                StopItem(name = "Final", type = StopType.DESTINATION, distanceToNextKm = 0.0)
            )
        )

        val (updatedStops, stats) = BatteryCalculator.recalculatePlan(plan)

        // Stop 0: Departs at 80%, consumes 60% -> arrives at Charger with 20%
        assertEquals(20.0, updatedStops[1].arrivalBatteryPercent, 0.1)
        // Recharges from 20% to target 90%
        assertEquals(90.0, updatedStops[1].departureBatteryPercent, 0.1)
        // Next leg: 50 km (consumes 50%) -> arrives at Final with 40%
        assertEquals(40.0, updatedStops[2].arrivalBatteryPercent, 0.1)
        assertTrue(stats.isTripSafe)
        assertEquals(1, stats.chargingStopsCount)
    }

    @Test
    fun testBatteryCalculation_LowBatteryWarning() {
        val plan = RidePlan(
            nominalRangeKm = 100.0,
            startBatteryPercent = 100.0,
            minReservePercent = 20.0,
            weatherCondition = WeatherCondition.CLEAR,
            stops = listOf(
                StopItem(name = "Start", type = StopType.HOME, distanceToNextKm = 85.0),
                StopItem(name = "Destination", type = StopType.DESTINATION, distanceToNextKm = 0.0)
            )
        )

        val (updatedStops, stats) = BatteryCalculator.recalculatePlan(plan)

        // Arrives at 15%, which is below the 20% reserve
        assertEquals(15.0, updatedStops[1].arrivalBatteryPercent, 0.1)
        assertFalse("Should fail safety reserve", stats.isTripSafe)
        assertNotNull(updatedStops[1].safetyWarning)
    }

    @Test
    fun testWeatherMultiplier() {
        val plan = RidePlan(
            nominalRangeKm = 100.0,
            startBatteryPercent = 100.0,
            weatherCondition = WeatherCondition.HILLY, // 0.78x multiplier -> 78 km range
            stops = listOf(
                StopItem(name = "Start", type = StopType.HOME, distanceToNextKm = 39.0),
                StopItem(name = "Ghat Peak", type = StopType.DESTINATION, distanceToNextKm = 0.0)
            )
        )

        val (updatedStops, stats) = BatteryCalculator.recalculatePlan(plan)

        // 39 km on 78 km effective range = 50% battery draw!
        assertEquals(50.0, updatedStops[1].arrivalBatteryPercent, 0.5)
        assertEquals(78.0, stats.effectiveRangeKm, 0.1)
    }
}
