const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: cannot read ride plans", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("ridePlans").get());
});

test("Authenticated user: can create, read, and delete their own ride plan", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const planRef = aliceDb.collection("users").doc(ALICE_UID).collection("ridePlans").doc("plan_1");

  await assertSucceeds(
    planRef.set({
      id: "plan_1",
      userId: ALICE_UID,
      title: "Nandi Hills Ride",
      stopsJson: "[]",
      createdAt: new Date(),
    })
  );

  await assertSucceeds(planRef.get());
  await assertSucceeds(planRef.delete());
});

test("Authenticated user: cannot read another user's ride plan", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("users").doc(BOB_UID).collection("ridePlans").doc("bob_plan").set({
      id: "bob_plan",
      userId: BOB_UID,
      title: "Bob's Secret Trip",
      stopsJson: "[]",
      createdAt: new Date(),
    });
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(
    aliceDb.collection("users").doc(BOB_UID).collection("ridePlans").doc("bob_plan").get()
  );
});

test("Authenticated user: cannot spoof userId on ride plan", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const planRef = aliceDb.collection("users").doc(ALICE_UID).collection("ridePlans").doc("plan_spoof");

  await assertFails(
    planRef.set({
      id: "plan_spoof",
      userId: BOB_UID, // Spoofed!
      title: "Spoofed Plan",
      stopsJson: "[]",
      createdAt: new Date(),
    })
  );
});

test("Authenticated user: can save favorite station", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const stationRef = aliceDb.collection("users").doc(ALICE_UID).collection("favoriteStations").doc("ath_1");

  await assertSucceeds(
    stationRef.set({
      id: "ath_1",
      userId: ALICE_UID,
      name: "Ather Grid Indiranagar",
      network: "Ather Grid",
      createdAt: new Date(),
    })
  );
  await assertSucceeds(stationRef.get());
});
