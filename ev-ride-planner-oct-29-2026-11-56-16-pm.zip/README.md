# EV Ride Planner ⚡🛵

A complete Android application built with Kotlin and Jetpack Compose to help electric scooter and motorcycle riders plan trips with charging stops, real-time battery calculations, safety reserve buffers, and station discovery.

---

## 🌟 Key Features

### 1. Trip Planning & Vehicle Configuration
- **Vehicle Presets:** Built-in profiles for popular electric two-wheelers including **Ather 450X**, **Ola S1 Pro Gen 2**, **TVS iQube ST**, **Bajaj Chetak**, **Ultraviolette F77**, **Vida V1 Pro**, **Revolt RV400**, or custom EV parameters.
- **Battery Range at 100%:** Configure nominal range in kilometers.
- **Starting Battery Percentage:** Adjust starting State-of-Charge (SoC).
- **Safety Reserve Threshold:** Configurable safety reserve (default 15%) to prevent running out of power.
- **Stop Types:**
  - 🏠 **Home** (Start / Finish)
  - ⚡ **Charging Station** (Recharge point with speed selection)
  - 📍 **Destination / Waypoint** (Scenic point, cafe, viewpoint, etc.)

### 2. Route Management
- Enter distances (km) between each waypoint.
- Add, edit, delete, and reorder stops with instant single-tap controls.
- Dynamic calculation of total route distance and leg-by-leg segments.

### 3. Smart Battery Calculations & Auto-Recalculation
- **Consumption Rate:** Calculates exact battery consumption for each route segment:
  $$\text{Consumption (\%)} = \left(\frac{\text{Distance (km)}}{\text{Effective Range (km)}}\right) \times 100$$
- **Arrival & Departure Battery:** View estimated arrival battery percentage at every stop.
- **Post-Charge Override:** Log real-world battery levels after charging to automatically recalculate the remaining trip in real-time.
- **Charging Duration & Cost Estimation:** Estimates charging time in minutes and charging tariffs based on charger speed (3.3 kW AC, 7.4 kW Type 2, 25 kW DC Fast).

### 4. Safety Checks & Risk Warnings
- **PASS / FAIL Status:** High-visibility banner evaluating if the trip can be safely completed without stranding.
- **Safety Reserve Breached:** Warning indicators if arrival battery drops below the configured safety reserve.
- **Deficit Alerts:** Clear alerts if a rider cannot reach the next stop, showing exact battery deficit and distance shortage.

### 5. Interactive Dashboard & Visualizations
- **Telemetry Metrics:** Total distance, final battery %, extra distance buffer, charging stops count, and charging cost.
- **Interactive Route Track & SoC Curve Graph:** Custom Canvas component displaying the waypoint track and the battery State-of-Charge curve across all stops.

### 6. Charging Stations Directory
- Pre-populated directory of EV charging stations across major Indian cities (Bengaluru, Mumbai, Delhi, Pune, Hyderabad, Goa).
- Network filters: **Ather Grid**, **Bolt.earth**, **Tata Power EZ Charge**, **Jio-bp pulse**, **Kazam**.
- Save favorite charging stations with quick one-tap toggle.
- **"Add to Route"**: Direct button to insert any charging station into your active ride plan.
- **Custom Stations:** Register local community plugs or highway dhabas with EV power.

### 7. Weather & Riding Conditions Impact
- Range impact coefficients:
  - Optimal (25°C): 1.0x
  - High Heat (38°C+): 0.92x (-8%)
  - Rain & Wet Roads: 0.88x (-12%)
  - Strong Headwind: 0.84x (-16%)
  - Hill Climb / Ghats: 0.78x (-22%)

### 8. Local Storage & Sharing
- **Room Database:** Local offline persistence for ride plans, favorite stations, and ride logs.
- **Export & Import:** Export ride plans as clean JSON to share with fellow riders via clipboard or Android Share Sheet, or paste JSON to import a friend's route.
- **History Log:** Keep track of completed rides, total kilometers traveled on clean EV power, and estimated petrol cost savings.

---

## 🛠️ Architecture & Tech Stack

- **Language:** Kotlin 100%
- **UI Framework:** Jetpack Compose (Material 3)
- **Architecture:** MVVM (Model-View-ViewModel) + Clean Architecture
- **State Management:** Kotlin Coroutines & `MutableStateFlow`
- **Database:** Android Room with KSP
- **Styling:** Custom High-Tech EV Green Dark Cockpit theme with full Light Mode support

---

## 🚀 Build & Run Instructions

### Prerequisites
- Android Studio Ladybug (2024.2.1) or newer
- JDK 11 or newer
- Android SDK 36 (minSdk 24)

### Building via Terminal
```bash
# Compile and build Debug APK
gradle :app:assembleDebug

# Run unit tests
gradle :app:testDebugUnitTest
```

The debug APK will be generated at:
`app/build/outputs/apk/debug/app-debug.apk`

---

## 📱 Package Info
- **Package Name:** `com.example`
- **Application ID:** `com.aistudio.evrideplanner.vtzpqe`
- **Target SDK:** 36 (Android 15 / 16)
- **Min SDK:** 24 (Android 7.0 Nougat+)
